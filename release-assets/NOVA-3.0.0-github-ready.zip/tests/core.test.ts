import { test } from 'node:test';
import assert from 'node:assert/strict';
import { defaults, makeProfile, applyTheme } from '../src/settings/schema';
import { validateSettings } from '../src/storage/settings';
import { parse, suggestions } from '../src/terminal/parser';
import { safeURL } from '../src/shared/dom';
import { migrateSettings } from '../src/settings/migrations';
test('prototype names are ordinary search queries', () => {
  const p = makeProfile();
  for (const word of ['constructor', 'toString', '__proto__'])
    assert.equal(parse(word, p.terminal).command, 'search');
});
import { mergeSettings } from '../src/storage/reconcile';
test('concurrent tabs retain unrelated profile edits and intentional removals', () => {
  const base = defaults(),
    local = structuredClone(base),
    remote = structuredClone(base);
  local.profiles[0].notes = 'local note';
  remote.profiles[0].appearance.accent = '#abcdef';
  remote.profiles[1].name = 'Remote Coding';
  const merged = mergeSettings(base, local, remote);
  assert.equal(merged.profiles[0].notes, 'local note');
  assert.equal(merged.profiles[0].appearance.accent, '#abcdef');
  assert.equal(merged.profiles[1].name, 'Remote Coding');
  local.profiles.splice(1, 1);
  assert.ok(!mergeSettings(base, local, remote).profiles.some((p) => p.id === 'coding'));
});
test('unversioned settings migrate without losing profiles', () => {
  const s = defaults();
  const raw = { ...s, schemaVersion: 0 };
  assert.equal(migrateSettings(raw).schemaVersion, 7);
  assert.equal(validateSettings(raw).profiles[0].name, 'Minimal');
  assert.throws(() => migrateSettings({ schemaVersion: 99 }), /version/);
});
test('search aliases, quoted commands, and fallback search', () => {
  const p = makeProfile();
  assert.equal(
    parse('yt cyber security', p.terminal).searchURL,
    'https://www.youtube.com/results?search_query=cyber%20security',
  );
  assert.equal(parse('gh xtufa7', p.terminal).searchURL, 'https://github.com/search?q=xtufa7');
  assert.deepEqual(parse('session save "my work"', p.terminal).args, ['save', 'my work']);
  assert.equal(parse('acer nitro gpu problem', p.terminal).query, 'acer nitro gpu problem');
  assert.ok(parse('<script>alert(1)</script>', p.terminal).searchURL?.includes('%3Cscript%3E'));
});
test('custom engines and aliases survive import; cycles fail', () => {
  const s = defaults();
  s.profiles[0].terminal.engines.custom = 'https://example.com/?q={query}';
  s.profiles[0].terminal.aliases.find = 'custom';
  const imported = validateSettings(JSON.parse(JSON.stringify(s)));
  assert.equal(
    parse('find cats', imported.profiles[0].terminal).searchURL,
    'https://example.com/?q=cats',
  );
  imported.profiles[0].terminal.aliases = { a: 'b', b: 'a' };
  assert.throws(() => parse('a', imported.profiles[0].terminal), /cycle/);
});
test('layout, hidden credits, profiles, and media references roundtrip', () => {
  const s = defaults();
  s.profiles[0].layout.clock = {
    x: 20,
    y: 30,
    w: 30,
    h: 20,
    z: 3,
    locked: true,
    custom: true,
  };
  s.profiles[0].widgets.credits = false;
  s.profiles[0].appearance.mediaId = 'local-media';
  const restored = validateSettings(JSON.parse(JSON.stringify(s)));
  assert.deepEqual(restored.profiles[0].layout, s.profiles[0].layout);
  assert.equal(restored.profiles[0].widgets.credits, false);
  assert.equal(restored.profiles[0].appearance.mediaId, 'local-media');
  assert.equal(restored.profiles.length, 4);
});
test('invalid imports never get silently accepted', () => {
  const mutate = (fn: (s: ReturnType<typeof defaults>) => void) => {
    const s = defaults();
    fn(s);
    return s;
  };
  assert.throws(() => validateSettings({ schemaVersion: 99 }), /version/);
  assert.throws(() =>
    validateSettings(mutate((s) => (s.profiles[0].links[0].url = 'javascript:alert(1)'))),
  );
  assert.throws(() => validateSettings(mutate((s) => (s.profiles[0].appearance.blur = Infinity))));
  assert.throws(() => validateSettings(mutate((s) => (s.profiles[0].music.volume = 101))));
  assert.throws(() =>
    validateSettings(
      mutate(
        (s) =>
          (s.profiles[0].layout.clock = {
            x: NaN,
            y: 1,
            w: 1,
            h: 1,
            z: 1,
            locked: false,
            custom: true,
          }),
      ),
    ),
  );
  assert.throws(() =>
    validateSettings(mutate((s) => (s.profiles[0].widgets.notes = 'yes' as never))),
  );
  assert.throws(() => validateSettings(mutate((s) => (s.activeProfile = 'missing'))));
  assert.throws(() =>
    validateSettings(
      mutate((s) => (s.profiles[0].terminal.engines.x = 'https://example.com/no-placeholder')),
    ),
  );
  assert.throws(() => validateSettings(mutate((s) => (s.profiles[1].id = s.profiles[0].id))));
});
test('defaults are independent, theme application and completion work', () => {
  const a = defaults(),
    b = defaults();
  a.profiles[0].notes = 'hello';
  assert.equal(b.profiles[0].notes, '');
  applyTheme(a.profiles[0], 'dusk');
  assert.equal(a.profiles[0].appearance.accent, '#e6a8b8');
  assert.throws(() => applyTheme(a.profiles[0], 'missing'));
  assert.ok(suggestions('op', a.profiles[0]).some((s) => s.value === 'open'));
});
test('unsafe URL protocols and embedded credentials are rejected', () => {
  for (const value of [
    'javascript:alert(1)',
    'data:text/html,hello',
    'https://user:secret@example.com',
  ])
    assert.throws(() => safeURL(value));
  assert.equal(safeURL('https://github.com/xtufa7'), 'https://github.com/xtufa7');
});

test('version 1 upgrade keeps music, layout, media and customized text; saved themes validate', () => {
  const legacy: any = defaults();
  legacy.schemaVersion = 1;
  legacy.profiles[0].notes = 'Keep this';
  legacy.profiles[0].appearance.mediaId = 'local-image';
  legacy.profiles[0].music.volume = 67;
  for (const p of legacy.profiles) {
    delete p.appearance.clockFace;
    delete p.appearance.clockFont;
    delete p.appearance.clockCaption;
    delete p.music.autoDuck;
  }
  delete legacy.customThemes;
  delete legacy.privacy.blockTrackers;
  delete legacy.privacy.exceptions;
  const upgraded = validateSettings(legacy);
  assert.equal(upgraded.schemaVersion, 7);
  assert.equal(upgraded.profiles[0].notes, 'Keep this');
  assert.equal(upgraded.profiles[0].music.volume, 67);
  assert.equal(upgraded.profiles[0].music.autoDuck, true);
  assert.equal(upgraded.profiles[0].appearance.mediaId, 'local-image');
  upgraded.profiles[0].appearance.clockCaption = 'وقت هادئ';
  upgraded.profiles[0].appearance.clockFace = 'neon';
  upgraded.profiles[0].appearance.clockFont = 'mono';
  upgraded.customThemes.push({
    id: 'custom',
    name: 'My neon',
    appearance: structuredClone(upgraded.profiles[0].appearance),
  });
  const restored = validateSettings(JSON.parse(JSON.stringify(upgraded)));
  assert.equal(restored.customThemes[0].appearance.clockCaption, 'وقت هادئ');
  assert.equal(restored.customThemes[0].appearance.clockFace, 'neon');
  upgraded.privacy.exceptions = ['https://bad.com/path'];
  assert.throws(() => validateSettings(upgraded));
});

test('v3 upgrade enables repeat and preserves media, branding defaults and settings isolation', () => {
  const legacy: any = defaults();
  legacy.schemaVersion = 3;
  delete legacy.branding;
  delete legacy.memory;
  delete legacy.accountAvatars;
  legacy.profiles[0].music.repeat = 'off';
  legacy.profiles[1].music.repeat = 'one';
  legacy.profiles[0].appearance.clockSpacing = -0.2;
  legacy.profiles[0].appearance.mediaId = 'keep-wallpaper';
  const migrated = validateSettings(legacy);
  assert.equal(migrated.profiles[0].music.repeat, 'all');
  assert.equal(migrated.profiles[1].music.repeat, 'one');
  assert.equal(migrated.profiles[0].appearance.clockSpacing, -0.2);
  assert.equal(migrated.profiles[0].appearance.mediaId, 'keep-wallpaper');
  assert.deepEqual(migrated.branding, { name: 'NØVA', hidden: false });
  assert.deepEqual(migrated.memory, { enabled: true, browser: 'helium' });
  assert.equal(legacy.profiles[0].music.repeat, 'off');
});

test('v4 migration keeps customization while replacing helper integrations with browser defaults', () => {
  const legacy: any = defaults();
  legacy.schemaVersion = 4;
  delete legacy.tab;
  delete legacy.profiles[0].widgets.lyrics;
  legacy.integrations.spotifySource = 'desktop';
  legacy.integrations.spotify = true;
  legacy.integrations.spectrum = 'native-cava';
  legacy.branding.name = 'TuFa7';
  legacy.profiles[0].appearance.mediaId = 'keep-video';
  const restored = validateSettings(legacy);
  assert.equal(restored.schemaVersion, 7);
  assert.equal(restored.branding.name, 'TuFa7');
  assert.equal(restored.profiles[0].appearance.mediaId, 'keep-video');
  assert.equal(restored.integrations.spotifySource, 'web');
  assert.equal(restored.integrations.spotify, false);
  assert.equal(restored.integrations.spectrum, 'cava');
  assert.equal(restored.profiles[0].widgets.lyrics, true);
  assert.equal(restored.tab.title, 'NØVA');
  restored.tab.title = '';
  assert.throws(() => validateSettings(restored), /tab title/);
});

test('legacy motion settings receive independent lyrics and opening defaults', () => {
 const legacy=defaults() as any;delete legacy.lyrics;delete legacy.entrance;legacy.performance.animations='off';
 const s=validateSettings(legacy);assert(s.lyrics.enabled&&s.entrance.enabled);assert.equal(s.performance.animations,'off');
 s.lyrics.arabicFont='Tahoma';s.lyrics.englishFont='Arial';s.lyrics.color='#aabbcc';s.entrance.duration=1250;
 assert.deepEqual(validateSettings(JSON.parse(JSON.stringify(s))).lyrics,s.lyrics);
 assert.equal(validateSettings(JSON.parse(JSON.stringify(s))).entrance.duration,1250);
});
test('lyrics and opening customization reject unsafe or out-of-range values',()=>{
 const s=defaults();s.lyrics.color='red; background:url(https://example.com)';assert.throws(()=>validateSettings(s));
 s.lyrics.color='#ffffff';s.lyrics.duration=-1;assert.throws(()=>validateSettings(s));
 s.lyrics.duration=650;s.entrance.stagger=99999;assert.throws(()=>validateSettings(s));
});
