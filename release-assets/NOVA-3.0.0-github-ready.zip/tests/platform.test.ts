import test from 'node:test';
import assert from 'node:assert/strict';
import { isGeckoAPI } from '../src/shared/platform';
test('a Chromium browser alias never enables Firefox-only permissions', () => {
 assert.equal(isGeckoAPI(undefined), false);
 assert.equal(isGeckoAPI({runtime:{getManifest:()=>({})}}), false);
 assert.equal(isGeckoAPI({runtime:{getManifest:()=>({browser_specific_settings:{gecko:{id:'nova@xtufa7'}}})}}), false);
 assert.equal(isGeckoAPI({runtime:{getBrowserInfo:()=>{},getManifest:()=>({browser_specific_settings:{gecko:{id:'nova@xtufa7'}}})}}), true);
});
