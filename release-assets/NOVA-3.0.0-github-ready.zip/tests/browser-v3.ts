import { chromium } from 'playwright';
import { resolve } from 'node:path';
import { cpSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { createServer } from 'node:http';
import assert from 'node:assert/strict';
import { defaults, type Settings } from '../src/settings/schema';
const html = `<!doctype html><html><head><title>Website fixture</title><style>body{background:#fff;color:#222;font:16px system-ui}main{background:#f4f4f4;padding:30px}#dark{background:#222;color:white;padding:20px}#transparent{background:rgba(0,0,0,.15)}#gradient{background:linear-gradient(90deg,rgb(240,240,240),rgb(80,80,80));padding:20px}img,canvas,svg{background:#ff0000}input{background:white;color:#111}.changing{background:#ddd}</style></head><body><h1>Website fixture</h1><main id="main"><p id="text">Readable original text</p><section id="dark">A dark surface</section><section id="transparent">Transparent panel</section><section id="gradient">Gradient</section><img id="photo" width="80" height="80" src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='80' height='80'%3E%3Crect fill='red' width='80' height='80'/%3E%3C/svg%3E"><canvas id="chart"></canvas><svg id="graphic" width="80" height="80"><rect fill="red" width="80" height="80"/></svg><div contenteditable id="editor" style="background:#ffffff;color:#111111">Editable</div><form action="/login"><input type="password" id="password"><button>Sign in</button></form><aside id="distraction">Suggested videos</aside><div id="shadow-host"></div></main><script>const r=document.querySelector('#shadow-host').attachShadow({mode:'open'});r.innerHTML='<style>p{background:rgb(255,255,255);color:rgb(0,0,0)}</style><p id="shadow-text">Shadow content</p>';</script></body></html>`;
const server = createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/html' });
  res.end(
    req.url === '/large'
      ? html.replace(
          '</main>',
          Array.from({ length: 2500 }, (_, i) => `<div class="changing">Row ${i}</div>`).join('') +
            '</main>',
        )
      : html,
  );
});
await new Promise<void>((r) => server.listen(0, '127.0.0.1', r));
const address = server.address() as { port: number };
const url = 'http://127.0.0.1:' + address.port;
mkdirSync('work', { recursive: true });
const output = resolve('work/v3-evidence');
mkdirSync(output, { recursive: true });
const fixture = resolve('work/v3-extension');
cpSync(resolve('dist'), fixture, { recursive: true });
const m = JSON.parse(readFileSync(resolve(fixture, 'manifest.json'), 'utf8'));
m.permissions.push('tabs', 'sessions', 'tabGroups');
m.optional_permissions = m.optional_permissions.filter((p: string) => !m.permissions.includes(p));
m.host_permissions.push('http://127.0.0.1/*');
writeFileSync(resolve(fixture, 'manifest.json'), JSON.stringify(m));
const context = await chromium.launchPersistentContext(resolve('work/v3-profile-' + Date.now()), {
  executablePath: process.env.NOVA_BROWSER,
  headless: true,
  viewport: { width: 1440, height: 1000 },
  args: [`--disable-extensions-except=${fixture}`, `--load-extension=${fixture}`],
});
const errors: string[] = [];
context.on('page', (p) => p.on('pageerror', (e) => errors.push(e.message)));
await context.addInitScript(() => {
  const list: {
    id: string;
    when: number;
    frames: ComputedKeyframe[];
    duration: number | string;
  }[] = [];
  (window as unknown as { opening: listType }).opening = list;
  type listType = typeof list;
  const original = Element.prototype.animate;
  Element.prototype.animate = function (frames, options) {
    const a = original.call(this, frames, options);
    if (this.matches('.wordmark,#canvas>.widget,#background'))
      list.push({
        id: this.id || this.className,
        when: performance.now(),
        frames: (a.effect as KeyframeEffect).getKeyframes(),
        duration: String(a.effect!.getTiming().duration!),
      });
    return a;
  };
});
const report: Record<string, unknown> = {
  version: '3.0.0',
  fixturePermissions:
    'Optional tabs/sessions/groups and localhost granted only in isolated test manifest',
  opening: [],
  checks: [],
};
try {
  let worker = context.serviceWorkers().find((w) => w.url().startsWith('chrome-extension:'));
  if (!worker)
    worker = await context.waitForEvent('serviceworker', {
      predicate: (w) => w.url().startsWith('chrome-extension:'),
    });
  console.log('Worker:', worker.url());
  await new Promise((r) => setTimeout(r, 600));
  const base = 'chrome-extension://' + new URL(worker.url()).host;
  const config = defaults();
  config.integrations.spotify = false;
  config.integrations.onlineLyrics = false;
  config.entrance.duration = 1200;
  config.entrance.delay = 250;
  config.entrance.stagger = 60;
  config.entrance.enabled = true;
  config.performance.animations = 'off';
  config.suite.website.enabled = true;
  config.profiles[0].appearance.background = 'solid';
  await worker.evaluate(async (s) => {
    await chrome.storage.local.set({ 'nova.settings': s, 'nova.spotify.autoSetup.v1': true });
  }, config);
  await context.route('https://lrclib.net/**', (r) => r.abort());
  async function actualNewTab() {
    const created = context.waitForEvent('page');
    await worker!.evaluate(() => chrome.tabs.create({ active: true }));
    const p = await created;
    await p.bringToFront();
    await p.waitForFunction(() => performance.getEntriesByName('nova-opening-start').length > 0);
    return p;
  }
  for (const style of ['rise+blur', 'rise', 'fade', 'zoom', 'slide'] as const) {
    config.entrance.style = style;
    await worker.evaluate((s) => chrome.storage.local.set({ 'nova.settings': s }), config);
    const p = await actualNewTab();
    assert(p.url().includes('newtab'), 'Actual browser-created New Tab');
    const record = await p.evaluate(
      () =>
        (
          window as unknown as {
            opening: { id: string; frames: ComputedKeyframe[]; when: number }[];
          }
        ).opening,
    );
    assert(record.some((r) => r.id === 'widget-clock'));
    assert(record.some((r) => r.id === 'widget-terminal'));
    const clock = record.find((r) => r.id === 'widget-clock')!;
    if (style === 'rise+blur') assert(String(clock.frames[0].filter).includes('blur('));
    if (style === 'slide') assert(String(clock.frames[0].translate).includes('-'));
    if (style === 'zoom') assert(clock.frames[0].scale === '0.9');
    (report.opening as unknown[]).push({ style, url: p.url(), record });
    if (style === 'rise+blur') {
      await p.screenshot({ path: resolve(output, 'opening-start.png') });
      await p.waitForTimeout(450);
      await p.screenshot({ path: resolve(output, 'opening-middle.png') });
      await p.waitForTimeout(1400);
      await p.screenshot({ path: resolve(output, 'opening-end.png') });
      await p.getByRole('button', { name: 'Open control center', exact: true }).click();
      await p.getByRole('button', { name: 'Website Appearance', exact: true }).click();
      await p.screenshot({ path: resolve(output, 'website-settings.png') });
      await p.getByRole('button', { name: 'Theme Marketplace', exact: true }).click();
      await p.screenshot({ path: resolve(output, 'marketplace.png') });
      await p.keyboard.press('Escape');
      await p.keyboard.press('Alt+Shift+P');
      await p.getByRole('combobox', { name: 'Search commands' }).waitFor();
      await p.screenshot({ path: resolve(output, 'command-palette.png') });
      await p.keyboard.press('Escape');
      const count = await p.evaluate(
        () => (window as unknown as { opening: unknown[] }).opening.length,
      );
      await p.waitForTimeout(200);
      assert.equal(
        await p.evaluate(() => (window as unknown as { opening: unknown[] }).opening.length),
        count,
        'Settings must not replay opening',
      );
    }
    await p.close();
  }
  console.log('Actual browser-created New Tab: all 5 styles passed.');
  config.entrance.header = true;
  config.entrance.clock = false;
  config.entrance.terminal = false;
  config.entrance.widgets = false;
  await worker.evaluate((s) => chrome.storage.local.set({ 'nova.settings': s }), config);
  const targetTab = await actualNewTab();
  const targetRecords = await targetTab.evaluate(
    () => (window as unknown as { opening: { id: string }[] }).opening,
  );
  assert(targetRecords.some((r) => r.id === 'wordmark'));
  assert(
    !targetRecords.some((r) => r.id.startsWith('widget-')),
    'Header stays independent of widget toggles',
  );
  await targetTab.close();
  const site = await context.newPage();
  await site.goto(url);
  await site.waitForFunction(() => !!document.querySelector('[data-nova-engine]'));
  await site.waitForFunction(
    () => getComputedStyle(document.body).backgroundColor === 'rgb(30, 30, 46)',
  );
  const mapped = await site.locator('#main').evaluate((e) => getComputedStyle(e).backgroundColor);
  assert.notEqual(mapped, 'rgb(244, 244, 244)');
  assert.notEqual(
    await site.locator('#dark').evaluate((e) => getComputedStyle(e).backgroundColor),
    mapped,
    'Distinct surfaces',
  );
  for (const id of ['photo', 'chart', 'graphic', 'editor', 'password'])
    assert.equal(
      await site.locator('#' + id).getAttribute('style'),
      id === 'editor' ? 'background:#ffffff;color:#111111' : null,
      'Protected original styles: ' + id,
    );
  await site.waitForFunction(
    () =>
      getComputedStyle(document.querySelector('#shadow-host')!.shadowRoot!.querySelector('p')!)
        .backgroundColor !== 'rgb(255, 255, 255)',
  );
  await site.evaluate(() => {
    const div = document.createElement('div');
    div.id = 'dynamic';
    div.style.backgroundColor = '#ffffff';
    div.textContent = 'SPA insert';
    document.body.append(div);
  });
  await site.waitForFunction(
    () =>
      getComputedStyle(document.querySelector('#dynamic')!).backgroundColor !==
      'rgb(255, 255, 255)',
  );
  await site.screenshot({ path: resolve(output, 'website-themed.png') });
  const controller = await context.newPage();
  await controller.goto(base + '/settings.html');
  const tabId = await worker.evaluate(
    async (u) => (await chrome.tabs.query({ url: u }))[0].id!,
    site.url(),
  );
  await controller.evaluate(async (id) => {
    await chrome.runtime.sendMessage({
      target: 'worker',
      type: 'suite-site-save',
      tabId: id,
      focus: '#distraction',
      focusEnabled: true,
    });
  }, tabId);
  await site.bringToFront();
  await site.waitForFunction(
    () => getComputedStyle(document.querySelector('#distraction')!).display === 'none',
  );
  await worker.evaluate('globalThis.__name=(fn)=>fn;');
  await worker.evaluate(async (id) => {
    await chrome.scripting.executeScript({
      target: { tabId: id },
      func: () => {
        const old = Element.prototype.attachShadow;
        Element.prototype.attachShadow = function (init) {
          const root = old.call(this, init);
          if (this.hasAttribute('data-nova-ui'))
            (window as unknown as { __testUI?: ShadowRoot }).__testUI = root;
          return root;
        };
      },
    });
    await chrome.tabs.sendMessage(id, { type: 'nova-inspect' }, { frameId: 0 });
  }, tabId);
  await site.locator('#dark').click({ position: { x: 20, y: 10 } });
  const preview = await worker.evaluate(async (id) => {
    return (
      await chrome.scripting.executeScript({
        target: { tabId: id },
        func: () => {
          const root = (window as unknown as { __testUI: ShadowRoot }).__testUI;
          const input = root.querySelector<HTMLInputElement>('[aria-label="Inspector base"]')!;
          input.value = '#234567';
          input.dispatchEvent(new Event('input', { bubbles: true }));
          return root.querySelector('.inspector-info')?.textContent;
        },
      })
    )[0].result;
  }, tabId);
  assert(String(preview).includes('#dark'));
  await site.waitForTimeout(100);
  assert.equal(
    await site.locator('#dark').evaluate((n) => getComputedStyle(n).backgroundColor),
    'rgb(35, 69, 103)',
  );
  await site.screenshot({ path: resolve(output, 'inspector.png') });
  for (const action of ['Undo', 'Redo', 'Save override'])
    await worker.evaluate(
      async (data) => {
        await chrome.scripting.executeScript({
          target: { tabId: data.id },
          func: (label: string) => {
            const root = (window as unknown as { __testUI: ShadowRoot }).__testUI;
            [...root.querySelectorAll('button')].find((n) => n.textContent === label)!.click();
          },
          args: [data.action],
        });
      },
      { id: tabId, action },
    );
  await site.waitForFunction(
    () => getComputedStyle(document.querySelector('#dark')!).backgroundColor === 'rgb(35, 69, 103)',
  );
  const saved = await worker.evaluate(async () => {
    const s = (await chrome.storage.local.get('nova.settings'))['nova.settings'] as Settings;
    return s.suite.website.sites[0].elements;
  });
  assert(saved.some((r) => r.selector === '#dark' && r.colors.base === '#234567'));
  const metrics = await worker.evaluate(
    (id) => chrome.tabs.sendMessage(id, { type: 'nova-metrics' }, { frameId: 0 }),
    tabId,
  );
  report.website = metrics;
  await worker.evaluate(async () => {
    const s = (await chrome.storage.local.get('nova.settings'))['nova.settings'] as Settings;
    s.suite.website.enabled = false;
    s.suite.website.sites = [];
    await chrome.storage.local.set({ 'nova.settings': s });
  });
  await site.waitForFunction(
    () => getComputedStyle(document.body).backgroundColor === 'rgb(255, 255, 255)',
  );
  assert.equal(await site.locator('#main').getAttribute('style'), null);
  assert.equal(await site.locator('#dark').getAttribute('style'), null);
  await site.screenshot({ path: resolve(output, 'website-original.png') });
  assert.notEqual(
    await site.locator('#distraction').evaluate((e) => getComputedStyle(e).display),
    'none',
  );
  console.log(
    'Themes, dynamic DOM, open shadow, protected media/forms, focus and exact restoration passed.',
  );
  const manager = await context.newPage();
  await manager.goto(base + '/manager.html');
  await manager.getByLabel('Search tabs').waitFor();
  await manager.screenshot({ path: resolve(output, 'tab-manager.png') });
  await manager.getByLabel('Search tabs').fill('Website fixture');
  assert((await manager.locator('.tab-row').count()) >= 1);
  const before = await worker.evaluate(() => chrome.tabs.query({}).then((v) => v.length));
  await manager
    .getByRole('button', { name: 'Duplicate Website fixture', exact: true })
    .first()
    .click();
  await manager.waitForTimeout(200);
  assert.equal(
    await worker.evaluate(() => chrome.tabs.query({}).then((v) => v.length)),
    before + 1,
  );
  async function tabAction(action: string, data: Record<string, unknown> = {}) {
    const result = await manager.evaluate(
      async (v) => chrome.runtime.sendMessage({ target: 'worker', type: 'suite-tab-action', ...v }),
      { action, ...data },
    );
    assert(!result.error, JSON.stringify(result));
  }
  const duplicateId = await worker.evaluate(
    async (u) => (await chrome.tabs.query({ url: u })).find((t) => t.id !== undefined)?.id!,
    site.url(),
  );
  await tabAction('pin', { id: duplicateId, value: true });
  assert((await worker.evaluate((id) => chrome.tabs.get(id), duplicateId)).pinned);
  await tabAction('pin', { id: duplicateId, value: false });
  await tabAction('mute', { id: duplicateId, value: true });
  assert((await worker.evaluate((id) => chrome.tabs.get(id), duplicateId)).mutedInfo?.muted);
  await tabAction('move', { id: duplicateId, index: 0 });
  assert.equal((await worker.evaluate((id) => chrome.tabs.get(id), duplicateId)).index, 0);
  await tabAction('group', { ids: [duplicateId], value: 'Suite QA' });
  const groupId = (await worker.evaluate((id) => chrome.tabs.get(id), duplicateId)).groupId;
  assert.equal(
    (await worker.evaluate((id) => chrome.tabGroups.get(id), groupId)).title,
    'Suite QA',
  );
  await tabAction('workspace', { ids: [duplicateId], value: config.activeProfile });
  assert.equal(
    await worker.evaluate(
      async (id) =>
        ((await chrome.storage.local.get('nova.settings'))['nova.settings'] as Settings).suite.tabs
          .assignments[String(id)],
      duplicateId,
    ),
    config.activeProfile,
  );
  await tabAction('save', { value: 'Suite QA' });
  assert(
    await worker.evaluate(async () =>
      (
        (await chrome.storage.local.get('nova.settings'))['nova.settings'] as Settings
      ).sessions.some((s: { name: string }) => s.name === 'Suite QA'),
    ),
  );
  await tabAction('close', { id: duplicateId });
  await tabAction('reopen');
  assert.equal(
    await worker.evaluate(() => chrome.tabs.query({}).then((v) => v.length)),
    before + 1,
  );
  await worker.evaluate(async () => {
    const s = (await chrome.storage.local.get('nova.settings'))['nova.settings'] as Settings;
    s.suite.website.enabled = true;
    s.suite.website.performance = 'economical';
    await chrome.storage.local.set({ 'nova.settings': s });
  });
  const large = await context.newPage();
  await large.goto(url + '/large');
  await large.waitForFunction(() => !!document.querySelector('[data-nova-engine]'));
  await large.waitForTimeout(2200);
  const largeId = await worker.evaluate(
    async (u) => (await chrome.tabs.query({ url: u }))[0].id!,
    large.url(),
  );
  report.large = await worker.evaluate(
    (id) => chrome.tabs.sendMessage(id, { type: 'nova-metrics' }, { frameId: 0 }),
    largeId,
  );
  report.errors = errors;
  assert.deepEqual(errors, []);
  report.checks = [
    'actual chrome.tabs.create New Tab',
    '5 opening styles',
    'settings no replay',
    'palette keyboard',
    'website tokens',
    'distinct surfaces',
    'media/editor/auth preservation',
    'shadow roots',
    'SPA mutation',
    'focus picker rules',
    'inspector preview / undo / redo / persisted override',
    'disable restores original',
    'manager search/duplicate',
    'independent header/clock/terminal/widget targets',
    'native pin/mute/move/group/workspace/save/close/reopen',
    '2500-node economical budget',
  ];
  writeFileSync('work/v3-report.json', JSON.stringify(report, null, 2));
  console.log('NØVA 3 browser checks passed.');
} finally {
  await context.close();
  await new Promise<void>((r) => server.close(() => r()));
}
