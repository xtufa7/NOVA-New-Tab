import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { resolve } from 'node:path';
import { gzipSync } from 'node:zlib';
import assert from 'node:assert/strict';
const engines = ['powershell.exe', 'C:/Users/KiT/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'];
const stamp = Date.now();
for (const [i, engine] of engines.entries()) {
 const root = resolve(`work/bootstrap Ø ${stamp}-${i}`); mkdirSync(root, {recursive:true});
 const host = `com.xtufa7.nova.bootstrapt${stamp}${i}`;
 const installer = readFileSync('native/install.ps1','utf8').replaceAll('com.xtufa7.nova.spotify', host);
 const script = readFileSync('native/bootstrap.ps1','utf8').replace(/('install.ps1' = ')[^']+/, '$1' + gzipSync(Buffer.from(installer)).toString('base64'));
 const file = resolve(root,'bootstrap.ps1'); writeFileSync(file, script);
 const run = args => spawnSync(engine, ['-NoProfile','-ExecutionPolicy','Bypass','-File',file,'-InstallDirectory',root,...args],{encoding:'utf8',cwd:process.env.SystemRoot + '/System32'});
 try {
  const r = run(['-ExtensionId','d'.repeat(32)]); assert.equal(r.status,0,r.stderr); assert(r.stdout.includes('Setup complete'));
  for (const f of ['spotify-bridge.ps1','launch.cmd','setup.cmd']) assert.deepEqual(readFileSync(resolve(root,f)),readFileSync('native/'+f));
  const chromium = JSON.parse(readFileSync(resolve(root,'host-chromium.json'),'utf8'));
  assert(chromium.allowed_origins.includes(`chrome-extension://${'d'.repeat(32)}/`));
  assert.equal(chromium.path,resolve(root,'launch.cmd'));
  assert.deepEqual(JSON.parse(readFileSync(resolve(root,'host-firefox.json'),'utf8')).allowed_extensions,['nova@xtufa7']);
  const upgraded = resolve(root,'upgrade Ø');
  const update = spawnSync(engine,['-NoProfile','-ExecutionPolicy','Bypass','-File',file,'-InstallDirectory',upgraded,'-ExtensionId','e'.repeat(32)],{encoding:'utf8'});
  assert.equal(update.status,0,update.stderr);
  const ids = JSON.parse(readFileSync(resolve(upgraded,'host-chromium.json'),'utf8')).allowed_origins;
  assert(ids.includes(`chrome-extension://${'d'.repeat(32)}/`) && ids.includes(`chrome-extension://${'e'.repeat(32)}/`));
  const uninstall = spawnSync(engine,['-NoProfile','-ExecutionPolicy','Bypass','-File',file,'-InstallDirectory',upgraded,'-Uninstall'],{encoding:'utf8'});
  assert.equal(uninstall.status,0,uninstall.stderr);
 } finally {
  const removed = run(['-Uninstall']); assert.equal(removed.status,0,removed.stderr);
 }
}
writeFileSync('work/bootstrap-report.json',JSON.stringify({version:'3.0.0',engines:['Windows PowerShell 5.1','PowerShell 7'],system32Cwd:true,unicodeAndSpaces:true,standalonePayloadExact:true,registeredAndRemoved:true},null,2));
console.log('Standalone bootstrap passed on PS 5.1 and 7: all-browser isolated registration, exact payload, System32 cwd, Unicode path, uninstall.');
