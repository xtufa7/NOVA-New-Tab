import { test } from 'node:test';
import assert from 'node:assert/strict';
import { parseLRC, lyricIndex, revealedLyric } from '../src/music/lyrics';
import { validateSettings } from '../src/storage/settings';
import { defaults } from '../src/settings/schema';
test('LRC supports duplicate timestamps, fractions, offset and seeking', () => {
  const lines = parseLRC(
    '[ar:Local artist]\n[offset:-500]\n[00:01.50][00:10.050]Repeat\n[00:02]Next\n[00:99]Invalid',
  );
  assert.deepEqual(lines, [
    { time: 1, text: 'Repeat' },
    { time: 1.5, text: 'Next' },
    { time: 9.55, text: 'Repeat' },
  ]);
  assert.equal(lyricIndex(lines, 0.9), -1);
  assert.equal(lyricIndex(lines, 1), 0);
  assert.equal(lyricIndex(lines, 12), 2);
  assert.equal(lyricIndex(lines, 1.4), 0);
});
test('v2 backup keeps music and receives independent v3 defaults', () => {
  const raw = JSON.parse(JSON.stringify(defaults()));
  raw.schemaVersion = 2;
  delete raw.fonts;
  delete raw.integrations;
  delete raw.companion;
  raw.profiles[0].appearance.clockCaption = 'My caption';
  delete raw.profiles[0].appearance.clockSpacing;
  const upgraded = validateSettings(raw);
  assert.equal(upgraded.schemaVersion, 7);
  assert.equal(upgraded.profiles[0].appearance.clockCaption, 'My caption');
  assert.equal(upgraded.integrations.spotifySource, 'web');
  assert.equal(upgraded.companion.enabled, false);
  assert.equal(upgraded.profiles[0].appearance.clockSpacing, -0.06);
  const invalid = defaults();
  invalid.integrations.lyricsOffset = 99;
  assert.throws(() => validateSettings(invalid));
});

test('enhanced LRC uses real word timestamps and line-only LRC labels estimates', () => {
  const exact = parseLRC('[00:02]<00:02.50>Hello <00:03.00>world\n[00:05]Next');
  assert.equal(revealedLyric(exact, 2.1).text, '');
  assert.equal(revealedLyric(exact, 2.6).text, 'Hello');
  assert.equal(revealedLyric(exact, 3).text, 'Hello world');
  assert.equal(revealedLyric(exact, 3).exact, true);
  const estimated = parseLRC('[00:02]Hello world\n[00:04]Next');
  assert.equal(revealedLyric(estimated, 2).text, 'Hello');
  assert.equal(revealedLyric(estimated, 3).text, 'Hello world');
  assert.equal(revealedLyric(estimated, 3).exact, false);
  assert.equal(revealedLyric(exact, 1).text, '');
});
