import { createServer } from 'node:http';
import { spawn, spawnSync } from 'node:child_process';
import { writeFileSync, readFileSync, readdirSync, mkdirSync } from 'node:fs';
import { resolve, relative } from 'node:path';
import { zipSync } from 'fflate';
import assert from 'node:assert/strict';
const siteServer = createServer((_req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/html' });
  res.end(
    '<title>Gecko theme fixture</title><body style="background:#ffffff;color:#111111"><main style="background:#dddddd">Theme fixture <canvas id="chart" style="background:red"></canvas></main></body>',
  );
});
await new Promise((r) => siteServer.listen(0, '127.0.0.1', r));
const siteURL = 'http://127.0.0.1:' + siteServer.address().port;
const driver = spawn(
  resolve('work/geckodriver/geckodriver.exe'),
  ['--port', '4447', '--allow-system-access'],
  { stdio: 'pipe' },
);
driver.stderr.on('data', () => {});
driver.stdout.on('data', () => {});
const call = async (path, body, method = 'POST') => {
  const r = await fetch('http://127.0.0.1:4447' + path, {
    method,
    headers: { 'Content-Type': 'application/json' },
    ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
  });
  const v = await r.json();
  if (v.value?.error) throw new Error(JSON.stringify(v));
  return v.value;
};
const files = (dir) =>
  readdirSync(dir, { withFileTypes: true }).flatMap((e) =>
    e.isDirectory() ? files(resolve(dir, e.name)) : [resolve(dir, e.name)],
  );
const nativeHost = 'com.xtufa7.nova.test' + Date.now();
const nativeKey = `HKCU:\\Software\\Mozilla\\NativeMessagingHosts\\${nativeHost}`;
const ps = (command) => {
  const r = spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', command], {
    encoding: 'utf8',
  });
  assert.equal(r.status, 0, r.stderr);
};
const q = (s) => "'" + s.replaceAll("'", "''") + "'";
const nativeManifest = resolve('work', nativeHost + '.json');
writeFileSync(
  nativeManifest,
  JSON.stringify({
    name: nativeHost,
    description: 'NOVA isolated Gecko native test',
    path: resolve('native/launch.cmd'),
    type: 'stdio',
    allowed_extensions: ['nova@xtufa7'],
  }),
);
ps(
  `if(Test-Path -LiteralPath ${q(nativeKey)}){throw 'Test key exists'};New-Item -Path ${q(nativeKey)} -Force | Out-Null;Set-Item -LiteralPath ${q(nativeKey)} -Value ${q(nativeManifest)}`,
);
const xpi = resolve('work/nova-gecko-test.xpi');
writeFileSync(
  xpi,
  zipSync(
    Object.fromEntries(
      files(resolve('dist-firefox')).map((p) => [
        relative(resolve('dist-firefox'), p).replaceAll('\\', '/'),
        new Uint8Array(
          p.endsWith('background.js')
            ? Buffer.from(readFileSync(p, 'utf8').replaceAll('com.xtufa7.nova.spotify', nativeHost))
            : p.endsWith('manifest.json')
              ? Buffer.from(
                  (() => {
                    const m = JSON.parse(readFileSync(p, 'utf8'));
                    m.permissions.push('nativeMessaging', 'tabs', 'sessions');
                    m.host_permissions.push('http://127.0.0.1/*');
                    m.optional_permissions = m.optional_permissions.filter(
                      (v) => !['nativeMessaging', 'tabs', 'sessions'].includes(v),
                    );
                    return JSON.stringify(m);
                  })(),
                )
              : readFileSync(p),
        ),
      ]),
    ),
  ),
);
let id;
const reports = [];
try {
  await new Promise((r) => setTimeout(r, 1000));
  for (const [name, binary] of [
    ['Firefox', 'C:\\Program Files\\Mozilla Firefox\\firefox.exe'],
    ['Zen', 'C:\\Program Files\\Zen Browser\\zen.exe'],
  ]) {
    const uuid = '934bcdbe-6a6a-4c58-8927-22a1125cf80d';
    const session = await call('/session', {
      capabilities: {
        alwaysMatch: {
          browserName: 'firefox',
          'moz:firefoxOptions': {
            binary,
            args: ['-headless', '-no-remote', '-new-instance'],
            prefs: {
              'extensions.webextensions.uuids': JSON.stringify({ 'nova@xtufa7': uuid }),
              'browser.shell.checkDefaultBrowser': false,
              'media.autoplay.default': 0,
            },
          },
        },
      },
    });
    id = session.sessionId;
    console.log(name, 'launched', session.capabilities.browserVersion);
    await call(`/session/${id}/moz/addon/install`, { path: xpi, temporary: true });
    await call(`/session/${id}/moz/context`, { context: 'chrome' });
    await call(`/session/${id}/execute/sync`, {
      script:
        'gBrowser.selectedTab = gBrowser.addTab(arguments[0], {triggeringPrincipal: Services.scriptSecurityManager.getSystemPrincipal()});',
      args: [`moz-extension://${uuid}/newtab.html`],
    });
    await call(`/session/${id}/moz/context`, { context: 'content' });
    const handles = await call(`/session/${id}/window/handles`, undefined, 'GET');
    await call(`/session/${id}/window`, { handle: handles[handles.length - 1] });
    await new Promise((r) => setTimeout(r, 1800));
    const script = async (script, args = []) =>
      call(`/session/${id}/execute/sync`, { script, args });
    const state = await script(
      "return {ready:!!performance.getEntriesByName('nova-ready').length,url:location.href,body:document.body.innerText.slice(0,200),clock:document.querySelector('#clock')?.textContent,api:!!globalThis.chrome?.storage};",
    );
    console.log(state);
    assert(state.ready);
    assert(state.api);
    await script("document.querySelector('#settings-toggle').click();");
    await new Promise((r) => setTimeout(r, 400));
    await script(
      "[...document.querySelectorAll('button')].find(n=>n.textContent==='Music').click();",
    );
    const asyncScript = async (script, args = []) =>
      call(`/session/${id}/execute/async`, { script, args });
    await script(
      "const f=document.querySelector('[aria-label=\"Mini player widget\"]');f.checked=false;f.dispatchEvent(new Event('change',{bubbles:true}));",
    );
    await new Promise((r) => setTimeout(r, 600));
    const nativeStatus = await asyncScript(
      "const done=arguments[arguments.length-1]; (async()=>{const s=(await chrome.storage.local.get('nova.settings'))['nova.settings'];s.integrations.desktopBridge=true;s.integrations.spotify=true;s.integrations.spotifySource='desktop';await chrome.storage.local.set({'nova.settings':s});let status;for(let i=0;i<80;i++){status=(await chrome.storage.session.get('nova.desktop.status'))['nova.desktop.status'];if(status?.state?.startsWith('connected'))break;await new Promise(r=>setTimeout(r,250));}return status;})().then(done,e=>done({error:e.message}));",
    );
    console.log(name, 'native', nativeStatus);
    assert(nativeStatus.state?.startsWith('connected'), JSON.stringify(nativeStatus));
    const wav = readFileSync('work/lyrics-test.wav').subarray(0, 44 + 88200);
    wav.writeUInt32LE(wav.length - 8, 4);
    wav.writeUInt32LE(wav.length - 44, 40);
    await asyncScript(
      "const data=arguments[0],done=arguments[arguments.length-1];(async()=>{const id=crypto.randomUUID();await new Promise((res,rej)=>{const r=indexedDB.open('nova-media',1);r.onupgradeneeded=()=>r.result.createObjectStore('blobs');r.onerror=()=>rej(r.error);r.onsuccess=()=>{const tx=r.result.transaction('blobs','readwrite');tx.objectStore('blobs').put(new Blob([Uint8Array.from(atob(data),c=>c.charCodeAt(0))],{type:'audio/wav'}),id);tx.oncomplete=res;tx.onerror=()=>rej(tx.error);};});const s=(await chrome.storage.local.get('nova.settings'))['nova.settings'];s.profiles[0].music.tracks=[{id,title:'Fixture',artist:'Test',coverId:'',playlist:'Library'}];await chrome.storage.local.set({'nova.settings':s});return true;})().then(done,e=>done({error:e.message}));",
      [wav.toString('base64')],
    );
    const audioStatus = await asyncScript(
      "const done=arguments[arguments.length-1]; chrome.runtime.sendMessage({target:'worker',type:'music',action:'play'}).then(done,e=>done({error:e.message}));",
    );
    assert(!audioStatus.error, JSON.stringify(audioStatus));
    assert.equal(audioStatus.playing, true);
    const audioTab = await asyncScript(
      "const done=arguments[arguments.length-1];chrome.tabs.query({url:chrome.runtime.getURL('offscreen.html')}).then(done);",
    );
    assert.equal(audioTab.length, 1);
    const stop = await asyncScript(
      "const done=arguments[arguments.length-1];chrome.runtime.sendMessage({target:'worker',type:'music',action:'stop'}).then(done,e=>done({error:e.message}));",
    );
    assert(!stop?.error);
    const remaining = await asyncScript(
      "const done=arguments[arguments.length-1];chrome.tabs.query({url:chrome.runtime.getURL('offscreen.html')}).then(done);",
    );
    assert.equal(remaining.length, 0);
    const music = await script(
      "return {animation:document.querySelector('[aria-label=\"Lyrics animation\"]')?.value,warning:document.querySelector('.native-warning')?.textContent,commands:document.querySelector('.native-commands')?.textContent};",
    );
    assert.equal(music.animation, 'rise+blur');
    assert(music.warning.includes('outside'));
    assert(music.commands.includes("NOVA_BROWSER='all'"));
    await script(
      "[...document.querySelectorAll('button')].find(n=>n.textContent==='About').click();",
    );
    assert.equal(
      await script(
        "return [...document.querySelectorAll('button')].some(n=>/Upload Guns|Follow my Guns/.test(n.textContent));",
      ),
      false,
    );
    const screenshot = await call(`/session/${id}/screenshot`, undefined, 'GET');
    writeFileSync(`work/NOVA-3.0.0-${name.toLowerCase()}.png`, Buffer.from(screenshot, 'base64'));
    const managerResult = await asyncScript(
      "const done=arguments[arguments.length-1];chrome.runtime.sendMessage({target:'worker',type:'suite-tabs'}).then(v=>done({count:v.tabs?.length,error:v.error}),e=>done({error:e.message}));",
    );
    assert(managerResult.count >= 1, JSON.stringify(managerResult));
    await asyncScript(
      "const done=arguments[arguments.length-1];(async()=>{const s=(await chrome.storage.local.get('nova.settings'))['nova.settings'];s.suite.website.enabled=true;s.entrance.enabled=true;s.entrance.respectSystem=false;s.performance.lowPower=false;await chrome.storage.local.set({'nova.settings':s});return true;})().then(done,e=>done({error:e.message}));",
    );
    const previousHandles = await call(`/session/${id}/window/handles`, undefined, 'GET');
    await call(`/session/${id}/moz/context`, { context: 'chrome' });
    await call(`/session/${id}/execute/sync`, {
      script:
        'if(typeof BrowserCommands!=="undefined"&&BrowserCommands.openTab)BrowserCommands.openTab(arguments[0]==="Zen"?{url:BROWSER_NEW_TAB_URL}:{});else BrowserOpenTab();',
      args: [name],
    });
    await call(`/session/${id}/moz/context`, { context: 'content' });
    let addedHandle;
    for (let attempt = 0; attempt < 40; attempt++) {
      const newHandles = await call(`/session/${id}/window/handles`, undefined, 'GET');
      addedHandle = newHandles.find((handle) => !previousHandles.includes(handle));
      if (addedHandle) break;
      await new Promise((r) => setTimeout(r, 150));
    }
    assert(addedHandle, 'Browser UI must create a new tab');
    await call(`/session/${id}/window`, { handle: addedHandle });
    let actualOpening;
    for (let attempt = 0; attempt < 40; attempt++) {
      actualOpening = await script(
        "return {ready:!!performance.getEntriesByName('nova-ready').length,opening:!!performance.getEntriesByName('nova-opening-start').length,url:location.href,visible:!document.hidden};",
      );
      if (actualOpening.ready && actualOpening.opening) break;
      await new Promise((r) => setTimeout(r, 150));
    }
    assert(actualOpening.ready && actualOpening.opening, JSON.stringify(actualOpening));
    await call(`/session/${id}/url`, { url: siteURL });
    let themeState;
    for (let attempt = 0; attempt < 40; attempt++) {
      themeState = await script(
        "return {engine:!!document.querySelector('[data-nova-engine]'),bg:getComputedStyle(document.body).backgroundColor,chart:document.querySelector('#chart')?.getAttribute('style')};",
      );
      if (themeState.bg === 'rgb(30, 30, 46)') break;
      await new Promise((r) => setTimeout(r, 150));
    }
    assert(themeState.engine && themeState.bg === 'rgb(30, 30, 46)', JSON.stringify(themeState));
    assert.equal(themeState.chart, 'background:red');
    reports.push({
      browser: name,
      version: session.capabilities.browserVersion,
      newtab: state,
      suite: {
        actualOpening,
        openingMethod:
          name === 'Zen'
            ? 'Native BrowserCommands with browser-resolved New Tab URL; default Zen command opens URL bar'
            : 'Native BrowserCommands.openTab()',
        themeState,
        tabManager: managerResult,
      },
      settings: 'Music, native warning, preview, About buttons removed',
      native: nativeStatus.state,
      audio: 'actual WAV playback returned playing=true; stop removed audio tab',
    });
    await call(`/session/${id}`, undefined, 'DELETE');
    id = undefined;
  }
  writeFileSync('work/gecko-report.json', JSON.stringify(reports, null, 2));
} finally {
  if (id) await call(`/session/${id}`, undefined, 'DELETE').catch(() => {});
  driver.kill();
  siteServer.close();
  ps(`if(Test-Path -LiteralPath ${q(nativeKey)}){Remove-Item -LiteralPath ${q(nativeKey)}}`);
}
