import {readFileSync,writeFileSync,readdirSync,mkdirSync} from 'node:fs';
import {resolve,relative} from 'node:path';
import {spawnSync} from 'node:child_process';
import {zipSync} from 'fflate';
import assert from 'node:assert/strict';
const files=dir=>readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?files(resolve(dir,e.name)):[resolve(dir,e.name)]);
const fixture=resolve('work/setup fixture Ø '+Date.now());mkdirSync(fixture,{recursive:true});
const contents={'repo-main/manifest.json':new Uint8Array(readFileSync('manifest.json')),'repo-main/native/bootstrap.ps1':new Uint8Array(readFileSync('native/bootstrap.ps1'))};
for(const dir of ['dist','dist-firefox'])for(const file of files(resolve(dir)))contents[`repo-main/${dir}/${relative(resolve(dir),file).replaceAll('\\','/')}`]=new Uint8Array(readFileSync(file));
const zip=resolve(fixture,'source.zip');writeFileSync(zip,zipSync(contents));
const engines=['powershell.exe','C:/Users/KiT/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'];
for(const [i,engine]of engines.entries()){
 const install=resolve(fixture,'install '+i);
 const run=args=>spawnSync(engine,['-NoProfile','-ExecutionPolicy','Bypass','-File',resolve('setup.ps1'),'-InstallRoot',install,...args],{encoding:'utf8',cwd:process.env.SystemRoot+'/System32'});
 const dry=run(['-DryRun']);assert.equal(dry.status,0,dry.stderr);const plan=JSON.parse(dry.stdout);assert.equal(plan.RegistryChanges,0);assert(plan.DetectedBrowsers.some(b=>b.Browser==='helium'));assert(plan.DetectedBrowsers.some(b=>b.Family==='firefox'));
 const args=['-ArchivePath',zip,'-PrepareOnly'];const ready=run(args);assert.equal(ready.status,0,ready.stderr);
 for(const family of ['chromium','firefox'])assert.equal(JSON.parse(readFileSync(resolve(install,'Extensions',family,'manifest.json'),'utf8')).version,'3.0.0');
 writeFileSync(resolve(install,'Extensions/chromium/keep.txt'),'user fixture');
 const update=run(args);assert.equal(update.status,0,update.stderr);assert.equal(readFileSync(resolve(install,'Extensions/chromium/keep.txt'),'utf8'),'user fixture');
 assert.equal(JSON.parse(readFileSync(resolve(install,'setup-report.json'),'utf8')).BridgeStatus,'Not run');
 const hostile=resolve(fixture,`unsafe-${i}.zip`);writeFileSync(hostile,zipSync({'../escape.txt':new Uint8Array([1])}));
 const rejected=run(['-ArchivePath',hostile,'-PrepareOnly']);assert.notEqual(rejected.status,0);assert(rejected.stderr.includes('Unsafe archive path'));
}
writeFileSync('work/setup-report.json',JSON.stringify({version:'3.0.0',windowsPowerShell51:true,powerShell7:true,realBrowserDetection:true,githubArchiveLayout:true,correctBuildFamilies:true,stableUpdatePath:true,userFilesPreserved:true,unsafeArchiveRejected:true,registryChanges:0,browserLaunches:0,network:'offline GitHub-layout fixture; live repository download awaits publication'},null,2));
console.log('Setup passed on PS5/PS7: browser detection, GitHub-layout archive, Chromium/Gecko selection, stable update, unsafe ZIP rejection; no live installation or registry changes.');
