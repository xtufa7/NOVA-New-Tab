import { chromium } from 'playwright';
import { cpSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { spawnSync } from 'node:child_process';
import assert from 'node:assert/strict';
import { defaults } from '../src/settings/schema';
const stamp = Date.now(),
  dir = resolve(`work/v15-native-${stamp}`),
  host = `com.xtufa7.nova.test${stamp}`;
cpSync('dist', dir, { recursive: true });
const manifest = JSON.parse(readFileSync(resolve(dir, 'manifest.json'), 'utf8'));
manifest.permissions.push('nativeMessaging');
manifest.optional_permissions = manifest.optional_permissions.filter(
  (p: string) => p !== 'nativeMessaging',
);
writeFileSync(resolve(dir, 'manifest.json'), JSON.stringify(manifest));
writeFileSync(
  resolve(dir, 'background.js'),
  readFileSync(resolve(dir, 'background.js'), 'utf8').replaceAll('com.xtufa7.nova.spotify', host),
);
const context = await chromium.launchPersistentContext(resolve(`work/v15-profile-${stamp}`), {
  executablePath: process.env.NOVA_BROWSER,
  channel: 'chromium',
  headless: true,
  args: [`--disable-extensions-except=${dir}`, `--load-extension=${dir}`],
  viewport: { width: 1440, height: 1000 },
});
const key = `HKCU:\\Software\\Google\\Chrome\\NativeMessagingHosts\\${host}`;
const ps = (command: string) => {
  const r = spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', command], {
    encoding: 'utf8',
  });
  assert.equal(r.status, 0, r.stderr);
};
const quote = (s: string) => "'" + s.replaceAll("'", "''") + "'";
try {
  const worker = context.serviceWorkers()[0] ?? (await context.waitForEvent('serviceworker'));
  const id = new URL(worker.url()).host;
  const hostPath = resolve(dir, 'test-host.json');
  writeFileSync(
    hostPath,
    JSON.stringify({
      name: host,
      description: 'NOVA isolated native test',
      path: resolve('native/launch.cmd'),
      type: 'stdio',
      allowed_origins: [`chrome-extension://${id}/`],
    }),
  );
  ps(
    `if(Test-Path -LiteralPath ${quote(key)}){throw 'Test key unexpectedly exists'}; New-Item -Path ${quote(key)} -Force | Out-Null; Set-Item -LiteralPath ${quote(key)} -Value ${quote(hostPath)}`,
  );
  const s = defaults();
  s.integrations.desktopBridge = true;
  s.integrations.spotify = true;
  s.integrations.spotifySource = 'desktop';
  await worker.evaluate((s) => chrome.storage.local.set({ 'nova.settings': s }), s);
  const page = await context.newPage();
  await page.goto(`chrome-extension://${id}/newtab.html`);
  await page.waitForFunction(() => !!performance.getEntriesByName('nova-ready').length);
  let status = '';
  for (let i = 0; i < 30; i++) {
    status = await worker.evaluate(
      async () =>
        (
          (await chrome.storage.session.get('nova.desktop.status'))['nova.desktop.status'] as {
            state: string;
          }
        )?.state,
    );
    if (status?.startsWith('connected')) break;
    await page.waitForTimeout(300);
  }
  assert(status?.startsWith('connected'), status);
  const state = await worker.evaluate(
    async () => (await chrome.storage.session.get('nova.spotify.desktop'))['nova.spotify.desktop'],
  );
  console.log('Real native host connected:', JSON.stringify(state));
  await page.locator('#settings-toggle').click();
  await page.getByRole('button', { name: 'About', exact: true }).click();
  assert.equal(await page.getByRole('button', { name: /Upload Guns|Follow my Guns/ }).count(), 0);
  await page.getByRole('button', { name: 'Profiles', exact: true }).click();
  await page.getByLabel('New profile name').fill('Studio');
  await page.getByRole('button', { name: 'Create workspace', exact: true }).click();
  assert.equal(await page.locator('.profile-card').count(), s.profiles.length + 1);
  const studio = page.locator('.profile-card').filter({ hasText: 'Studio' });
  assert.equal(await studio.getAttribute('data-active'), 'true');
  await studio.getByText('Rename workspace', { exact: true }).click();
  await page.getByLabel('Rename Studio', { exact: true }).fill('Focus');
  await studio.getByRole('button', { name: 'Save name', exact: true }).click();
  assert.equal(await page.locator('.profile-card').filter({ hasText: 'Focus' }).count(), 1);
  await page.getByRole('button', { name: 'Privacy', exact: true }).click();
  await page.getByText('Browser permissions', { exact: true }).click();
  assert.equal(await page.locator('.permission-card').count(), 4);
  await page.getByRole('button', { name: 'Music', exact: true }).click();
  await page.getByText('Spotify desktop · optional Windows PowerShell', { exact: true }).click();
  assert.equal(
    await page.getByLabel('Browser for PowerShell registration').locator('option').count(),
    10,
  );
  assert.equal(await page.getByLabel('Browser for PowerShell registration').inputValue(), 'all');
  assert(!/[\u0600-\u06ff]/.test(await page.locator('.native-warning').innerText()));
  await page.getByLabel('Browser for PowerShell registration').selectOption('firefox');
  assert((await page.locator('.native-commands').innerText()).includes('nova@xtufa7'));
  await page.getByLabel('Browser for PowerShell registration').selectOption('all');
  await page.getByRole('button', { name: 'Music', exact: true }).click();
  await page.getByText('Lyrics animation preview', { exact: true }).click();
  for (const mode of ['rise', 'rise+blur', 'fade', 'blur', 'typewriter', 'none']) {
    await page.getByLabel('Lyrics animation', { exact: true }).selectOption(mode);
    assert(await page.locator('.lyrics-preview').isVisible());
    assert.equal(await page.locator('.lyrics-preview').getAttribute('data-animation'), mode);
    await page.evaluate(() => {
      document.body.dataset.animations = 'off';
    });
    const frames = await page
      .locator('.lyrics-preview .lyric-word')
      .first()
      .evaluate((n) =>
        n.getAnimations({ subtree: true }).map((a) => (a.effect as KeyframeEffect).getKeyframes()),
      );
    assert(mode === 'none' ? frames.length === 0 : frames.length > 0);
    if (mode === 'rise+blur')
      assert(
        frames.some(
          (f) =>
            String(f[0].filter).includes('blur') && String(f[0].transform).includes('translate'),
        ),
      );
    await page.getByRole('button', { name: 'Replay animation', exact: true }).click();
    assert.equal(await page.locator('.lyrics-preview .current').getAttribute('data-text'), 'Your');
  }
  await page.waitForFunction(
    () => document.querySelector('.lyrics-preview .current')?.getAttribute('data-line') === '1',
  );
  assert.equal(await page.locator('.lyrics-preview .lyric-out').count(), 0);
  await page.getByLabel('Lyrics animation', { exact: true }).selectOption('blur');
  assert(await page.locator('.lyrics-preview').isVisible());
  await page.waitForTimeout(700);
  assert((await page.locator('.lyrics-preview .lyric-word').count()) > 0);
  assert.equal(await page.locator('.lyrics-preview').getAttribute('data-animation'), 'blur');
  await page.evaluate(() => {
    const n = document.querySelector('.lyrics-preview .current')!;
    (window as any).__stableLine = n;
    (window as any).__stableWord = n.querySelector('.lyric-word');
  });
  await page.waitForTimeout(700);
  assert(
    await page.evaluate(
      () =>
        document.querySelector('.lyrics-preview .current') === (window as any).__stableLine &&
        document.querySelector('.lyrics-preview .lyric-word') === (window as any).__stableWord,
    ),
  );
  await page.getByText('Spotify desktop · optional Windows PowerShell', { exact: true }).click();
  await page.locator('.native-warning').scrollIntoViewIfNeeded();
  await page.screenshot({ path: 'work/NOVA-3.0.0-desktop-bridge.png' });
  await page.locator('.native-commands').scrollIntoViewIfNeeded();
  await page.screenshot({ path: 'docs/images/gallery/desktop-commands.png' });
  await page.getByRole('button', { name: 'Disable desktop bridge', exact: true }).click();
  await page.waitForTimeout(1000);
  assert.equal(
    await worker.evaluate(
      async () =>
        (
          (await chrome.storage.session.get('nova.desktop.status'))['nova.desktop.status'] as {
            state: string;
          }
        )?.state,
    ),
    'disabled',
  );
  assert.equal(
    await worker.evaluate(
      async () =>
        !!(await chrome.storage.session.get('nova.spotify.desktop'))['nova.spotify.desktop'],
    ),
    false,
  );
  mkdirSync('docs/images/gallery', { recursive: true });
  for (const section of [
    'Appearance',
    'Layout',
    'Widgets',
    'Shortcuts',
    'Terminal',
    'Music',
    'Floating Tabs',
    'Browser Companion',
    'Profiles',
    'Performance',
    'Privacy',
    'Backup',
    'Advanced',
    'About',
  ]) {
    await page.getByRole('button', { name: section, exact: true }).click();
    await page.evaluate(() =>
      document
        .querySelectorAll('details.settings-group')
        .forEach((n) => ((n as HTMLDetailsElement).open = true)),
    );
    await page.waitForTimeout(100);
    await page.screenshot({
      path: `docs/images/gallery/${section.toLowerCase().replaceAll(' ', '-')}.png`,
    });
    if (section === 'Appearance') {
      for (const [label, slug] of [
        ['Background & local media', 'background'],
        ['Custom font library', 'fonts'],
        ['Browser tab · title & GIF icon', 'tab-customization'],
        ['Custom colors & saved themes', 'custom-theme'],
      ]) {
        await page.evaluate(
          (label) =>
            document
              .querySelectorAll('details.settings-group')
              .forEach(
                (n) =>
                  ((n as HTMLDetailsElement).open =
                    n.querySelector('summary')?.textContent === label),
              ),
          label,
        );
        await page.getByText(label, { exact: true }).scrollIntoViewIfNeeded();
        await page.screenshot({ path: `docs/images/gallery/${slug}.png` });
      }
    }
    if (section === 'Music') {
      await page.locator('.lyrics-preview').scrollIntoViewIfNeeded();
      await page.getByLabel('Lyrics animation', { exact: true }).selectOption('rise+blur');
      await page.waitForTimeout(850);
      await page.screenshot({ path: 'work/NOVA-3.0.0-animation-preview.png' });
    }
  }
  await page.getByRole('button', { name: '×', exact: true }).click();
  await page.setViewportSize({ width: 1280, height: 800 });
  mkdirSync('docs/images/store', { recursive: true });
  await page.screenshot({ path: 'docs/images/store/newtab-1280x800.png' });
  await page.locator('#settings-toggle').click();
  await page.getByRole('button', { name: 'Music', exact: true }).click();
  await page.getByText('Lyrics animation preview', { exact: true }).click();
  await page.screenshot({ path: 'docs/images/store/music-1280x800.png' });
  const promo = await context.newPage();
  await promo.setViewportSize({ width: 440, height: 280 });
  await promo.setContent(
    '<html><body style="margin:0;width:440px;height:280px;background:radial-gradient(ellipse at top right,#493963,#17141e);color:#eee5ff;font-family:system-ui;box-sizing:border-box;padding:32px"><div style="font-size:14px;letter-spacing:5px;color:#c7a3ed">YOUR TIME. YOUR SPACE.</div><h1 style="font-size:68px;letter-spacing:10px;margin:18px 0 8px">NØVA</h1><p style="font-size:17px;color:#ccc3db;margin:0 0 25px">A New Tab that feels like you.</p><div style="display:flex;gap:8px;font-size:12px;color:#d9c4f2"><span>Clock</span><span>·</span><span>Themes</span><span>·</span><span>Music & lyrics</span></div><div style="margin-top:22px;color:#a699ba;font-size:11px">github.com/xtufa7</div></body></html>',
  );
  await promo.screenshot({ path: 'docs/images/store/promo-440x280.png' });
  await promo.close();
  await worker.evaluate(async () => {
    const s = (await chrome.storage.local.get('nova.settings'))['nova.settings'] as ReturnType<
      typeof defaults
    >;
    s.integrations.desktopBridge = true;
    await chrome.storage.local.set({ 'nova.settings': s });
  });
  await context.close();
  const restarted = await chromium.launchPersistentContext(resolve(`work/v15-profile-${stamp}`), {
    executablePath: process.env.NOVA_BROWSER,
    channel: 'chromium',
    headless: true,
    args: [`--disable-extensions-except=${dir}`, `--load-extension=${dir}`],
  });
  try {
    const restartedWorker =
      restarted.serviceWorkers()[0] ?? (await restarted.waitForEvent('serviceworker'));
    let startup = '';
    for (let i = 0; i < 40; i++) {
      startup = await restartedWorker.evaluate(
        async () =>
          (
            (await chrome.storage.session.get('nova.desktop.status'))['nova.desktop.status'] as {
              state: string;
            }
          )?.state,
      );
      if (startup?.startsWith('connected')) break;
      await new Promise((r) => setTimeout(r, 200));
    }
    assert(startup?.startsWith('connected'), startup);
    console.log('PowerShell connected automatically after actual browser restart.');
  } finally {
    await restarted.close();
  }
  writeFileSync(
    'work/v15-report.json',
    JSON.stringify(
      {
        version: '3.0.0',
        native:
          'Browser-launched PowerShell connected with valid metadata; disabling disconnects and removes state',
        preview:
          '6 modes change without closing; none rollover has no overlap; stable line and word DOM',
        about: 'both requested buttons removed',
        gallery: 14,
        profiles: 'Create and inline rename passed',
        privacy: 'Permission cards and status passed',
        browsers: 'All 10 options present; correct IDs by family',
        startup: 'Actual browser restart launched PowerShell automatically',
      },
      null,
      2,
    ),
  );
} finally {
  await context.close();
  ps(`if(Test-Path -LiteralPath ${quote(key)}){Remove-Item -LiteralPath ${quote(key)}}`);
}
