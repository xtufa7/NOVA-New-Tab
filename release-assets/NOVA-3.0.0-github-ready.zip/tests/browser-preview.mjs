import { chromium } from 'playwright';
import { spawn } from 'node:child_process';
import { createServer } from 'node:http';
import { resolve } from 'node:path';
import assert from 'node:assert/strict';
const reservation = createServer();
await new Promise((r) => reservation.listen(0, '127.0.0.1', r));
const port = reservation.address().port;
await new Promise((r) => reservation.close(r));
const server = spawn(
  process.execPath,
  [
    resolve('node_modules/vite/bin/vite.js'),
    '--host',
    '127.0.0.1',
    '--port',
    String(port),
    '--strictPort',
  ],
  { stdio: 'pipe' },
);
let browser;
let serverLog = '';
server.stdout.on('data', (d) => (serverLog += d));
server.stderr.on('data', (d) => (serverLog += d));
try {
  const url = `http://127.0.0.1:${port}/newtab.html`;
  let ready = false;
  for (let i = 0; i < 100; i++) {
    try {
      ready = (await fetch(url)).ok;
    } catch {}
    if (ready) break;
    await new Promise((r) => setTimeout(r, 100));
  }
  assert(ready, 'Vite preview did not start');
  browser = await chromium.launch({ executablePath: process.env.NOVA_BROWSER, headless: true });
  const page = await browser.newPage();
  const errors = [];
  const pending = new Set();
  page.on('request', (r) => pending.add(r.url()));
  page.on('requestfinished', (r) => pending.delete(r.url()));
  page.on('requestfailed', (r) => pending.delete(r.url()));
  page.on('pageerror', (e) => errors.push(e.message));
  page.on('requestfailed', (r) => console.log('Failed request', r.url(), r.failure()));
  await page.route('https://**/*', (route) => route.abort());
  await page.goto(url, { waitUntil: 'domcontentloaded' }).catch(async (e) => {
    console.log(
      'Preview navigation diagnostics',
      page.url(),
      serverLog,
      [...pending],
      await page.evaluate(() => ({
        state: document.readyState,
        body: document.body?.innerText,
        marks: performance.getEntriesByType('mark').map((m) => m.name),
      })),
    );
    throw e;
  });
  await page.waitForFunction(() => performance.getEntriesByName('nova-ready').length);
  await page.waitForFunction(() => performance.getEntriesByName('nova-opening-start').length);
  await page.locator('#settings-toggle').click();
  await page.getByRole('button', { name: 'Website Appearance', exact: true }).click();
  await page.getByText('Website access', { exact: true }).click();
  await page
    .getByText('Install the extension to grant browser access.', { exact: false })
    .waitFor();
  await page.keyboard.press('Escape');
  await page.keyboard.press('Alt+Shift+P');
  await page
    .getByText('Open NØVA as an installed extension to use browser actions.', { exact: true })
    .waitFor();
  await page.waitForTimeout(1100);
  assert.deepEqual(errors, []);
  console.log(
    'Non-extension developer preview passed: New Tab, opening, settings and browser-action gating; no unhandled errors.',
  );
} finally {
  await browser?.close();
  server.kill();
}
