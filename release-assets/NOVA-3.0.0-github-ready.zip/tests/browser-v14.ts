import { chromium } from 'playwright';
import { resolve } from 'node:path';
import { cpSync, readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { unzipSync, zipSync } from 'fflate';
import assert from 'node:assert/strict';
import { defaults, applyTheme } from '../src/settings/schema';
const dir = resolve('work/v14-extension-' + Date.now());
cpSync('dist', dir, { recursive: true });
const manifest = JSON.parse(readFileSync(resolve(dir, 'manifest.json'), 'utf8'));
manifest.permissions.push('tabs');
manifest.optional_permissions = manifest.optional_permissions.filter((p: string) => p !== 'tabs');
manifest.host_permissions = ['https://*/*']; // Only the disposable fixture pregrants optional origins.
writeFileSync(resolve(dir, 'manifest.json'), JSON.stringify(manifest));
const context = await chromium.launchPersistentContext(resolve('work/v14-browser-' + Date.now()), {
  channel: 'chromium',
  executablePath: process.env.NOVA_BROWSER,
  headless: true,
  args: [
    `--disable-extensions-except=${dir}`,
    `--load-extension=${dir}`,
    '--autoplay-policy=no-user-gesture-required',
  ],
  viewport: { width: 1440, height: 900 },
});
context.setDefaultTimeout(20000);
const errors: string[] = [],
  requests: string[] = [];
context.on('page', (p) => p.on('pageerror', (error) => errors.push(error.message)));
context.on('request', (r) => requests.push(r.url()));
try {
  const worker = context.serviceWorkers()[0] ?? (await context.waitForEvent('serviceworker'));
  for (
    let i = 0;
    i < 40 && !(await worker.evaluate(() => !!globalThis.chrome?.storage?.local));
    i++
  )
    await new Promise((r) => setTimeout(r, 100));
  const base = `chrome-extension://${new URL(worker.url()).host}`;
  const s = defaults();
  applyTheme(s.profiles[0], 'mocha');
  s.profiles[0].terminal.username = 'Tufa7';
  s.profiles[0].terminal.hostname = 'Nullium';
  s.integrations.spotify = s.integrations.onlineLyrics = true;
  await worker.evaluate((s) => chrome.storage.local.set({ 'nova.settings': s }), s);
  await context.route('https://lrclib.net/**', (r) =>
    r.fulfill({
      contentType: 'application/json',
      body: JSON.stringify({
        syncedLyrics: '[00:00]<00:00>One <00:05>two <00:08>three\n[00:20]Next line',
      }),
    }),
  );
  const page = await context.newPage();
  await page.goto(base + '/newtab.html');
  await page.waitForFunction(() => !!performance.getEntriesByName('nova-ready').length);
  await worker.evaluate(() =>
    chrome.storage.session.set({
      'nova.spotify': {
        title: 'Fixture',
        artist: 'Test',
        current: 0.2,
        duration: 180,
        playing: true,
        updatedAt: Date.now(),
      },
    }),
  );

  await page.waitForFunction(
    () => document.querySelector('.terminal-lyrics .current')?.textContent === 'One',
  );
  assert.equal(await page.locator('#terminal-input').getAttribute('placeholder'), '');
  assert.equal(await page.locator('.prompt-host').textContent(), '@Spotify');
  assert(!(await page.locator('#widget-lyrics').isVisible()));
  await page.waitForFunction(
    () => document.querySelector('.terminal-lyrics .current')?.textContent === 'One two',
  );
  await page.locator('#terminal-input').click();
  assert.equal(await page.locator('.prompt-host').textContent(), '@Nullium');
  assert(
    (await page.locator('#terminal-input').getAttribute('placeholder'))?.includes(
      'Search anything',
    ),
  );
  assert(!(await page.locator('.terminal-lyrics').isVisible()));
  assert(await page.locator('#widget-lyrics').isVisible());
  const order = await page.evaluate(() =>
    ['#widget-clock', '#widget-lyrics', '#widget-greeting'].map(
      (id) => document.querySelector(id)!.getBoundingClientRect().top,
    ),
  );
  assert(order[0] < order[1] && order[1] < order[2], JSON.stringify(order));
  await page.screenshot({ path: 'work/NOVA-3.0.0-lyrics-layout.png' });
  await page.locator('#terminal-input').blur();
  await page.waitForFunction(
    () => !document.querySelector<HTMLElement>('.terminal-lyrics')!.hidden,
  );
  await page.screenshot({ path: 'work/NOVA-3.0.0-lyrics-terminal.png' });
  await worker.evaluate(async () => {
    const s = (await chrome.storage.local.get('nova.settings'))['nova.settings'] as ReturnType<
      typeof defaults
    >;
    s.integrations.spotify = false;
    await chrome.storage.local.set({ 'nova.settings': s });
  });
  await page.locator('#settings-toggle').click();
  await page.getByRole('button', { name: 'About', exact: true }).click();
  await page.waitForFunction(() =>
    [...document.querySelectorAll<HTMLImageElement>('.account-avatar')].every(
      (img) => img.complete && img.naturalWidth > 10,
    ),
  );
  await page.screenshot({ path: 'work/NOVA-3.0.0-about.png' });
  await page.getByRole('button', { name: '×', exact: true }).click();

  // Actual GIF, WAV, PNG and synthetic WebM bytes go through the production portable backup UI.
  const gif = Buffer.from(
    '47494638396101000100800000ff00000000ff21ff0b4e45545343415045322e30030100000021f904000a0000002c000000000100010000020244010021f904000a0000002c00000000010001000002024c01003b',
    'hex',
  );
  const png = Buffer.from(
    'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQIHWP4z8DwHwAFgAI/ScLbtAAAAABJRU5ErkJggg==',
    'base64',
  );
  const wav = Buffer.alloc(44 + 44100 * 2);
  wav.write('RIFF');
  wav.writeUInt32LE(wav.length - 8, 4);
  wav.write('WAVEfmt ', 8);
  wav.writeUInt32LE(16, 16);
  wav.writeUInt16LE(1, 20);
  wav.writeUInt16LE(1, 22);
  wav.writeUInt32LE(44100, 24);
  wav.writeUInt32LE(88200, 28);
  wav.writeUInt16LE(2, 32);
  wav.writeUInt16LE(16, 34);
  wav.write('data', 36);
  wav.writeUInt32LE(wav.length - 44, 40);
  const media = await page.evaluate(
    async ({ gif, png, wav, videoBytes }) => {
      const video = new Blob([new Uint8Array(videoBytes)], { type: 'video/webm' });
      const files = [
        new Blob([new Uint8Array(gif)], { type: 'image/gif' }),
        new Blob([new Uint8Array(png)], { type: 'image/png' }),
        new Blob([new Uint8Array(wav)], { type: 'audio/wav' }),
        video,
      ];
      const ids = files.map(() => crypto.randomUUID());
      const db = await new Promise<IDBDatabase>((resolve, reject) => {
        const r = indexedDB.open('nova-media', 1);
        r.onupgradeneeded = () => r.result.createObjectStore('blobs');
        r.onsuccess = () => resolve(r.result);
        r.onerror = () => reject(r.error);
      });
      await new Promise<void>((resolve, reject) => {
        const tx = db.transaction('blobs', 'readwrite');
        files.forEach((b, i) => tx.objectStore('blobs').put(b, ids[i]));
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      });
      db.close();
      return { ids, videoBytes: [...new Uint8Array(await video.arrayBuffer())] };
    },
    {
      gif: [...gif],
      png: [...png],
      wav: [...wav],
      videoBytes: [...readFileSync('tests/fixtures/solid.webm')],
    },
  );
  await worker.evaluate(async (ids) => {
    const s = (await chrome.storage.local.get('nova.settings'))['nova.settings'] as ReturnType<
      typeof defaults
    >;
    s.tab = {
      title: 'TuFa7 · NØVA',
      animation: 'scroll',
      speed: 150,
      iconId: ids[0],
      animateIcon: true,
    };
    s.profiles[0].appearance.background = 'video';
    s.profiles[0].appearance.mediaId = ids[3];
    s.profiles[0].music.tracks = [
      {
        id: ids[2],
        title: 'Portable song',
        artist: 'xtufa7',
        coverId: ids[1],
        playlist: '',
        lyrics: '[00:00]Portable lyrics',
      },
    ];
    s.credits.gunsAvatarId = ids[1];
    await chrome.storage.local.set({ 'nova.settings': s });
  }, media.ids);
  await page.waitForFunction(() =>
    document.querySelector<HTMLLinkElement>('#nova-tab-icon')?.href.startsWith('data:image/png'),
  );
  const firstIcon = await page.locator('#nova-tab-icon').getAttribute('href');
  await page.waitForFunction(
    (previous) =>
      document.querySelector<HTMLLinkElement>('#nova-tab-icon')?.getAttribute('href') !== previous,
    firstIcon,
  );
  const firstTitle = await page.title();
  await page.waitForFunction((previous) => document.title !== previous, firstTitle);
  await page.waitForFunction(
    () => !!document.querySelector<HTMLVideoElement>('#background video')?.videoWidth,
  );
  await page.locator('#settings-toggle').click();
  await page.getByRole('button', { name: 'Appearance', exact: true }).click();
  await page.getByText('Browser tab · title & GIF icon', { exact: true }).click();
  await page.waitForFunction(
    () =>
      document.querySelector<HTMLImageElement>('.tab-help img')?.complete &&
      document.querySelector<HTMLImageElement>('.tab-help img')!.naturalWidth > 100,
  );
  await page.screenshot({ path: 'work/NOVA-3.0.0-tab-settings.png' });
  await page.getByRole('button', { name: 'Backup', exact: true }).click();
  const downloaded = page.waitForEvent('download');
  await page
    .getByRole('button', { name: 'Export full backup · media included', exact: true })
    .click();
  const archivePath = resolve('work/v14-full-backup.nova');
  await (await downloaded).saveAs(archivePath);
  const archive = unzipSync(readFileSync(archivePath));
  const meta = JSON.parse(new TextDecoder().decode(archive['nova.json']));
  assert.equal(meta.assets.length, 4);
  for (const asset of meta.assets)
    assert.equal(createHash('sha256').update(archive[asset.path]).digest('hex'), asset.sha256);
  assert(
    Buffer.from(archive[meta.assets.find((a: any) => a.id === media.ids[3]).path]).equals(
      Buffer.from(media.videoBytes),
    ),
  );
  // New settings + empty IndexedDB simulate installation on a different browser profile.
  await page.evaluate(async () => {
    const db = await new Promise<IDBDatabase>((resolve) => {
      const r = indexedDB.open('nova-media', 1);
      r.onsuccess = () => resolve(r.result);
    });
    await new Promise<void>((resolve) => {
      const tx = db.transaction('blobs', 'readwrite');
      tx.objectStore('blobs').clear();
      tx.oncomplete = () => resolve();
    });
    db.close();
  });
  await worker.evaluate((s) => chrome.storage.local.set({ 'nova.settings': s }), defaults());
  await page.reload();
  await page.waitForFunction(() => !!performance.getEntriesByName('nova-ready').length);
  await page.locator('#settings-toggle').click();
  await page.getByRole('button', { name: 'Backup', exact: true }).click();
  page.once('dialog', (dialog) => void dialog.accept());
  await page.getByLabel('Import full backup', { exact: true }).setInputFiles(archivePath);
  await page.getByText('Full backup restored.', { exact: true }).waitFor();
  const restored = await worker.evaluate(
    async () =>
      (await chrome.storage.local.get('nova.settings'))['nova.settings'] as ReturnType<
        typeof defaults
      >,
  );
  assert.equal(restored.tab.title, 'TuFa7 · NØVA');
  assert.notEqual(restored.tab.iconId, media.ids[0]);
  assert.equal(restored.profiles[0].music.tracks[0].lyrics, '[00:00]Portable lyrics');
  const restoredIds = [
    restored.tab.iconId,
    restored.credits.gunsAvatarId,
    restored.profiles[0].music.tracks[0].id,
    restored.profiles[0].appearance.mediaId,
  ];
  const bytes = await page.evaluate(async (ids) => {
    const db = await new Promise<IDBDatabase>((resolve) => {
      const r = indexedDB.open('nova-media', 1);
      r.onsuccess = () => resolve(r.result);
    });
    const blobs = await Promise.all(
      ids.map(
        (id) =>
          new Promise<Blob>((resolve) => {
            const r = db.transaction('blobs').objectStore('blobs').get(id);
            r.onsuccess = () => resolve(r.result);
          }),
      ),
    );
    db.close();
    return Promise.all(blobs.map(async (b) => [...new Uint8Array(await b.arrayBuffer())]));
  }, restoredIds);
  for (const [i, expected] of [gif, png, wav, Buffer.from(media.videoBytes)].entries())
    assert(Buffer.from(bytes[i]).equals(expected));
  // Corrupt one byte: hash verification must reject it before confirmation, settings or file mutation.
  archive[meta.assets[0].path][0] ^= 1;
  const corruptPath = resolve('work/v14-corrupt.nova');
  writeFileSync(corruptPath, zipSync(archive));
  let dialogs = 0;
  page.on('dialog', (d) => {
    dialogs++;
    void d.dismiss();
  });
  await page.getByLabel('Import full backup', { exact: true }).setInputFiles(corruptPath);
  await page
    .getByText('A media file is missing or corrupted. Import cancelled.', { exact: true })
    .waitFor();
  assert.equal(dialogs, 0);
  assert.deepEqual(
    await worker.evaluate(
      async () => (await chrome.storage.local.get('nova.settings'))['nova.settings'],
    ),
    restored,
  );
  await page.getByRole('button', { name: 'About', exact: true }).click();
  assert.equal(await page.locator('.account-card').count(), 2);
  assert.equal(
    await page.locator('.account-card a').nth(1).getAttribute('href'),
    'https://guns.lol/xtufa7',
  );
  await page.screenshot({ path: 'work/NOVA-3.0.0-about-restored.png' });
  console.log(
    'Word timing / focus / layout, actual GIF frames, title animation, full media restore and corruption rejection passed.',
  );

  // Production content script + native Document PiP. No capture substitution or helper is used here.
  await context.route('https://example.com/**', (r) =>
    r.request().url().endsWith('.webm')
      ? r.fulfill({ contentType: 'video/webm', body: readFileSync('tests/fixtures/solid.webm') })
      : r.fulfill({
          contentType: 'text/html',
          body: '<title>Video fixture</title><video id="actual-video" muted autoplay loop src="/solid.webm" style="width:320px;height:180px"></video>',
        }),
  );
  const web = await context.newPage();
  await web.goto('https://example.com/video');
  await worker.evaluate(async () => {
    const tabs = await chrome.tabs.query({ url: 'https://example.com/video' });
    await chrome.scripting.executeScript({
      target: { tabId: tabs[0].id! },
      files: ['site-pip.js'],
    });
  });
  await web.waitForSelector('#nova-direct-pin');
  const box = await web.locator('#nova-direct-pin').boundingBox();
  await web.mouse.click(box!.x + box!.width / 2, box!.y + 18);
  await web.waitForFunction(
    () =>
      !!(window as any).documentPictureInPicture.window?.document.querySelector('#actual-video'),
  );
  assert.equal(await web.locator('#actual-video').count(), 0);
  assert(
    await web.evaluate(
      () => !(window as any).documentPictureInPicture.window.document.querySelector('video').paused,
    ),
  );
  await web.evaluate(() =>
    [...(window as any).documentPictureInPicture.window.document.querySelectorAll('button')]
      .find((b: any) => b.textContent === 'Play / pause')
      .click(),
  );
  assert(
    await web.evaluate(
      () => (window as any).documentPictureInPicture.window.document.querySelector('video').paused,
    ),
  );
  await web.evaluate(() => (window as any).documentPictureInPicture.window.close());
  await web.waitForSelector('#actual-video');
  assert.equal(
    await web.locator('#actual-video').getAttribute('style'),
    'width:320px;height:180px',
  );
  assert(!(await web.locator('#actual-video').evaluate((v: HTMLVideoElement) => v.controls)));
  console.log(
    'Actual video moved to native PiP, playback controls worked, closing restored the original node and style.',
  );
  await context.route('https://guns.lol/xtufa7', (r) =>
    r.fulfill({
      contentType: 'text/html',
      body: '<title>Public avatar fixture</title><img width="120" height="120" src="https://r2.guns.lol/nova-fixture.webp">',
    }),
  );
  let referrer = '';
  await context.route('https://r2.guns.lol/nova-fixture.webp', async (r) => {
    referrer = (await r.request().allHeaders()).referer;
    await r.fulfill({ contentType: 'image/webp', body: readFileSync('public/accounts/guns.webp') });
  });
  await worker.evaluate(async () => {
    const s = (await chrome.storage.local.get('nova.settings'))['nova.settings'] as ReturnType<
      typeof defaults
    >;
    s.credits.syncGunsAvatar = true;
    s.credits.lastSync = 0;
    await chrome.storage.local.set({ 'nova.settings': s });
  });
  const profile = await context.newPage();
  await profile.goto('https://guns.lol/xtufa7');
  await page.waitForFunction(
    async () =>
      ((await chrome.storage.local.get('nova.settings'))['nova.settings'] as any).credits.lastSync >
      0,
  );
  assert(referrer.startsWith('https://guns.lol/'));
  let sessionRules = await worker.evaluate(() => chrome.declarativeNetRequest.getSessionRules());
  for (let i = 0; i < 40 && sessionRules.some(r => r.id === 919001); i++) {
    await new Promise(resolve => setTimeout(resolve, 100));
    sessionRules = await worker.evaluate(() => chrome.declarativeNetRequest.getSessionRules());
  }
  assert(!sessionRules.some(r => r.id === 919001));
  console.log(
    'Public Guns avatar synced with its website referrer; temporary session rule removed.',
  );
  assert(!requests.some((url) => /^https?:\/\/(127\.0\.0\.1|localhost)/.test(url)));
  assert.deepEqual(errors, []);
  writeFileSync(
    'work/v14-report.json',
    JSON.stringify(
      {
        version: '3.0.0',
        lyrics: 'word reveal, focus routing, layout order',
        backup:
          '4 real media files roundtripped byte-for-byte; corrupt archive rejected without mutation',
        tab: 'title animation, animated GIF frames, provided help image',
        pin: 'native Document PiP actual video move, controls and restore',
        avatar: 'public Guns image synced; exact-request referrer rule removed after fetch',
        helperRequests: 0,
        pageErrors: errors,
      },
      null,
      2,
    ),
  );
} finally {
  await context.close();
}
