import test from 'node:test';
import assert from 'node:assert/strict';
import { defaults } from '../src/settings/schema';
import { validateSettings } from '../src/storage/settings';
import {
  domain,
  matches,
  newSite,
  siteConfig,
  resolvePalette,
  hostPattern,
} from '../src/website/model';
import { palettes, validatePalette, validCSS } from '../src/themes/tokens';
import { color, luminance, contrast, composite, surface, readable } from '../src/website/color';
import { registry, searchCommands } from '../src/commands/registry';
test('schema 7 upgrade is lossless and suite defaults are independent', () => {
  const s = defaults();
  const raw = structuredClone(s) as Partial<typeof s>;
  raw.schemaVersion = 6 as 7;
  delete raw.suite;
  s.profiles[0].appearance.mediaId = 'personal-video';
  raw.profiles = s.profiles;
  const v = validateSettings(raw);
  assert.equal(v.profiles[0].appearance.mediaId, 'personal-video');
  assert.equal(v.schemaVersion, 7);
  assert.equal(v.suite.website.enabled, false);
  const a = defaults(),
    b = defaults();
  a.suite.website.sites.push(newSite('example.com'));
  assert.equal(b.suite.website.sites.length, 0);
});
test('domain rules use safe boundaries, priority and specificity', () => {
  assert.equal(domain('https://EXAMPLE.com/path'), 'example.com');
  assert.throws(() => domain('*.example.com'));
  assert.throws(() => domain('example.com/path'));
  const broad = { ...newSite('example.com'), subdomains: true, priority: 5 },
    specific = { ...newSite('app.example.com'), priority: 5 };
  assert(matches('app.example.com', broad));
  assert(!matches('evil-example.com', broad));
  const w = defaults().suite.website;
  w.sites = [broad, specific];
  assert.equal(siteConfig(w, 'app.example.com')?.id, specific.id);
  broad.priority = 6;
  assert.equal(siteConfig(w, 'app.example.com')?.id, broad.id);
});
test('theme and website imports reject remote and executable CSS', () => {
  for (const css of [
    '@import "https://evil.test";',
    'x{background:url(https://evil.test)}',
    'x{width:expression(alert(1))}',
    'x{background:image-set("https://evil.test" 1x)}',
    'x{\\75rl:test}',
  ])
    assert.throws(() => validCSS(css));
  const p = structuredClone(palettes[0]);
  p.tokens.accent = 'javascript:alert(1)';
  assert.throws(() => validatePalette(p));
  assert.doesNotThrow(() => validCSS('article { max-width: 70ch; }'));
});
test('effective colors, perceptual surfaces and readability retain hierarchy', () => {
  const t = palettes[0].tokens;
  assert.equal(luminance(color('#000000')!), 0);
  assert.equal(contrast(color('#ffffff')!, color('#000000')!), 21);
  assert.deepEqual(composite([255, 255, 255, 0.5], [0, 0, 0, 1]), [127.5, 127.5, 127.5, 1]);
  assert.notDeepEqual(surface(color('#111111')!, t), surface(color('#dddddd')!, t));
  assert(contrast(readable(color('#333333')!, color(t.base)!, 4.5, t), color(t.base)!) >= 4.5);
  assert.equal(t.base, '#1e1e2e');
  assert.equal(t.text, '#cdd6f4');
});
test('adaptive overnight schedules, priorities and manual overrides', () => {
  const s = defaults().suite;
  s.adaptive.enabled = true;
  s.adaptive.rules = [
    {
      id: 'night',
      name: 'Night',
      kind: 'time',
      start: '18:00',
      end: '07:00',
      system: 'dark',
      profile: 'default',
      palette: 'deep-purple',
      priority: 10,
      enabled: true,
    },
  ];
  assert.equal(resolvePalette(s, 'default', new Date(2026, 9, 11, 23)), 'deep-purple');
  assert.equal(resolvePalette(s, 'default', new Date(2026, 9, 11, 3)), 'deep-purple');
  assert.equal(resolvePalette(s, 'default', new Date(2026, 9, 11, 12)), 'mocha');
  s.adaptive.manualUntil = Date.now() + 60000;
  s.adaptive.manualPalette = 'latte';
  assert.equal(resolvePalette(s, 'default'), 'latte');
});
test('command search is safe, typed and bounded across 1000 tabs', () => {
  const s = defaults(),
    items = registry(
      s,
      Array.from({ length: 1000 }, (_, i) => ({
        id: i + 1,
        title: 'Project ' + i,
        url: 'https://example.com/' + i,
      })),
    );
  assert(searchCommands(items, 'proj999').some((v) => v.label === 'Project 999'));
  assert.equal(searchCommands(items, '<script>').length, 0);
  assert(searchCommands(items, '').length <= 60);
  assert(items.some((v) => v.id === 'settings:Backup'));
});
test('suite roundtrip includes custom palettes, rules, focus and tab assignments', () => {
  assert.equal(hostPattern('http://localhost:1234/path'), 'http://localhost/*');
  assert.throws(() => hostPattern('file:///tmp/test'));
  const s = defaults(),
    r = newSite('example.com');
  r.focus = ['aside'];
  r.elements = [{ selector: '#banner', preserve: false, colors: { base: '#111111' } }];
  s.suite.website.sites.push(r);
  s.suite.website.custom.push({ ...structuredClone(palettes[0]), id: 'mine' });
  s.suite.tabs.assignments['17'] = s.activeProfile;
  const v = validateSettings(JSON.parse(JSON.stringify(s)));
  assert.deepEqual(v.suite, s.suite);
  s.suite.website.sites[0].css = '@import "bad"';
  assert.throws(() => validateSettings(s));
});
