import { chromium, type Page } from 'playwright';
import { resolve, dirname } from 'node:path';
import { mkdirSync, writeFileSync, readFileSync, cpSync, rmSync } from 'node:fs';
import { defaults } from '../src/settings/schema';
import assert from 'node:assert/strict';
mkdirSync('work', { recursive: true });
// Headless Chromium cannot approve optional-permission dialogs. Grant tabs only in the disposable test fixture.
const extensionDir = resolve('work/test-extension');
cpSync(resolve('dist'), extensionDir, { recursive: true });
const testManifest = JSON.parse(readFileSync(resolve(extensionDir, 'manifest.json'), 'utf8'));
testManifest.permissions.push('tabs');
testManifest.optional_permissions = testManifest.optional_permissions.filter(
  (v: string) => !['tabs', 'declarativeNetRequest'].includes(v),
);
writeFileSync(resolve(extensionDir, 'manifest.json'), JSON.stringify(testManifest));
const testProfileDir = resolve('work/test-browser-' + Date.now());
const context = await chromium.launchPersistentContext(testProfileDir, {
  channel: 'chromium',
  executablePath: process.env.NOVA_BROWSER,
  headless: true,
  ignoreDefaultArgs: ['--mute-audio'],
  args: [
    `--disable-extensions-except=${extensionDir}`,
    `--load-extension=${extensionDir}`,
    '--autoplay-policy=no-user-gesture-required',
  ],
  viewport: { width: 1440, height: 900 },
});
const errors: string[] = [];
context.on('page', (page) => page.on('pageerror', (e) => errors.push(e.message)));
try {
  const worker = context.serviceWorkers()[0] ?? (await context.waitForEvent('serviceworker'));
  const id = new URL(worker.url()).host,
    base = `chrome-extension://${id}`;
  const page = await context.newPage();
  const requests: string[] = [];
  page.on('request', (r) => {
    if (r.url().startsWith('http')) requests.push(r.url());
  });
  await page.goto(base + '/newtab.html');
  await page.locator('#clock').waitFor();
  await page.waitForFunction(() => !!performance.getEntriesByName('nova-ready').length);
  assert.equal(await page.locator('.quick-link').count(), 4);
  assert.equal(requests.length, 0);
  assert.equal(await page.locator('.credits-widget').isVisible(), true);
  assert.equal(
    await page.locator('.credit-row a').first().getAttribute('href'),
    'https://github.com/xtufa7',
  );
  async function command(p: Page, text: string) {
    await p.locator('#terminal-input').fill(text);
    await p.locator('#terminal-input').press('Enter');
  }
  await command(page, 'theme dusk');
  await page.waitForFunction(
    () =>
      getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() === '#e6a8b8',
  );
  await command(page, 'profile coding');
  await page.locator('.notes-area').waitFor();
  await page.locator('.notes-area').fill('Persistent note');
  await page.locator('.notes-area').blur();
  await command(page, 'help');
  await page.locator('#terminal-input').press('ArrowUp');
  assert.equal(await page.locator('#terminal-input').inputValue(), 'help');
  await page.locator('#terminal-input').fill('op');
  await page.locator('#terminal-input').press('Tab');
  assert.equal(await page.locator('#terminal-input').inputValue(), 'open ');
  await page.locator('#terminal-input').press('Escape');
  await page.locator('#settings-toggle').click();
  await page.getByRole('button', { name: 'Widgets', exact: true }).click();
  await page.getByLabel('Show Creator Credits', { exact: true }).uncheck();
  await page.getByRole('button', { name: '×', exact: true }).click();
  assert.equal(await page.locator('#widget-credits').count(), 0);
  await page.keyboard.press('Control+Shift+E');
  await page.locator('.edit-tools').first().waitFor();
  const handle = page.getByRole('button', { name: 'Drag clock', exact: true });
  await handle.focus();
  await handle.press('ArrowRight');
  await page.getByRole('button', { name: 'Done' }).click();
  assert.equal(await page.locator('.edit-tools').count(), 0);
  await page.waitForTimeout(300);
  const settings = (await worker.evaluate(async () => {
    const value = await chrome.storage.local.get('nova.settings');
    return value['nova.settings'];
  })) as { profiles: { id: string; layout: Record<string, unknown> }[] };
  assert.ok(settings.profiles.find((p) => p.id === 'coding')?.layout.clock);
  await page.reload();
  await page.waitForFunction(() => !!performance.getEntriesByName('nova-ready').length);
  assert.equal(await page.locator('.notes-area').inputValue(), 'Persistent note');
  assert.equal(await page.locator('#widget-credits').count(), 0);
  assert.equal(
    await page.locator('#widget-clock').evaluate((n) => (n as HTMLElement).style.position),
    'absolute',
  );
  await page.locator('#settings-toggle').click();
  await page.getByRole('button', { name: 'Performance', exact: true }).click();
  await page.getByLabel('Low Power Mode', { exact: true }).check();
  await page.getByRole('button', { name: '×', exact: true }).click();
  assert.equal(await page.locator('body').getAttribute('data-animations'), 'off');
  await page.setViewportSize({ width: 390, height: 844 });
  assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.locator('#settings-toggle').click();
  for (const section of [
    'Appearance',
    'Layout',
    'Widgets',
    'Shortcuts',
    'Terminal',
    'Music',
    'Floating Tabs',
    'Profiles',
    'Performance',
    'Privacy',
    'Backup',
    'Advanced',
    'About',
  ]) {
    await page.getByRole('button', { name: section, exact: true }).click();
    assert.equal(await page.locator('.settings-heading h1').textContent(), section);
  }
  await page.getByRole('button', { name: '×', exact: true }).click();
  // A generated silent WAV verifies import, decoding, offscreen transport, seek, and playback after New Tab closes.
  const samples = 44100 * 120,
    wav = Buffer.alloc(44 + samples * 2);
  wav.write('RIFF');
  wav.writeUInt32LE(36 + samples * 2, 4);
  wav.write('WAVE', 8);
  wav.write('fmt ', 12);
  wav.writeUInt32LE(16, 16);
  wav.writeUInt16LE(1, 20);
  wav.writeUInt16LE(1, 22);
  wav.writeUInt32LE(44100, 24);
  wav.writeUInt32LE(88200, 28);
  wav.writeUInt16LE(2, 32);
  wav.writeUInt16LE(16, 34);
  wav.write('data', 36);
  wav.writeUInt32LE(samples * 2, 40);
  writeFileSync('work/test.wav', wav);
  await page.locator('#settings-toggle').click();
  await page.getByRole('button', { name: 'Music', exact: true }).click();
  const chooserPromise = page.waitForEvent('filechooser');
  await page.getByRole('button', { name: 'Add local audio', exact: true }).press('Enter');
  await (await chooserPromise).setFiles(resolve('work/test.wav'));
  await page.getByText('test — Local audio', { exact: true }).waitFor();
  await page.getByLabel('Mini player widget', { exact: true }).check();
  await page.getByRole('button', { name: 'play', exact: true }).click();
  await page.getByRole('button', { name: '×', exact: true }).click();
  const monitor = await context.newPage();
  await monitor.goto(base + '/settings.html');
  async function waitUntil(predicate: () => Promise<boolean | undefined>, timeout = 15000) {
    const end = Date.now() + timeout;
    while (Date.now() < end) {
      if (await monitor.evaluate(predicate)) return;
      await monitor.waitForTimeout(100);
    }
    throw new Error('Async condition timed out');
  }
  const audioStatus = () =>
    monitor.evaluate(async () =>
      chrome.runtime.sendMessage({
        target: 'worker',
        type: 'music',
        action: 'status',
      }),
    );
  await page.waitForTimeout(700);
  let audio = await audioStatus();
  assert.ok(!audio?.error, JSON.stringify(audio));
  assert.equal(audio.playing, true);
  assert.equal(audio.title, 'test');
  await command(page, 'volume 30');
  await page.waitForTimeout(250);
  audio = await audioStatus();
  assert.equal(audio.volume, 30);
  await monitor.evaluate(async () =>
    chrome.runtime.sendMessage({
      target: 'worker',
      type: 'music',
      action: 'seek',
      value: 2,
    }),
  );
  audio = await audioStatus();
  assert.ok(audio.current >= 2);
  // Actual audible-tab events drive fading, hiding, resume and manual-pause cancellation.
  await context.route('https://audio-fixture.test/**', (route) =>
    route.fulfill({ contentType: 'text/html', body: '<title>Audio fixture</title>' }),
  );
  const sound = await context.newPage();
  await sound.goto('https://audio-fixture.test/');
  await sound.evaluate(() => {
    const win = window as unknown as { sound: AudioContext };
    win.sound = new AudioContext();
    const oscillator = win.sound.createOscillator();
    const gain = win.sound.createGain();
    gain.gain.value = 0.02;
    oscillator.connect(gain);
    gain.connect(win.sound.destination);
    oscillator.start();
    return win.sound.resume();
  });
  await waitUntil(async () => {
    const s = await chrome.runtime.sendMessage({
      target: 'worker',
      type: 'music',
      action: 'status',
    });
    return s?.ducked && !s.playing;
  });
  await page.waitForFunction(() =>
    document.querySelector('#widget-music')?.classList.contains('music-ducked'),
  );
  assert.equal(
    await page.locator('#widget-music').evaluate((n) => n.classList.contains('music-ducked')),
    true,
  );
  const pausedAt = (await audioStatus()).current;
  // Simulate the browser closing a silent offscreen document; the session checkpoint must restore it.
  await worker.evaluate(() => chrome.offscreen.closeDocument());
  await sound.evaluate(() => (window as unknown as { sound: AudioContext }).sound.suspend());
  await waitUntil(async () => {
    const s = await chrome.runtime.sendMessage({
      target: 'worker',
      type: 'music',
      action: 'status',
    });
    return s?.playing && !s.ducked;
  });
  assert.ok((await audioStatus()).current >= pausedAt);
  await sound.evaluate(() => (window as unknown as { sound: AudioContext }).sound.resume());
  await waitUntil(async () => {
    const s = await chrome.runtime.sendMessage({
      target: 'worker',
      type: 'music',
      action: 'status',
    });
    return s?.ducked && !s.playing;
  });
  await monitor.evaluate(() =>
    chrome.runtime.sendMessage({ target: 'worker', type: 'music', action: 'pause' }),
  );
  await sound.close();
  await monitor.waitForTimeout(3500);
  assert.equal((await audioStatus()).playing, false);
  await monitor.evaluate(() =>
    chrome.runtime.sendMessage({ target: 'worker', type: 'music', action: 'play' }),
  );
  await page.close();
  audio = await audioStatus();
  assert.equal(audio.playing, true);
  const next = await context.newPage();
  await next.goto(base + '/newtab.html');
  await next.waitForFunction(() => !!performance.getEntriesByName('nova-ready').length);
  await command(next, 'music pause');
  await next.waitForTimeout(200);
  assert.equal((await audioStatus()).playing, false);
  // The production manifest keeps tabs optional; the fixture grants it for API integration checks.
  await next.locator('#settings-toggle').click();
  await next.getByRole('button', { name: 'Privacy', exact: true }).click();
  await next.getByText('Browser permissions', {exact:true}).click();
  const tabsCard = next.locator('.permission-card').filter({hasText:'Tabs & sessions'});
  await tabsCard.getByText('Allowed', {exact:true}).waitFor();
  assert(await tabsCard.getByRole('button',{name:'Allow',exact:true}).isDisabled());
  const granted = await worker.evaluate(() =>
    chrome.permissions.contains({ permissions: ['tabs'] }),
  );
  let sessionsVerified = false;
  assert.equal(granted, true);
  if (granted) {
    const site = await context.newPage();
    await site.goto('https://example.com');
    await next.getByRole('button', { name: '×', exact: true }).click();
    await command(next, 'session save browser-test');
    await next.waitForTimeout(300);
    const saved = await worker.evaluate(async () => {
      const s = (await chrome.storage.local.get('nova.settings'))['nova.settings'] as {
        sessions: { name: string; urls: string[] }[];
      };
      return s.sessions.find((s) => s.name === 'browser-test');
    });
    assert.ok(saved?.urls.includes('https://example.com/'));
    await command(next, 'session open browser-test');
    await next.waitForTimeout(400);
    sessionsVerified = true;
    await command(next, 'float current');
    await next.waitForTimeout(300);
    const original = (await next.evaluate(
      async () => (await chrome.storage.session.get('nova.popup'))['nova.popup'],
    )) as { tabId: number; windowId: number; popupWindowId: number };
    assert.ok(original?.tabId);
    assert.notEqual(original.windowId, original.popupWindowId);
    await command(next, 'float close');
    await next.waitForTimeout(300);
    const restored = await next.evaluate(async (tabId) => chrome.tabs.get(tabId), original.tabId);
    assert.equal(restored.windowId, original.windowId);
  }
  await monitor.evaluate(() =>
    chrome.runtime.sendMessage({
      target: 'worker',
      type: 'music',
      action: 'stop',
    }),
  );
  await worker.evaluate(
    async (settings) => chrome.storage.local.set({ 'nova.settings': settings }),
    defaults(),
  );
  await next.reload();
  await next.waitForFunction(() => !!performance.getEntriesByName('nova-ready').length);
  await next.screenshot({ path: resolve('work/newtab-desktop.png') });
  assert.deepEqual(errors, []);
  const metrics = await next.evaluate(() => ({
    readyMs: performance.getEntriesByName('nova-ready')[0]?.startTime,
    domNodes: document.querySelectorAll('*').length,
  }));
  await next.locator('#settings-toggle').click();
  await next.getByRole('button', { name: 'Backup', exact: true }).click();
  const [backupDownload] = await Promise.all([
    next.waitForEvent('download'),
    next.getByRole('button', { name: 'Export configuration', exact: true }).click(),
  ]);
  await backupDownload.saveAs(resolve('work/roundtrip-backup.json'));
  assert.equal(
    JSON.parse(readFileSync('work/roundtrip-backup.json', 'utf8')).settings.schemaVersion,
    7,
  );
  await next.getByRole('button', { name: '×', exact: true }).click();
  await command(next, 'theme dusk');
  await next.waitForFunction(
    () =>
      getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() === '#e6a8b8',
  );
  await next.locator('#settings-toggle').click();
  await next.getByRole('button', { name: 'Backup', exact: true }).click();
  next.once('dialog', (dialog) => void dialog.accept());
  await next.getByLabel('Import configuration', { exact: true }).setInputFiles(resolve('work/roundtrip-backup.json'));
  await next.waitForFunction(
    () =>
      getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() === '#b2a1ef',
  );
  await next.getByRole('button', { name: 'Appearance', exact: true }).click();
  await next.getByRole('button', { name: 'Background image', exact: true }).click();
  await next
    .locator('.wallpaper-drop input[type=file]')
    .setInputFiles(resolve('public/icons/128.png'));
  await next.locator('#background img').waitFor();
  await next.getByRole('button', { name: 'Advanced', exact: true }).click();
  await next
    .getByLabel('Custom CSS', { exact: true })
    .fill('#terminal-form { border-radius: 3px; }');
  await next.getByLabel('Custom CSS', { exact: true }).blur();
  await next.getByLabel('Enable custom CSS', { exact: true }).check();
  await next.waitForFunction(
    () => getComputedStyle(document.querySelector('#terminal-form')!).borderRadius === '3px',
  );
  assert.equal(await monitor.locator('#custom-css').textContent(), '');
  await next.getByRole('button', { name: 'Reset Advanced', exact: true }).click();
  await next.getByRole('button', { name: 'Widgets', exact: true }).click();
  await next.getByLabel('Links', { exact: true }).uncheck();
  assert.equal(await next.locator('.quick-link').count(), 0);
  await next.getByLabel('Links', { exact: true }).check();
  assert.equal(await next.locator('.quick-link').count(), 4);
  await next.getByRole('button', { name: '×', exact: true }).click();
  await next.waitForTimeout(250);
  await next.reload();
  await next.locator('#background img').waitFor();
  // Search navigation is intercepted, so this assertion sends no query to a real search service.
  await context.route('https://www.google.com/search?*', (route) =>
    route.fulfill({ status: 200, contentType: 'text/html', body: '<title>Search fixture</title>' }),
  );
  await command(next, 'g nova privacy');
  await next.waitForURL('https://www.google.com/search?q=nova%20privacy');
  await next.goto(base + '/newtab.html');
  await next.waitForFunction(() => !!performance.getEntriesByName('nova-ready').length);
  await next.locator('#settings-toggle').click();
  await next.getByRole('button', { name: 'Appearance', exact: true }).click();
  await next.getByRole('button', { name: 'Clock style neon', exact: true }).click();
  await next.getByLabel('Clock font', { exact: true }).selectOption('mono');
  await next.getByLabel('Text below clock', { exact: true }).fill('My quiet time');
  await next.getByLabel('Text below clock', { exact: true }).blur();
  assert.equal(await next.locator('#widget-clock .eyebrow').textContent(), 'My quiet time');
  await next.locator('summary').filter({ hasText: 'Custom colors & saved themes' }).click();
  await next.getByLabel('Theme name', { exact: true }).fill('My neon');
  await next.getByRole('button', { name: 'Save theme', exact: true }).click();
  await next.getByRole('button', { name: 'Privacy', exact: true }).click();
  await next.getByRole('button', { name: 'Enable tracker blocker', exact: true }).click();
  await waitUntil(async () => (await chrome.declarativeNetRequest.getDynamicRules()).length > 0);
  const blocked = await worker.evaluate(() =>
    chrome.declarativeNetRequest.testMatchOutcome({
      url: 'https://www.google-analytics.com/collect',
      type: chrome.declarativeNetRequest.ResourceType.XMLHTTPREQUEST,
      initiator: 'https://example.com',
    }),
  );
  assert.ok(blocked.matchedRules.length);
  await next
    .getByLabel('Website exceptions · one domain per line', { exact: true })
    .fill('example.com');
  await next.getByLabel('Website exceptions · one domain per line', { exact: true }).blur();
  await waitUntil(async () =>
    (
      await chrome.declarativeNetRequest.getDynamicRules()
    )[0]?.condition.excludedInitiatorDomains?.includes('example.com'),
  );
  const allowed = await worker.evaluate(() =>
    chrome.declarativeNetRequest.testMatchOutcome({
      url: 'https://www.google-analytics.com/collect',
      type: chrome.declarativeNetRequest.ResourceType.XMLHTTPREQUEST,
      initiator: 'https://example.com',
    }),
  );
  assert.equal(allowed.matchedRules.length, 0);
  await next.getByRole('button', { name: 'Disable tracker blocker', exact: true }).click();
  await waitUntil(async () => (await chrome.declarativeNetRequest.getDynamicRules()).length === 0);
  await next.getByRole('button', { name: 'Floating Tabs', exact: true }).click();
  assert.equal(await next.locator('.keybind-row').count(), 3);
  await next.getByRole('button', { name: 'Appearance', exact: true }).click();
  await next.getByRole('button', { name: 'aurora', exact: true }).click();
  await next.screenshot({ path: resolve('work/settings-v11.png') });
  await next.setViewportSize({ width: 390, height: 844 });
  assert.ok(await next.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
  await next.screenshot({ path: resolve('work/settings-mobile-v11.png') });
  await next.setViewportSize({ width: 1440, height: 900 });
  await next.getByRole('button', { name: '×', exact: true }).click();
  await next.screenshot({ path: resolve('work/neon-v11.png') });
  // Unsupported persisted data remains intact when a page merely loads and closes.
  await worker.evaluate(() =>
    chrome.storage.local.set({
      'nova.settings': { schemaVersion: 99, recoveryMarker: 'preserve-me' },
    }),
  );
  await next.reload();
  await next.waitForFunction(() => !!performance.getEntriesByName('nova-ready').length);
  await next.close();
  const preserved = (await worker.evaluate(
    async () => (await chrome.storage.local.get('nova.settings'))['nova.settings'],
  )) as { schemaVersion: number };
  assert.equal(preserved.schemaVersion, 99);
  await worker.evaluate(
    (settings) => chrome.storage.local.set({ 'nova.settings': settings }),
    defaults(),
  );
  assert.deepEqual(errors, []);
  writeFileSync(
    'work/browser-report.json',
    JSON.stringify(
      {
        passed: true,
        errors,
        defaultRemoteRequests: requests,
        metrics,
        sessionsVerified,
        offscreenPlayback: true,
        layoutPersistence: true,
        creditsHide: true,
        backupRoundtrip: true,
        backgroundPersistence: true,
        customCSSScope: true,
        searchNavigation: true,
        interactiveFloat: true,
        invalidStoragePreserved: true,
      },
      null,
      2,
    ),
  );
  console.log(
    'Browser checks passed:',
    JSON.stringify({
      metrics,
      sessionsVerified,
      offscreenPlayback: true,
      layoutPersistence: true,
      creditsHide: true,
    }),
  );
} finally {
  await context.close();
  if (dirname(testProfileDir) === resolve('work'))
    rmSync(testProfileDir, { recursive: true, force: true });
}
