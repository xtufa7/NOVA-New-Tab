import { chromium } from 'playwright';
import { resolve } from 'node:path';
import { writeFileSync } from 'node:fs';
import assert from 'node:assert/strict';
import type { Settings } from '../src/settings/schema';
const dir = resolve('dist');
const context = await chromium.launchPersistentContext(resolve('work/spotify-auto-' + Date.now()), {
  executablePath: process.env.NOVA_BROWSER,
  channel: 'chromium',
  headless: true,
  args: [`--disable-extensions-except=${dir}`, `--load-extension=${dir}`],
});
const errors: string[] = [];
context.on('page', (page) => page.on('pageerror', (e) => errors.push(e.message)));
await context.addInitScript(() => {
  if (globalThis.chrome?.runtime?.id) (globalThis as any).browser = chrome;
});
try {
  const worker = context.serviceWorkers()[0] ?? (await context.waitForEvent('serviceworker'));
  const base = 'chrome-extension://' + new URL(worker.url()).host;
  const page = await context.newPage();
  await page.goto(base + '/newtab.html');
  await page.waitForFunction(() => performance.getEntriesByName('nova-ready').length > 0);
  await page.waitForFunction(
    async () =>
      !!(await chrome.storage.local.get('nova.spotify.autoSetup.v1'))['nova.spotify.autoSetup.v1'],
  );
  const settings = (await worker.evaluate(
    async () => (await chrome.storage.local.get('nova.settings'))['nova.settings'],
  )) as Settings;
  assert(
    settings.integrations.spotify &&
      settings.integrations.onlineLyrics &&
      settings.integrations.terminalLyrics,
  );
  settings.integrations.lyricsAnimation = 'rise+blur';
  await worker.evaluate((s) => chrome.storage.local.set({ 'nova.settings': s }), settings);
  const permissions = await worker.evaluate(() => chrome.permissions.getAll());
  assert(
    permissions.origins?.includes('https://open.spotify.com/*') &&
      permissions.origins.includes('https://lrclib.net/*'),
  );
  await page.waitForFunction(async () =>
    (await chrome.scripting.getRegisteredContentScripts()).some((s) => s.id === 'nova-spotify'),
  );
  await context.route('https://open.spotify.com/**', (r) =>
    r.fulfill({
      contentType: 'text/html',
      body: '<div data-testid="now-playing-widget"><a data-testid="context-item-info-title" href="/track/test">Auto Song</a><a href="/artist/test">Auto Artist</a></div><button data-testid="control-button-playpause" aria-label="Pause"></button><span data-testid="playback-position">0:04</span><span data-testid="playback-duration">3:00</span>',
    }),
  );
  await context.route('https://lrclib.net/**', (r) =>
    r.fulfill({
      contentType: 'application/json',
      body: JSON.stringify({ syncedLyrics: '[00:00]Automatic lyrics work\n[00:20]Next line' }),
    }),
  );
  const opened = context.waitForEvent('page');
  await worker.evaluate(() =>
    chrome.tabs.create({ url: 'https://open.spotify.com/test', active: true }),
  );
  const spotify = await opened;
  await spotify.waitForURL('https://open.spotify.com/test');
  await spotify.waitForLoadState('domcontentloaded');
  await page.bringToFront();
  await page.waitForFunction(
    async () =>
      ((await chrome.storage.session.get('nova.spotify'))['nova.spotify'] as { title?: string })
        ?.title === 'Auto Song',
  );
  await page.locator('.terminal-lyrics').waitFor({ state: 'visible' });
  assert((await page.locator('.terminal-lyrics').innerText()).includes('Automatic'));
  const effects = await page
    .locator('.terminal-lyrics .lyric-word')
    .first()
    .evaluate((n) =>
      n.getAnimations({ subtree: true }).map((a) => ({
        frames: (a.effect as KeyframeEffect).getKeyframes(),
        duration: a.effect!.getTiming().duration,
      })),
    );
  assert(
    effects.some(
      (e) =>
        String(e.frames[0].filter).includes('blur') &&
        String(e.frames[0].transform).includes('translate'),
    ),
  );
  assert(effects.every((e) => e.duration === 650));
  await page.screenshot({ path: 'work/NOVA-3.0.0-lyrics-terminal.png' });
  await page.locator('#settings-toggle').click();
  await page.getByRole('button', { name: 'Music', exact: true }).click();
  await page.getByText('Spotify & synchronized lyrics', { exact: true }).click();
  await page
    .getByRole('button', { name: 'Reconnect Spotify + enable lyrics', exact: true })
    .click();
  await page.waitForTimeout(800);
  await page.getByText('Lyrics animation preview', { exact: true }).click();
  await page.getByLabel('Lyrics animation', { exact: true }).selectOption('rise+blur');
  await page.getByRole('button', { name: 'Replay animation', exact: true }).click();
  await page.locator('.lyrics-preview').scrollIntoViewIfNeeded();
  await page.waitForTimeout(850);
  await page.screenshot({ path: 'work/NOVA-3.0.0-animation-preview.png' });
  assert(
    !(await page
      .locator('body')
      .innerText()
      .then((t) => t.includes('Unexpected property'))),
  );
  assert.deepEqual(errors, []);
  settings.integrations.spotify = false;
  settings.integrations.onlineLyrics = false;
  await worker.evaluate((s) => chrome.storage.local.set({ 'nova.settings': s }), settings);
  await page.waitForFunction(
    async () =>
      !(await chrome.scripting.getRegisteredContentScripts()).some((s) => s.id === 'nova-spotify'),
  );
  await page.reload();
  assert.equal(
    (
      (await worker.evaluate(
        async () => (await chrome.storage.local.get('nova.settings'))['nova.settings'],
      )) as Settings
    ).integrations.spotify,
    false,
  );
  writeFileSync(
    'work/spotify-auto-report.json',
    JSON.stringify(
      {
        version: '3.0.0',
        unmodifiedStoreBuild: true,
        chromiumBrowserAlias: true,
        automaticSpotifyReader: true,
        automaticLyrics: true,
        reconnectWithoutFirefoxFields: true,
        optOutPreserved: true,
      },
      null,
      2,
    ),
  );
  console.log(
    'Unmodified store build passed: automatic Spotify reader and lyrics, Chromium browser alias, reconnect without data_collection, explicit opt-out preserved.',
  );
} finally {
  await context.close();
}
