import { chromium } from 'playwright';
import { resolve } from 'node:path';
import { cpSync, readFileSync, writeFileSync, readdirSync } from 'node:fs';
import assert from 'node:assert/strict';


import { defaults, applyTheme } from '../src/settings/schema';
const samples = 44100 * 30,
  wav = Buffer.alloc(44 + samples * 2);
wav.write('RIFF');
wav.writeUInt32LE(36 + samples * 2, 4);
wav.write('WAVE', 8);
wav.write('fmt ', 12);
wav.writeUInt32LE(16, 16);
wav.writeUInt16LE(1, 20);
wav.writeUInt16LE(1, 22);
wav.writeUInt32LE(44100, 24);
wav.writeUInt32LE(88200, 28);
wav.writeUInt16LE(2, 32);
wav.writeUInt16LE(16, 34);
wav.write('data', 36);
wav.writeUInt32LE(samples * 2, 40);
writeFileSync('work/lyrics-test.wav', wav);
const dir = resolve('work/v12-extension-' + Date.now());
cpSync('dist', dir, { recursive: true });
const m = JSON.parse(readFileSync(resolve(dir, 'manifest.json'), 'utf8'));
assert(!m.optional_permissions.includes('declarativeNetRequest'));
m.permissions.push('tabs', 'tabCapture');
m.optional_permissions = m.optional_permissions.filter(
  (p: string) => !['tabs', 'tabCapture'].includes(p),
);
m.host_permissions = ['http://*/*', 'https://*/*'];
writeFileSync(resolve(dir, 'manifest.json'), JSON.stringify(m));
// The disposable fixture supplies actual canvas video while leaving the shipping PiP controller unchanged.
const asset = readdirSync(resolve(dir, 'assets')).find((name) => /^floating-.*\.js$/.test(name))!;
const viewerAsset = resolve(dir, 'assets', asset);
const streamHelper =
  'async function __novaTestStream(){const c=document.createElement("canvas");c.width=640;c.height=360;const draw=()=>{const x=c.getContext("2d");x.fillStyle="#1e1e2e";x.fillRect(0,0,640,360);x.fillStyle="#cba6f7";x.font="32px sans-serif";x.fillText("NOVA PiP fixture",30,130)};draw();setInterval(draw,100);return c.captureStream(10)};';
writeFileSync(
  viewerAsset,
  streamHelper +
    readFileSync(viewerAsset, 'utf8').replace(
      'navigator.mediaDevices.getUserMedia(',
      '__novaTestStream(',
    ),
);
const context = await chromium.launchPersistentContext(resolve('work/v12-browser-' + Date.now()), {
  channel: 'chromium',
  executablePath: process.env.NOVA_BROWSER,
  headless: true,
  args: [
    `--disable-extensions-except=${dir}`,
    `--load-extension=${dir}`,
    '--autoplay-policy=no-user-gesture-required',
  ],
  viewport: { width: 1280, height: 800 },
});
const errors: string[] = [];
context.on('page', (p) =>
  p.on('pageerror', (e) => (errors.push(e.message), console.log('PAGE ERROR', p.url(), e.stack))),
);
try {
  const worker = context.serviceWorkers()[0] ?? (await context.waitForEvent('serviceworker'));
  for (let i = 0; i < 60; i++) {
    if (await worker.evaluate(async () => !!globalThis.chrome?.storage?.local && !!(await chrome.storage.local.get('nova.spotify.autoSetup.v1'))['nova.spotify.autoSetup.v1'])) break;
    await new Promise(resolve => setTimeout(resolve, 50));
  }
  const base = `chrome-extension://${new URL(worker.url()).host}`;
  await context.route('https://example.com/**', (r) =>
    r.fulfill({ contentType: 'text/html', body: '<title>NOVA fixture</title><h1>Web page</h1>' }),
  );
  await context.route('https://www.tiktok.com/**', (r) =>
    r.fulfill({
      contentType: 'text/html',
      body: '<title>TikTok fixture</title><h1>Mini TikTok</h1>',
    }),
  );
  await context.route('https://open.spotify.com/**', (r) =>
    r.fulfill({
      contentType: 'text/html',
      body: '<title>Spotify fixture</title><div data-testid="now-playing-widget"><a data-testid="context-item-info-title" href="/track/test">Test Song</a><a href="/artist/test">Test Artist</a></div><button data-testid="control-button-playpause" aria-label="Pause"></button><span data-testid="playback-position">0:04</span><span data-testid="playback-duration">3:00</span>',
    }),
  );
  await context.route('https://lrclib.net/**', (r) =>
    r.fulfill({
      contentType: 'application/json',
      body: JSON.stringify({
        syncedLyrics: '[00:00]A quiet start\n[00:03]The second line\n[00:20]A future line',
      }),
    }),
  );
  const settings = defaults();
  applyTheme(settings.profiles[0], 'mocha');
  settings.profiles[0].appearance.clockStyle = '12h';
  settings.profiles[0].appearance.clockSpacing = 0.1;
  settings.companion.enabled = true;
  settings.integrations.spotify = true;
  settings.integrations.onlineLyrics = true;
  await worker.evaluate((s) => chrome.storage.local.set({ 'nova.settings': s }), settings);
  const page = await context.newPage();
  await page.goto(base + '/newtab.html');
  await page.waitForFunction(() => performance.getEntriesByName('nova-ready').length > 0);
  await page.waitForSelector('#nova-browser-handle');
  assert(
    (await page
      .locator('.clock-meridiem')
      .evaluate((n) => parseFloat(getComputedStyle(n).fontSize))) <
      (await page
        .locator('.clock-digits')
        .evaluate((n) => parseFloat(getComputedStyle(n).fontSize))) *
        0.25,
  );
  await page.locator('#terminal-input').fill('d');
  const bounds = await page.evaluate(() => {
    const a = document.querySelector('#suggestions')!.getBoundingClientRect(),
      b = document.querySelector('#widget-links')!.getBoundingClientRect();
    return { bottom: a.bottom, linkTop: b.top };
  });
  assert(bounds.bottom <= bounds.linkTop, JSON.stringify(bounds));
  await page.locator('#terminal-input').fill('');
  await page.locator('#terminal-input').blur();
  const webReady=context.waitForEvent('page');
  await worker.evaluate(()=>chrome.tabs.create({url:'https://example.com/test',active:true}));
  const web=await webReady;
  await web.waitForURL('https://example.com/test');
  await web.waitForSelector('#nova-browser-handle');

  // Hide only this tab through the same worker action used by the handle context menu.
  await web.locator('#nova-browser-handle').click({ button: 'right' });
  const handleBounds = await web.locator('#nova-browser-handle').boundingBox();
  await web.mouse.click(handleBounds!.x - 100, handleBounds!.y + 24);
  await web.waitForFunction(() => !document.querySelector('#nova-browser-handle'));
  assert.equal(await page.locator('#nova-browser-handle').count(), 1);
  await worker.evaluate(async () => {
    const s = await chrome.storage.session.get(null);
    await chrome.storage.session.remove(
      Object.keys(s).filter((k) => k.startsWith('nova.sideHidden.')),
    );
  });
  await web.waitForSelector('#nova-browser-handle');
  await page.evaluate(() =>
    chrome.runtime.sendMessage({
      target: 'worker',
      type: 'companion-position',
      edge: 'left',
      y: 0.08,
    }),
  );
  await page.waitForFunction(
    () => document.querySelector<HTMLElement>('#nova-browser-handle')?.style.left === '0px',
  );
  await page.evaluate(() =>
    chrome.runtime.sendMessage({ target: 'worker', type: 'companion-open' }),
  );
  await worker.evaluate(async () => {
    const saved = (await chrome.storage.session.get('nova.tiktok'))['nova.tiktok'] as
      { windowId: number } | undefined;
    if (!saved?.windowId) throw new Error('Mini window missing');
    await chrome.windows.remove(saved.windowId);
  });
  const spotify = await context.newPage();
  await spotify.goto('https://open.spotify.com/test');
  await page.bringToFront();
  await page.waitForFunction(
    () => document.querySelector('.terminal-lyrics .current')?.textContent?.startsWith('The'),
    {},
    { timeout: 15000 },
  );
  await page.screenshot({ path: 'work/NOVA-3.0.0-preview.png' });
  await page.locator('#settings-toggle').click();
  await page.locator('.theme-tile').filter({ hasText: 'mocha' }).waitFor();
  assert.equal(await page.locator('.theme-tile').count(), 11);
  await page.screenshot({ path: 'work/NOVA-3.0.0-settings.png' });
  await page.getByRole('button', { name: 'Music', exact: true }).click();
  await page.getByText('Spotify & synchronized lyrics', { exact: true }).click();
  assert(await page.getByLabel('Spotify source', { exact: true }).isVisible());
  await page.setViewportSize({ width: 390, height: 844 });
  assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
  await page.screenshot({ path: 'work/NOVA-3.0.0-mobile.png' });
  await page.setViewportSize({ width: 1280, height: 800 });
  await page.getByRole('button', { name: '×', exact: true }).click();
  // Exercise the production PiP controller with a real canvas stream. Capture authorization needs a manual toolbar action.
  const viewerReady=context.waitForEvent('page');
  await worker.evaluate(async (base) => {
    const t = await chrome.tabs.create({ url: base + '/floating.html?target=1' });
    await chrome.storage.session.set({
      ['nova.capture.' + t.id]: { tabId: 1, streamId: 'fixture' },
    });
    return t;
  }, base);
  const viewer = await viewerReady;
  await viewer.waitForURL('**/floating.html?target=1');
  await viewer.waitForFunction(
    () => !document.querySelector<HTMLButtonElement>('#start-float')!.disabled,
  );
  console.log(
    'capture state',
    await viewer.locator('#float-status').textContent(),
    await viewer.locator('#start-float').textContent(),
  );
  await viewer.locator('#start-float').click();
  await viewer.waitForFunction(
    () => !!(window as any).documentPictureInPicture.window?.document.querySelector('#preview'),
  );
  assert(await viewer.evaluate(() => !document.querySelector('#preview')));
  await viewer.evaluate(() =>
    (window as any).documentPictureInPicture.window.document.querySelector('#pin-float').click(),
  );
  await viewer.waitForSelector('#preview');
  assert(await viewer.locator('#start-float').isVisible());
  await viewer.close();
  // Download and cache an actual Google Fonts family by name.
  await page.locator('#settings-toggle').click();
  await page.getByRole('button', { name: 'Appearance', exact: true }).click();
  await page.getByText('Custom font library', { exact: true }).click();
  await page.getByLabel('Font family name', { exact: true }).fill('Orbitron');
  await page.getByRole('button', { name: 'Find & download', exact: true }).click();
  await page.waitForFunction(
    () =>
      document.fonts.check(
        '20px "' +
          getComputedStyle(document.documentElement)
            .getPropertyValue('--clock-font')
            .split(',')[0]
            .trim()
            .replaceAll('"', '') +
          '"',
      ) &&
      getComputedStyle(document.documentElement)
        .getPropertyValue('--clock-font')
        .includes('NovaFont-'),
    {},
    { timeout: 60000 },
  );
  console.log('PiP pin/unpin and actual Google Fonts download/cache passed.');
  await context.route('https://fonts.googleapis.com/**', (r) => r.abort());
  await context.route('https://fonts.gstatic.com/**', (r) => r.abort());
  await page.reload();
  await page.waitForFunction(() => performance.getEntriesByName('nova-ready').length > 0);
  await page.waitForFunction(
      () =>
        document.fonts.size > 0 &&
        getComputedStyle(document.documentElement)
          .getPropertyValue('--clock-font')
          .includes('NovaFont-'),
    undefined,
    {timeout:15000},
  );
  await worker.evaluate(async () => {
    const s = (await chrome.storage.local.get('nova.settings'))['nova.settings'] as ReturnType<
      typeof defaults
    >;
    s.integrations.spotify = false;
    s.integrations.onlineLyrics = false;
    s.profiles[0].widgets.music = true;
    s.profiles[0].music.autoDuck = false;
    await chrome.storage.local.set({ 'nova.settings': s });
    return s;
  });
  await page.locator('#settings-toggle').click();
  await page.getByRole('button', { name: 'Music', exact: true }).click();
  await page
    .getByLabel('Add local audio', { exact: true })
    .setInputFiles(resolve('work/lyrics-test.wav'));
  await page.waitForTimeout(500);
  await worker.evaluate(async () => {
    const s = (await chrome.storage.local.get('nova.settings'))['nova.settings'] as ReturnType<
      typeof defaults
    >;
    s.profiles[0].music.tracks[0].lyrics =
      '[00:00]Local opening\n[00:05]Seeked lyric\n[00:20]Last lyric';
    await chrome.storage.local.set({ 'nova.settings': s });
    return s;
  });
  await page.getByRole('button', { name: '×', exact: true }).click();
  await page.getByRole('button', { name: 'Play or pause', exact: true }).click();
  await page.waitForFunction(
    () => document.querySelector('.music-lyrics .current')?.textContent === 'Local opening',
  );
  await page.getByLabel('Seek', { exact: true }).evaluate((node: HTMLInputElement) => {
    node.value = '8';
    node.dispatchEvent(new Event('change', { bubbles: true }));
  });
  await page.waitForFunction(
    () => document.querySelector('.music-lyrics .current')?.textContent === 'Seeked lyric',
  );
  await page.screenshot({ path: 'work/NOVA-3.0.0-player.png', fullPage: true });
  await page.getByLabel('Seek', { exact: true }).evaluate((node: HTMLInputElement) => {
    node.value = '29';
    node.dispatchEvent(new Event('change', { bubbles: true }));
  });
  await page.waitForFunction(
    () => document.querySelector('.music-lyrics .current')?.textContent === 'Local opening',
    {},
    { timeout: 10000 },
  );
  assert.equal(
    await page.getByRole('button', { name: 'Play or pause', exact: true }).textContent(),
    '❚❚',
  );
  console.log('Automatic repeat at the end of a real audio file passed.');
  await page.getByRole('button', { name: 'Play or pause', exact: true }).click();
  console.log('Offline custom font and local LRC seek synchronization passed.');
  assert.deepEqual(errors, []);
  console.log(
    'V14 UI, Spotify DOM sync, lyrics, handle, mini popup, clock and responsive checks passed.',
  );
} finally {
  await context.close();
}
