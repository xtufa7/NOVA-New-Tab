import { chromium } from 'playwright';
import { resolve } from 'node:path';
import { writeFileSync } from 'node:fs';
import assert from 'node:assert/strict';
import type { Settings } from '../src/settings/schema';
const context = await chromium.launchPersistentContext(resolve('work/v156-' + Date.now()), {
  executablePath: process.env.NOVA_BROWSER,
  headless: true,
  viewport: { width: 1440, height: 1000 },
  args: [`--disable-extensions-except=${resolve('dist')}`, `--load-extension=${resolve('dist')}`],
});
try {
  await context.addInitScript(()=>{const original=Element.prototype.animate;Element.prototype.animate=function(frames,options){const result=original.call(this,frames,options);if(this.matches('.wordmark,#canvas > .widget')){const win=window as any;win.openingRecords??=[];win.openingRecords.push({id:this.id||this.className,effects:[{frames:(result.effect as KeyframeEffect).getKeyframes(),timing:result.effect!.getTiming()}]});}return result;};});
  const worker = context.serviceWorkers()[0] ?? (await context.waitForEvent('serviceworker'));
  const base = 'chrome-extension://' + new URL(worker.url()).host;
  const page = await context.newPage();
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto(base + '/newtab.html');
  await page.waitForFunction(
    async () =>
      !!(await chrome.storage.local.get('nova.spotify.autoSetup.v1'))['nova.spotify.autoSetup.v1'],
  );
  const s = (await worker.evaluate(
    async () => (await chrome.storage.local.get('nova.settings'))['nova.settings'],
  )) as Settings;
  s.performance.animations = 'off';
  s.performance.lowPower = false;
  s.entrance.duration = 900;
  s.entrance.delay = 100;
  s.entrance.stagger = 90;
  s.entrance.enabled = true;
  s.profiles[0].appearance.opacity = 40;
  s.profiles[0].widgets.music = true;
  s.lyrics.enabled = true;
  s.lyrics.unit = 'letter';
  s.lyrics.duration = 900;
  s.lyrics.stagger = 40;
  s.integrations.lyricsAnimation = 'rise+blur';
  s.tab.title = 'TuFa7 NØVA';
  s.tab.animation = 'typewriter';
  s.tab.speed = 150;
  await worker.evaluate((s) => chrome.storage.local.set({ 'nova.settings': s }), s);
  await page.reload();
  await page.bringToFront();
  await page.waitForFunction(() => performance.getEntriesByName('nova-ready').length > 0);
  await page.waitForFunction(()=>(window as any).openingRecords?.length>=4);
  const opening = await page.evaluate(() => (window as any).openingRecords as {id:string;effects:{frames:ComputedKeyframe[];timing:EffectTiming}[]}[]);
  assert(
    opening.length >= 4 && opening.every((n) => n.effects.some((e) => e.timing.duration === 900)),
  );
  const title1 = await page.title();
  await page.waitForFunction(title=>document.title!==title,title1,{timeout:5000});
  await page.waitForTimeout(1800);
  assert.equal(
    await page.locator('#background').evaluate((n) => getComputedStyle(n).opacity),
    '0.4',
  );
  await context.route('https://open.spotify.com/**', (r) =>
    r.fulfill({
      contentType: 'text/html',
      body: '<div data-testid="now-playing-widget"><a data-testid="context-item-info-title" href="/track/test">Motion Song</a><a href="/artist/test">Motion Artist</a></div><button data-testid="control-button-playpause" aria-label="Pause"></button><span data-testid="playback-position">0:00</span><span data-testid="playback-duration">3:00</span>',
    }),
  );
  await context.route('https://lrclib.net/**', (r) =>
    r.fulfill({
      contentType: 'application/json',
      body: JSON.stringify({
        syncedLyrics: r.request().url().includes('Arabic')
          ? '[00:00]<00:00>مرحبا <00:04>بالعالم\n[00:30]نهاية'
          : '[00:00]<00:00>Hello <00:04>world\n[00:30]Next line',
      }),
    }),
  );
  await page.waitForFunction(async () =>
    (await chrome.scripting.getRegisteredContentScripts()).some((s) => s.id === 'nova-spotify'),
  );
  const spotify = await context.newPage();
  await spotify.goto('https://open.spotify.com/test');
  await page.bringToFront();
  await page.locator('.terminal-lyrics .lyric-char').first().waitFor({ state: 'visible' });
  const actual = await page
    .locator('.terminal-lyrics .lyric-char')
    .first()
    .evaluate((n) => {
      const a = n.getAnimations()[0];
      if (!a) throw Error('No live letter motion');
      a.pause();
      a.currentTime = 100;
      const before = {
        filter: getComputedStyle(n).filter,
        transform: getComputedStyle(n).transform,
      };
      a.currentTime = 850;
      const after = {
        filter: getComputedStyle(n).filter,
        transform: getComputedStyle(n).transform,
      };
      a.play();
      return {
        before,
        after,
        frames: (a.effect as KeyframeEffect).getKeyframes(),
        duration: a.effect!.getTiming().duration,
      };
    });
  assert(
    actual.before.filter !== actual.after.filter &&
      actual.before.transform !== actual.after.transform,
  );
  assert.equal(actual.duration, 900);
  await page.locator('.spotify-player-panel .lyric-char').first().waitFor({state:'visible'});
  assert(await page.locator('.spotify-player-panel .lyric-char').first().evaluate(n=>n.getAnimations().some(a=>String((a.effect as KeyframeEffect).getKeyframes()[0].filter).includes('blur'))));
  await page
    .locator('.terminal-lyrics .lyric-word')
    .first()
    .evaluate((n) => ((window as any).firstWord = n));
  await page.waitForTimeout(1100);
  assert(
    await page
      .locator('.terminal-lyrics .lyric-word')
      .first()
      .evaluate((n) => (window as any).firstWord === n),
  );
  await page.screenshot({ path: 'work/NOVA-3.0.0-lyrics-terminal.png' });
  await page.locator('#settings-toggle').click();
  await page.getByRole('button', { name: 'Music', exact: true }).click();
  await page.getByText('Lyrics typography & motion', { exact: true }).click();
  await page.getByLabel('Arabic lyrics font', { exact: true }).selectOption('Tahoma');
  await page.getByLabel('English lyrics font', { exact: true }).selectOption('Arial');
  await page.getByLabel('Lyrics color', { exact: true }).fill('#aabbcc');
  await page.getByLabel('Lyrics color', { exact: true }).dispatchEvent('change');
  await page.getByLabel('Lyrics font size', { exact: true }).fill('24');
  await page.getByLabel('Lyrics font size', { exact: true }).dispatchEvent('input');
  await page.getByLabel('Arabic lyrics font', {exact:true}).scrollIntoViewIfNeeded();
  await page.screenshot({path:'docs/images/gallery/lyrics-typography.png'});
  await page.getByLabel('Lyrics rise distance (px)',{exact:true}).scrollIntoViewIfNeeded();
  await page.screenshot({path:'docs/images/gallery/lyrics-motion.png'});
  await page.getByText('Lyrics animation preview', { exact: true }).click();
  await page.getByRole('button', { name: 'Replay animation', exact: true }).click();
  await page.waitForFunction(
    () =>
      getComputedStyle(document.querySelector('.lyrics-preview')!).color === 'rgb(170, 187, 204)',
  );
  assert.equal(
    await page
      .locator('.lyrics-preview .lyric-word')
      .first()
      .evaluate((n) => getComputedStyle(n).fontFamily),
    'Arial, system-ui, sans-serif',
  );
  assert.equal(
    await page.locator('.lyrics-preview').evaluate((n) => getComputedStyle(n).fontSize),
    '24px',
  );
  const previewStyles: Record<string, unknown> = {};
  for (const mode of ['rise', 'rise+blur', 'fade', 'blur', 'typewriter', 'none']) {
    await page.getByLabel('Lyrics animation', { exact: true }).selectOption(mode);
    await page.getByRole('button', { name: 'Replay animation', exact: true }).click();
    previewStyles[mode] = await page
      .locator('.lyrics-preview .lyric-char')
      .first()
      .evaluate((n) => n.getAnimations().map((a) => (a.effect as KeyframeEffect).getKeyframes()));
    assert(
      mode === 'none'
        ? (previewStyles[mode] as unknown[]).length === 0
        : (previewStyles[mode] as unknown[]).length > 0,
    );
  }
  assert.notDeepEqual(previewStyles['rise'], previewStyles['rise+blur']);
  // Delay a real storage acknowledgement, then return to the original style while it is pending.
  await page.getByLabel('Lyrics animation',{exact:true}).selectOption('rise+blur');
  await page.waitForTimeout(500);
  await page.evaluate(()=>{const original=chrome.storage.local.set.bind(chrome.storage.local);(window as any).restoreStorage=()=>{chrome.storage.local.set=original;};chrome.storage.local.set=(async(items:Record<string,unknown>)=>{await new Promise(r=>setTimeout(r,300));return original(items);}) as typeof chrome.storage.local.set;});
  await page.getByLabel('Lyrics animation',{exact:true}).selectOption('fade');
  await page.waitForTimeout(180);
  await page.getByLabel('Lyrics animation',{exact:true}).selectOption('rise+blur');
  await page.waitForTimeout(900);
  assert.equal(await worker.evaluate(async()=>((await chrome.storage.local.get('nova.settings'))['nova.settings'] as Settings).integrations.lyricsAnimation),'rise+blur');
  assert.equal(await page.locator('.lyrics-preview').getAttribute('data-animation'),'rise+blur');
  await page.evaluate(()=>(window as any).restoreStorage());
  await page.getByLabel('Lyrics animation', { exact: true }).selectOption('rise+blur');
  await page.getByLabel('Preview language', { exact: true }).selectOption('Arabic');
  assert.equal(
    await page
      .locator('.lyrics-preview .lyric-word')
      .first()
      .evaluate((n) => getComputedStyle(n).fontFamily),
    'Tahoma, system-ui, sans-serif',
  );
  assert.equal(await page.locator('.lyrics-preview .lyric-char').count(), 0);
  await page.locator('.lyrics-preview').scrollIntoViewIfNeeded();
  await page.waitForTimeout(1000);
  await page.screenshot({ path: 'work/NOVA-3.0.0-animation-preview.png' });
  await page.getByRole('button', { name: 'Performance', exact: true }).click();
  await page.locator('.motion-preview').waitFor({ state: 'visible' });
  const entranceStyles: Record<string, unknown> = {};
  for (const mode of ['rise+blur', 'rise', 'fade', 'zoom', 'slide']) {
    await page.getByLabel('Opening style', { exact: true }).selectOption(mode);
    await page.getByRole('button', { name: 'Replay opening preview', exact: true }).click();
    entranceStyles[mode] = await page
      .locator('.motion-preview > span')
      .first()
      .evaluate((n) => (n.getAnimations()[0].effect as KeyframeEffect).getKeyframes()[0]);
  }
  assert(new Set(Object.values(entranceStyles).map((v) => JSON.stringify(v))).size === 5);
  await page.screenshot({ path: 'docs/images/gallery/opening-animation.png' });
  await page.getByRole('button', { name: '×', exact: true }).click();
  await spotify
    .locator('[data-testid="context-item-info-title"]')
    .evaluate((n) => (n.textContent = 'Arabic Song'));
  await spotify
    .locator('[data-testid="playback-position"]')
    .evaluate((n) => (n.textContent = '0:00'));
  await page.waitForFunction(
    () => document.querySelector<HTMLElement>('.terminal-lyrics .current')?.dataset.flow === 'arabic',
  );
  await page.waitForTimeout(1000);
  const before = await page
    .locator('.terminal-lyrics .lyric-word')
    .first()
    .evaluate((n) => {
      (window as any).arabicFirst = n;
      return n.getBoundingClientRect().x;
    });
  await spotify
    .locator('[data-testid="playback-position"]')
    .evaluate((n) => (n.textContent = '0:05'));
  await page.waitForFunction(
    () => document.querySelectorAll('.terminal-lyrics .current .lyric-word').length >= 2,
  );
  await page.waitForTimeout(500);
  const arabic = await page.locator('.terminal-lyrics .current').evaluate((n) => {
    const w = n.querySelectorAll('.lyric-word');
    return {
      stable: w[0] === (window as any).arabicFirst,
      first: w[0].getBoundingClientRect().x,
      second: w[1].getBoundingClientRect().x,
      text: n.textContent,
    };
  });
  assert(arabic.stable && arabic.first > before && arabic.second < arabic.first);
  const saved = (await worker.evaluate(
    async () => (await chrome.storage.local.get('nova.settings'))['nova.settings'],
  )) as Settings;
  assert.equal(saved.lyrics.color, '#aabbcc');
  assert.equal(saved.lyrics.arabicFont, 'Tahoma');
  assert.equal(await page.locator('.spotify-player-panel .player-lyric-active').evaluate(n=>getComputedStyle(n).color),'rgb(170, 187, 204)');
  saved.entrance.enabled = false;
  await worker.evaluate((s) => chrome.storage.local.set({ 'nova.settings': s }), saved);
  await page.reload();
  await page.waitForFunction(() => performance.getEntriesByName('nova-ready').length > 0);
  assert.equal(await page.locator('.wordmark').evaluate((n) => n.getAnimations().length), 0);
  saved.entrance.enabled = true;
  saved.lyrics.enabled = true;
  saved.entrance.respectSystem = true;
  saved.lyrics.respectSystem = true;
  await worker.evaluate((s) => chrome.storage.local.set({ 'nova.settings': s }), saved);
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.reload();
  await page.waitForFunction(() => performance.getEntriesByName('nova-ready').length > 0);
  assert.equal(await page.locator('.wordmark').evaluate((n) => n.getAnimations().length), 0);
  await page.locator('.terminal-lyrics .lyric-word').first().waitFor({ state: 'visible' });
  assert.equal(
    await page
      .locator('.terminal-lyrics')
      .evaluate((n) => n.getAnimations({ subtree: true }).length),
    0,
  );
  assert.deepEqual(errors, []);
  writeFileSync(
    process.env.NOVA_REPORT ?? 'work/v156-report.json',
    JSON.stringify(
      {
        version: '3.0.0',
        browser: process.env.NOVA_BROWSER,
        unmodifiedStoreBuild: true,
        generalAnimationsOff: true,
        opening,
        actual,
        arabic,
        previewStyles,
        entranceStyles,
        typographySaved: true,
        rapidSelectionPreserved: true,
        playerMotionVerified: true,
        titleAnimation: true,
        systemReducedMotionRespected: true,
      },
      null,
      2,
    ),
  );
  console.log(
    'Actual live blur/rise, letter stagger, Arabic word shift, independent entrance/title, typography and all previews passed.',
  );
} finally {
  await context.close();
}
