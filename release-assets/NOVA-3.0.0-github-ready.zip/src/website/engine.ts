import { color, composite, luminance, surface, readable, mix, css, type RGBA } from './color';
import type { WebsiteSettings, SiteRule } from './model';
import type { Tokens } from '../themes/tokens';
export interface PageConfig {
  website: WebsiteSettings;
  site?: SiteRule;
  tokens: Tokens;
  theme: boolean;
  host: string;
  shortcuts: { enabled: boolean; websites: boolean; shortcut: string; focusShortcut: string };
}
type Saved = { before: string; priority: string; applied: string };
const protectedSelector =
  'img,picture,video,audio,canvas,svg,iframe,object,embed,[contenteditable],.monaco-editor,.CodeMirror,[data-nova-preserve],[data-chart],[role="img"],input[type="image"],input[type="color"]';
const sensitive =
  'input[type="password"],input[autocomplete*="cc-"],input[autocomplete="one-time-code"],[role="alertdialog"],form[action*="login"],form[action*="checkout"],form[action*="payment"],[data-security]';
export function safeToHide(e: Element) {
  return (
    !e.matches(
      'html,body,main,form,input,select,textarea,button,[role="dialog"],[role="alert"],[role="status"]',
    ) &&
    !e.closest(`${sensitive},form,[role="dialog"]`) &&
    !e.querySelector(`${sensitive},form`)
  );
}
export class WebsiteEngine {
  private frozen = new WeakSet<HTMLElement>();
  private writes: { e: HTMLElement; p: string; v: string }[] | undefined;
  private attributes = new WeakMap<HTMLElement, boolean>();
  private computed = new WeakMap<HTMLElement, Record<string, string>>();
  freeze(e: HTMLElement) {
    this.frozen.add(e);
  }
  unfreeze(e: HTMLElement) {
    this.frozen.delete(e);
    this.enqueue(e);
  }
  private saved = new Map<HTMLElement, Map<string, Saved>>();
  private styles = new Map<Document | ShadowRoot, HTMLStyleElement>();
  private observers = new Map<Document | ShadowRoot, MutationObserver>();
  private queue: Element[] = [];
  private pending = new Set<Element>();
  private cursor?: TreeWalker;
  private roots = new Set<Document | ShadowRoot>();
  private scheduled = 0;
  private epoch = 0;
  private mutations = new WeakMap<Element, string>();
  config?: PageConfig;
  metrics = {
    processed: 0,
    slices: 0,
    maxSlice: 0,
    protected: 0,
    started: 0,
    queuePeak: 0,
    classification: 'unknown',
  };
  original(e: HTMLElement, p: string) {
    return this.computed.get(e)?.[p] ?? getComputedStyle(e).getPropertyValue(p);
  }
  private restoreNode(e: HTMLElement) {
    for (const [p, v] of this.saved.get(e) ?? [])
      if (e.style.getPropertyValue(p) === v.applied) {
        if (v.before) e.style.setProperty(p, v.before, v.priority);
        else e.style.removeProperty(p);
      }
    this.saved.delete(e);
    if (!e.style.length && this.attributes.get(e) === false) e.removeAttribute('style');
    this.attributes.delete(e);
    this.mutations.set(e, e.getAttribute('style') ?? '');
  }
  private set(e: HTMLElement, p: string, v: string) {
    if (this.writes) {
      this.writes.push({ e, p, v });
      return;
    }
    if (e.style.getPropertyValue(p) === v) return;
    let map = this.saved.get(e);
    if (!map) {
      map = new Map();
      this.saved.set(e, map);
      this.attributes.set(e, e.hasAttribute('style'));
    }
    if (!map.has(p))
      map.set(p, {
        before: e.style.getPropertyValue(p),
        priority: e.style.getPropertyPriority(p),
        applied: v,
      });
    else map.get(p)!.applied = v;
    e.style.setProperty(p, v, 'important');
    map.get(p)!.applied = e.style.getPropertyValue(p);
    this.mutations.set(e, e.getAttribute('style') ?? '');
  }
  stop() {
    this.epoch++;
    for (const o of this.observers.values()) o.disconnect();
    this.observers.clear();
    document.removeEventListener('pointerover', this.interaction, true);
    document.removeEventListener('focusin', this.interaction, true);
    if (this.scheduled) cancelAnimationFrame(this.scheduled);
    this.scheduled = 0;
    this.queue = [];
    this.pending.clear();
    this.cursor = undefined;
    for (const e of this.saved.keys()) this.restoreNode(e);
    for (const s of this.styles.values()) s.remove();
    this.styles.clear();
    this.roots.clear();
  }
  start(config: PageConfig) {
    this.stop();
    this.config = config;
    this.metrics = {
      processed: 0,
      slices: 0,
      maxSlice: 0,
      protected: 0,
      started: performance.now(),
      queuePeak: 0,
      classification: 'unknown',
    };
    const samples = [
      document.documentElement,
      document.body,
      ...document.querySelectorAll('main,article,header,nav,section'),
    ]
      .filter(Boolean)
      .slice(0, 16)
      .map((e) => color(getComputedStyle(e).backgroundColor))
      .filter((c) => c && c[3] > 0.8) as RGBA[];
    const light = samples.filter((c) => luminance(c) > 0.4).length,
      dark = samples.filter((c) => luminance(c) < 0.15).length;
    this.metrics.classification =
      light && dark ? 'mixed' : light ? 'light' : dark ? 'dark' : 'transparent';
    if (
      !config.theme &&
      !config.site?.focusEnabled &&
      !config.site?.reading &&
      !config.site?.reduceMotion
    )
      return;
    this.observe(document);
    this.enqueue(document.documentElement);
    document.addEventListener('pointerover', this.interaction, true);
    document.addEventListener('focusin', this.interaction, true);
  }
  private observe(root: Document | ShadowRoot) {
    if (this.roots.has(root) || this.roots.size >= 256) return;
    this.roots.add(root);
    const style = document.createElement('style');
    style.dataset.novaEngine = '';
    const c = this.config!,
      t = c.tokens;
    style.textContent =
      (c.theme
        ? `${root instanceof Document ? ':root' : ':host'}{${Object.entries(t)
            .map(([k, v]) => `--nova-${k}:${v}`)
            .join(
              ';',
            )};color-scheme:${luminance(color(t.base)!) > 0.4 ? 'light' : 'dark'}}\n a:focus-visible,button:focus-visible,input:focus-visible,textarea:focus-visible,select:focus-visible{outline:2px solid ${t.focus}!important;outline-offset:2px}\n::selection{background:${t.selection};color:${t.text}}`
        : '') +
      (c.site?.reduceMotion
        ? '*{scroll-behavior:auto!important;animation-duration:.001ms!important;transition-duration:.001ms!important}'
        : '') +
      (c.theme ? '\n' + c.website.css + '\n' + (c.site?.css ?? '') : '');
    if (root instanceof Document) (root.head ?? root.documentElement).append(style);
    else root.append(style);
    this.styles.set(root, style);
    const observer = new MutationObserver((records) => {
      for (const r of records) {
        if ((r.target as Element).closest?.('[data-nova-ui],[data-nova-engine]')) continue;
        if (r.type === 'attributes') {
          const e = r.target as Element;
          if (
            r.attributeName === 'style' &&
            this.mutations.get(e) === (e.getAttribute('style') ?? '')
          )
            continue;
          this.enqueue(e);
        } else
          for (const n of r.addedNodes)
            if (n instanceof Element && !n.matches('[data-nova-ui],[data-nova-engine]'))
              this.enqueue(n);
      }
      this.prune();
    });
    observer.observe(root, {
      subtree: true,
      childList: true,
      attributes: true,
      attributeFilter: ['class', 'style', 'hidden', 'aria-expanded', 'data-theme'],
    });
    this.observers.set(root, observer);
  }
  private interaction = (event: Event) => {
    const node = event.composedPath().find((n) => n instanceof HTMLElement) as
      HTMLElement | undefined;
    if (node) {
      const root = node.getRootNode();
      if (root instanceof ShadowRoot) this.observe(root);
      this.enqueue(node);
    }
  };
  private prune() {
    for (const root of this.roots)
      if (root instanceof ShadowRoot && !root.host.isConnected) {
        this.observers.get(root)?.disconnect();
        this.observers.delete(root);
        this.styles.get(root)?.remove();
        this.styles.delete(root);
        this.roots.delete(root);
      }
    if (this.saved.size < 1000) return;
    for (const e of this.saved.keys()) if (!e.isConnected) this.saved.delete(e);
  }
  private enqueue(e: Element) {
    if (!this.pending.has(e) && this.queue.length < 2000) {
      this.pending.add(e);
      this.queue.push(e);
      this.metrics.queuePeak = Math.max(this.metrics.queuePeak, this.queue.length);
    }
    if (!this.scheduled && !document.hidden)
      this.scheduled = requestAnimationFrame(() => this.drain());
  }
  resume() {
    if (this.queue.length && !this.scheduled && !document.hidden)
      this.scheduled = requestAnimationFrame(() => this.drain());
  }
  private drain() {
    this.scheduled = 0;
    if (document.hidden) return;
    this.writes = [];
    const start = performance.now(),
      budget = this.config!.website.performance === 'economical' ? 4 : 8;
    let count = 0;
    while (
      performance.now() - start < budget &&
      count++ < (this.config!.website.performance === 'economical' ? 30 : 80)
    ) {
      if (!this.cursor) {
        const root = this.queue.shift();
        if (!root) break;
        this.pending.delete(root);
        if (!root.isConnected) continue;
        this.process(root);
        this.cursor = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT, {
          acceptNode: (n) =>
            (n as Element).matches(protectedSelector + ',[data-nova-ui],[data-nova-engine]')
              ? NodeFilter.FILTER_REJECT
              : NodeFilter.FILTER_ACCEPT,
        });
      }
      const e = this.cursor.nextNode() as Element | null;
      if (e) this.process(e);
      else this.cursor = undefined;
    }
    const writes = this.writes;
    this.writes = undefined;
    for (const op of writes ?? []) this.set(op.e, op.p, op.v);
    this.metrics.slices++;
    this.metrics.maxSlice = Math.max(this.metrics.maxSlice, performance.now() - start);
    if (this.cursor || this.queue.length)
      this.scheduled = requestAnimationFrame(() => this.drain());
  }
  private process(node: Element) {
    if (!(node instanceof HTMLElement) || !node.isConnected || this.frozen.has(node)) return;
    const c = this.config!;
    if (node.closest('[data-nova-ui],[data-nova-engine]')) return;
    if (node.shadowRoot) {
      this.observe(node.shadowRoot);
      for (const e of node.shadowRoot.children) this.enqueue(e);
    }
    this.restoreNode(node);
    this.metrics.processed++;
    let preserve = node.matches(protectedSelector) || !!node.closest(sensitive);
    try {
      preserve ||= c.website.preserve.some((s) => !!node.closest(s));
    } catch {
      preserve = true;
    }
    const rules = c.site?.elements ?? [];
    const rule = rules.find((r) => {
      try {
        return node.matches(r.selector);
      } catch {
        return false;
      }
    });
    preserve ||= rule?.preserve ?? false;
    if (preserve) {
      this.metrics.protected++;
      return;
    }
    if (c.site?.focusEnabled && safeToHide(node)) {
      try {
        if (c.site.focus.some((s) => node.matches(s))) {
          this.set(node, 'display', 'none');
          return;
        }
      } catch {}
    }
    if (c.site?.reading && node.matches('main,article,[role="main"]')) {
      this.set(node, 'max-width', '78ch');
      this.set(node, 'margin-inline', 'auto');
      this.set(node, 'line-height', '1.7');
    }
    const mode = c.site?.mode ?? c.website.mode;
    if (!c.theme || mode === 'original' || c.website.intensity === 0) return;
    const style = getComputedStyle(node);
    if (/url\(|image-set\(/.test(style.backgroundImage)) return;
    this.computed.set(node, {
      'background-color': style.backgroundColor,
      color: style.color,
      'border-color': style.borderColor,
    });
    const originalBG = color(style.backgroundColor),
      fg = color(style.color);
    if (!fg) return;
    let parent: RGBA = color(c.tokens.base)!;
    let ancestor = node.parentElement;
    for (let i = 0; ancestor && i < 8; i++, ancestor = ancestor.parentElement) {
      const b = color(getComputedStyle(ancestor).backgroundColor);
      if (b && b[3] > 0.95) {
        const mapped =
          ancestor === document.body || ancestor === document.documentElement
            ? color(c.tokens.base)!
            : surface(b, c.tokens);
        parent =
          mode === 'dark-only' && luminance(b) > 0.25
            ? b
            : mix(b, mapped, c.website.intensity / 100);
        break;
      }
    }
    const effective = originalBG ? composite(originalBG, parent) : parent;
    if (mode === 'dark-only' && luminance(effective) > 0.25) return;
    const t = c.tokens,
      intensity = c.website.intensity / 100;
    let bg: RGBA = parent;
    if (node === document.documentElement && (!originalBG || originalBG[3] < 0.01)) {
      bg = color(t.base)!;
      this.set(node, 'background-color', css(bg));
    }
    if (originalBG && originalBG[3] > 0.01) {
      let mapped =
        node === document.body || node === document.documentElement
          ? color(t.base)!
          : surface(originalBG, t);
      if (
        mode === 'smart' &&
        Math.max(...originalBG.slice(0, 3)) - Math.min(...originalBG.slice(0, 3)) > 50
      )
        mapped = mix(
          mapped,
          color(t.highlight)!,
          node.matches('button,[role=button],[aria-selected=true]') ? 0.22 : 0.1,
        );
      mapped[3] = originalBG[3];
      bg = mix(originalBG, mapped, intensity);
      this.set(node, 'background-color', css(bg));
      bg = composite(bg, parent);
    }
    // Only replace parsed color stops of CSS gradients. URLs and unrecognized color spaces stay intact.
    if (
      /gradient\(/.test(style.backgroundImage) &&
      !/(url\(|image-set\()/.test(style.backgroundImage)
    ) {
      const g = style.backgroundImage.replace(/rgba?\([^)]+\)/g, (v) => {
        const x = color(v);
        if (!x) return v;
        const mapped = surface(x, t);
        mapped[3] = x[3];
        return css(mix(x, mapped, intensity));
      });
      this.set(node, 'background-image', g);
    }
    const saturation = (Math.max(...fg.slice(0, 3)) - Math.min(...fg.slice(0, 3))) / 255;
    let mapped = color(node.matches('a') ? t.link : saturation > 0.2 ? t.accent : t.text)!;
    if (saturation > 0.2 && c.website.saturation < 100) {
      const gray = mapped.slice(0, 3).reduce((a, b) => a + b, 0) / 3;
      mapped = mix([gray, gray, gray, 1], mapped, c.website.saturation / 100);
    }
    if (style.boxShadow !== 'none')
      this.set(
        node,
        'box-shadow',
        style.boxShadow.replace(/rgba?\([^)]+\)/g, (v) => {
          const x = color(v),
            shadow = color(t.shadow)!;
          if (!x) return v;
          shadow[3] = x[3];
          return css(mix(x, shadow, intensity));
        }),
      );
    this.set(node, 'color', css(readable(mix(fg, mapped, intensity), bg, c.website.contrast, t)));
    for (const p of [
      'border-top-color',
      'border-right-color',
      'border-bottom-color',
      'border-left-color',
    ]) {
      const v = color(style.getPropertyValue(p));
      if (v && v[3] > 0.01) {
        const b = color(t.border)!;
        b[3] = v[3];
        this.set(node, p, css(mix(v, b, intensity)));
      }
    }
    if (rule) {
      for (const [k, v] of Object.entries(rule.colors))
        if (v)
          this.set(
            node,
            k === 'base'
              ? 'background-color'
              : k === 'text'
                ? 'color'
                : k === 'accent'
                  ? 'accent-color'
                  : 'border-color',
            v,
          );
    }
    if (node.matches('input,select,textarea')) this.set(node, 'accent-color', t.accent);
  }
}
