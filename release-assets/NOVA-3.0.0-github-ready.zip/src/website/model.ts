import { palettes, type Palette, type Tokens, validatePalette, validCSS } from '../themes/tokens';
export type ThemeMode = 'smart' | 'force' | 'dark-only' | 'original' | 'custom';
export interface ElementRule {
  selector: string;
  preserve: boolean;
  colors: Partial<Pick<Tokens, 'base' | 'text' | 'accent' | 'border'>>;
}
export interface SiteRule {
  id: string;
  domain: string;
  subdomains: boolean;
  priority: number;
  enabled: boolean;
  mode: ThemeMode;
  palette: string;
  inheritPalette: boolean;
  tokens: Partial<Tokens>;
  css: string;
  elements: ElementRule[];
  focus: string[];
  focusEnabled: boolean;
  reading: boolean;
  reduceMotion: boolean;
}
export interface WebsiteSettings {
  enabled: boolean;
  mode: ThemeMode;
  palette: string;
  sync: boolean;
  followSystem: boolean;
  intensity: number;
  contrast: number;
  saturation: number;
  performance: 'balanced' | 'economical';
  preserve: string[];
  css: string;
  sites: SiteRule[];
  allowlist: string[];
  blocklist: string[];
  listMode: 'all' | 'allowlist';
  custom: Palette[];
}
export interface AdaptiveRule {
  id: string;
  name: string;
  kind: 'time' | 'system' | 'profile';
  start: string;
  end: string;
  system: 'dark' | 'light';
  profile: string;
  palette: string;
  priority: number;
  enabled: boolean;
}
export interface Suite {
  website: WebsiteSettings;
  adaptive: { enabled: boolean; manualUntil: number; manualPalette: string; rules: AdaptiveRule[] };
  tabs: {
    width: number;
    compact: boolean;
    collapse: boolean;
    minimal: boolean;
    assignments: Record<string, string>;
  };
  commands: {
    enabled: boolean;
    websites: boolean;
    shortcut: string;
    focusShortcut: string;
    favorites: string[];
    recent: string[];
  };
}
export function suiteDefaults(): Suite {
  return {
    website: {
      enabled: false,
      mode: 'smart',
      palette: 'mocha',
      sync: false,
      followSystem: false,
      intensity: 100,
      contrast: 4.5,
      saturation: 100,
      performance: 'balanced',
      preserve: ['[contenteditable]', '.monaco-editor', '.CodeMirror', '[data-nova-preserve]'],
      css: '',
      sites: [],
      allowlist: [],
      blocklist: [],
      listMode: 'all',
      custom: [],
    },
    adaptive: { enabled: false, manualUntil: 0, manualPalette: 'mocha', rules: [] },
    tabs: { width: 340, compact: false, collapse: false, minimal: false, assignments: {} },
    commands: {
      enabled: true,
      websites: false,
      shortcut: 'Alt+Shift+P',
      focusShortcut: 'Alt+Shift+D',
      favorites: [],
      recent: [],
    },
  };
}
export function domain(value: string) {
  let host = value.trim().toLowerCase();
  if (/^[a-z]+:\/\//i.test(host)) host = new URL(host).hostname;
  host = host.replace(/\.$/, '');
  if (
    host.includes('/') ||
    host.includes('*') ||
    host.includes(':') ||
    !/^([a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)*[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/.test(host) ||
    host.length > 253
  )
    throw Error('Use an exact domain without paths, wildcards or ports.');
  return host;
}
export function matches(host: string, rule: Pick<SiteRule, 'domain' | 'subdomains'>) {
  return host === rule.domain || (rule.subdomains && host.endsWith('.' + rule.domain));
}
export function selector(value: string) {
  if (!value.trim() || value.length > 300 || /[{}<>]|:has\(/.test(value))
    throw Error('Use a conservative CSS selector.');
  return value.trim();
}
export function newSite(host: string): SiteRule {
  return {
    id: crypto.randomUUID(),
    domain: domain(host),
    subdomains: false,
    priority: 10,
    enabled: true,
    mode: 'smart',
    palette: 'mocha',
    inheritPalette: true,
    tokens: {},
    css: '',
    elements: [],
    focus: [],
    focusEnabled: false,
    reading: false,
    reduceMotion: false,
  };
}
export function validateSuite(s: Suite) {
  const w = s.website;
  if (
    !['smart', 'force', 'dark-only', 'original', 'custom'].includes(w.mode) ||
    !['balanced', 'economical'].includes(w.performance) ||
    !['all', 'allowlist'].includes(w.listMode)
  )
    throw Error('Invalid website mode.');
  for (const [v, min, max] of [
    [w.intensity, 0, 100],
    [w.contrast, 3, 7],
    [w.saturation, 0, 150],
    [s.tabs.width, 240, 600],
    [s.adaptive.manualUntil, 0, Number.MAX_SAFE_INTEGER],
  ] as number[][])
    if (!Number.isFinite(v) || v < min || v > max)
      throw Error('Suite setting outside supported range.');
  validCSS(w.css);
  if (
    w.sites.length > 300 ||
    w.custom.length > 100 ||
    w.preserve.length > 100 ||
    w.allowlist.length > 300 ||
    w.blocklist.length > 300 ||
    s.adaptive.rules.length > 100
  )
    throw Error('Too many rules.');
  w.preserve = w.preserve.map(selector);
  w.allowlist = w.allowlist.map(domain);
  w.blocklist = w.blocklist.map(domain);
  w.custom = w.custom.map(validatePalette);
  if (w.custom.some((p) => palettes.some((v) => v.id === p.id)))
    throw Error(
      'Custom theme IDs cannot replace curated palettes. Duplicate the theme with a new ID.',
    );
  if (new Set(w.custom.map((p) => p.id)).size !== w.custom.length)
    throw Error('Theme IDs must be unique.');
  const text = (v: unknown, max: number) => {
    if (typeof v !== 'string' || v.length > max) throw Error('Invalid suite text.');
  };
  const toggle = (v: unknown) => {
    if (typeof v !== 'boolean') throw Error('Invalid suite toggle.');
  };
  const id = (v: unknown) => {
    text(v, 100);
    if (!v || ['__proto__', 'constructor', 'prototype'].includes(String(v)))
      throw Error('Invalid rule identity.');
  };
  text(w.palette, 100);
  text(s.adaptive.manualPalette, 100);
  for (const [key, value] of Object.entries(s.tabs.assignments)) {
    if (!/^\d+$/.test(key)) throw Error('Invalid tab assignment.');
    text(value, 100);
  }
  for (const x of [...s.commands.recent, ...s.commands.favorites]) text(x, 200);
  for (const r of w.sites) {
    r.inheritPalette ??= true;
    id(r.id);
    text(r.palette, 100);
    for (const v of [
      r.inheritPalette,
      r.subdomains,
      r.enabled,
      r.focusEnabled,
      r.reading,
      r.reduceMotion,
    ])
      toggle(v);
    if (
      !r.tokens ||
      typeof r.tokens !== 'object' ||
      !Array.isArray(r.elements) ||
      !Array.isArray(r.focus)
    )
      throw Error('Invalid site overrides.');
    for (const k of Object.keys(r.tokens))
      if (!Object.hasOwn(palettes[0].tokens, k)) throw Error('Unknown site token.');
    for (const e of r.elements) {
      toggle(e.preserve);
      if (
        !e.colors ||
        typeof e.colors !== 'object' ||
        Object.keys(e.colors).some((k) => !['base', 'text', 'accent', 'border'].includes(k))
      )
        throw Error('Invalid element override.');
    }
  }
  const adaptiveIds = new Set<string>();
  for (const r of s.adaptive.rules) {
    id(r.id);
    if (adaptiveIds.has(r.id)) throw Error('Adaptive IDs must be unique.');
    adaptiveIds.add(r.id);
    text(r.name, 80);
    text(r.palette, 100);
    text(r.profile, 100);
    toggle(r.enabled);
  }
  const ids = new Set<string>();
  for (const r of w.sites) {
    if (!r.id || ids.has(r.id)) throw Error('Site IDs must be unique.');
    ids.add(r.id);
    r.domain = domain(r.domain);
    if (
      !['smart', 'force', 'dark-only', 'original', 'custom'].includes(r.mode) ||
      !Number.isFinite(r.priority) ||
      r.priority < 0 ||
      r.priority > 100
    )
      throw Error('Invalid site rule.');
    validCSS(r.css);
    if (r.elements.length > 200 || r.focus.length > 100) throw Error('Too many element rules.');
    r.focus = r.focus.map(selector);
    for (const e of r.elements) {
      e.selector = selector(e.selector);
      for (const c of Object.values(e.colors))
        if (!/^#[a-f0-9]{6}$/i.test(c)) throw Error('Invalid element color.');
    }
    for (const [k, c] of Object.entries(r.tokens)) {
      if (k === 'gradient')
        validatePalette({ ...palettes[0], tokens: { ...palettes[0].tokens, gradient: c } });
      else if (!/^#[a-f0-9]{6}$/i.test(c)) throw Error('Invalid site color.');
    }
  }
  for (const r of s.adaptive.rules)
    if (
      !r.id ||
      !['time', 'system', 'profile'].includes(r.kind) ||
      !/^([01]\d|2[0-3]):[0-5]\d$/.test(r.start) ||
      !/^([01]\d|2[0-3]):[0-5]\d$/.test(r.end) ||
      r.priority < 0 ||
      r.priority > 100 ||
      !['dark', 'light'].includes(r.system)
    )
      throw Error('Invalid adaptive schedule.');
  for (const key of [s.commands.shortcut, s.commands.focusShortcut])
    if (key.length > 80 || !/(Alt|Ctrl|Meta)\+/.test(key))
      throw Error('Use a shortcut with a modifier.');
  if (
    s.commands.recent.length > 30 ||
    s.commands.favorites.length > 100 ||
    Object.keys(s.tabs.assignments).length > 10000
  )
    throw Error('Too many stored commands or tab assignments.');
  return s;
}
export function siteConfig(w: WebsiteSettings, host: string) {
  return w.sites
    .filter((r) => matches(host, r))
    .sort((a, b) => b.priority - a.priority || b.domain.length - a.domain.length)[0];
}
export function resolvePalette(s: Suite, profile: string, now = new Date(), dark = true): string {
  if (s.adaptive.manualUntil > now.getTime()) return s.adaptive.manualPalette;
  if (s.adaptive.enabled) {
    const mins = now.getHours() * 60 + now.getMinutes();
    const r = s.adaptive.rules
      .filter(
        (r) =>
          r.enabled &&
          (r.kind === 'profile'
            ? r.profile === profile
            : r.kind === 'system'
              ? r.system === (dark ? 'dark' : 'light')
              : (() => {
                  const [a, b] = [r.start, r.end].map(
                    (v) => Number(v.slice(0, 2)) * 60 + Number(v.slice(3)),
                  );
                  return a === b || a < b
                    ? (mins >= a && mins < b) || a === b
                    : mins >= a || mins < b;
                })()),
      )
      .sort((a, b) => b.priority - a.priority)[0];
    if (r) return r.palette;
  }
  if (s.website.followSystem) return dark ? 'mocha' : 'latte';
  return s.website.palette;
}
export function paletteExists(w: WebsiteSettings, id: string) {
  return [...palettes, ...w.custom].some((p) => p.id === id);
}
// Match-pattern ports are unsupported in Firefox. Host grants already cover every port.
export function hostPattern(value: string) {
  const url = new URL(value);
  if (!['http:', 'https:'].includes(url.protocol)) throw Error('Website URL required.');
  return `${url.protocol}//${url.hostname}/*`;
}
