import type { Tokens } from '../themes/tokens';
export type RGBA = [number, number, number, number];
export function color(s: string): RGBA | null {
  const h = s.match(/^#([a-f\d]{6}|[a-f\d]{3})$/i);
  if (h) {
    const v =
      h[1].length === 3
        ? h[1]
            .split('')
            .map((c) => c + c)
            .join('')
        : h[1];
    return [
      parseInt(v.slice(0, 2), 16),
      parseInt(v.slice(2, 4), 16),
      parseInt(v.slice(4, 6), 16),
      1,
    ];
  }
  const m = s.match(/^rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:\s*[,/]\s*([\d.]+))?\s*\)$/);
  return m ? [+m[1], +m[2], +m[3], m[4] === undefined ? 1 : +m[4]] : null;
}
export function luminance(c: RGBA) {
  const x = c.slice(0, 3).map((v) => {
    v /= 255;
    return v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
  });
  return x[0] * 0.2126 + x[1] * 0.7152 + x[2] * 0.0722;
}
export function contrast(a: RGBA, b: RGBA) {
  const x = luminance(a),
    y = luminance(b);
  return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
}
export function composite(a: RGBA, b: RGBA): RGBA {
  return [
    a[0] * a[3] + b[0] * (1 - a[3]),
    a[1] * a[3] + b[1] * (1 - a[3]),
    a[2] * a[3] + b[2] * (1 - a[3]),
    1,
  ];
}
export function mix(a: RGBA, b: RGBA, t: number): RGBA {
  return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t, a[3]];
}
export function css(c: RGBA) {
  return `rgba(${c
    .slice(0, 3)
    .map((v) => Math.round(v))
    .join(',')},${c[3]})`;
}
// Perceptual lightness partitions surfaces instead of tinting every node identically.
export function lightness(c: RGBA) {
  const y = luminance(c);
  return y > 0.008856 ? 116 * Math.cbrt(y) - 16 : 903.3 * y;
}
export function surface(c: RGBA, t: Tokens): RGBA {
  const l = lightness(c);
  return color(
    t[
      l < 12
        ? 'crust'
        : l < 25
          ? 'mantle'
          : l < 45
            ? 'base'
            : l < 65
              ? 'surface0'
              : l < 82
                ? 'surface1'
                : 'surface2'
    ],
  )!;
}
export function readable(f: RGBA, b: RGBA, target: number, t: Tokens) {
  if (contrast(f, b) >= target) return f;
  const choices = [color(t.text)!, [255, 255, 255, 1] as RGBA, [0, 0, 0, 1] as RGBA];
  return choices.sort((a, c) => contrast(c, b) - contrast(a, b))[0];
}
