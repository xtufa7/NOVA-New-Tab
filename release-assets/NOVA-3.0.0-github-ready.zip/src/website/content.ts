import '../shared/platform';
import { WebsiteEngine, type PageConfig } from './engine';
import { inspect } from './inspector';
import { openPalette, send, paletteShortcut } from '../commands/palette';
import { overlayCSS } from './overlay';
const win = window as unknown as { __novaSuite?: boolean };
if (!win.__novaSuite) {
  win.__novaSuite = true;
  const engine = new WebsiteEngine();
  let fingerprint = '';
  let config: PageConfig,
    host: HTMLDivElement | undefined,
    root: ShadowRoot | undefined,
    cleanup: (() => void) | undefined;
  const surface = () => {
    if (!root) {
      host = document.createElement('div');
      host.dataset.novaUi = '';
      host.style.cssText =
        'all:initial;position:fixed;inset:0;z-index:2147483646;pointer-events:none';
      root = host.attachShadow({ mode: 'closed' });
      const style = document.createElement('style');
      style.textContent = overlayCSS;
      root.append(style);
      document.documentElement.append(host);
    }
    return root;
  };
  const refresh = async () => {
    try {
      config = await send('suite-config');
      const next = JSON.stringify(config);
      if (next !== fingerprint) {
        fingerprint = next;
        engine.start(config);
      }
    } catch {
      engine.stop();
      cleanup?.();
      host?.remove();
      root = undefined;
      host = undefined;
    }
  };
  const system = matchMedia('(prefers-color-scheme: dark)');
  system.addEventListener('change', () => {
    void send('suite-system', { dark: system.matches })
      .then(refresh)
      .catch(() => {});
  });
  document.addEventListener('keydown', (e) => {
    if (!config || window.top !== window || !config.shortcuts.enabled || !config.shortcuts.websites)
      return;
    if (paletteShortcut(e, config.shortcuts.shortcut)) {
      e.preventDefault();
      cleanup?.();
      cleanup = openPalette(surface());
    }
    if (paletteShortcut(e, config.shortcuts.focusShortcut)) {
      e.preventDefault();
      void send('suite-command', { id: 'focus-site' }).catch(() => {});
    }
  });
  chrome.runtime.onMessage.addListener((m, _sender, respond) => {
    if (m.type === 'nova-suite-refresh') {
      void refresh().then(() => respond({}));
      return true;
    }
    if (m.type === 'nova-inspect' || m.type === 'nova-focus-pick') {
      cleanup?.();
      cleanup = inspect(engine, surface(), m.type === 'nova-focus-pick');
      respond({});
    }
    if (m.type === 'nova-palette') {
      cleanup?.();
      cleanup = openPalette(surface());
      respond({});
    }
    if (m.type === 'nova-metrics') respond(engine.metrics);
  });
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) {
      engine.resume();
      void refresh();
    }
  });
  window.addEventListener('pagehide', () => {
    cleanup?.();
    engine.stop();
    host?.remove();
    root = undefined;
    host = undefined;
  });
  window.addEventListener('pageshow', (e) => {
    if (e.persisted) void refresh();
  });
  void refresh();
}
