import { el } from '../shared/dom';
import { color, contrast } from './color';
import { WebsiteEngine, safeToHide } from './engine';
import { send } from '../commands/palette';
export function stableSelector(e: Element): string {
  if (e === document.body) return 'body';
  if (e === document.documentElement) return 'html';
  if (e.id && document.querySelectorAll('#' + CSS.escape(e.id)).length === 1)
    return '#' + CSS.escape(e.id);
  for (const attr of ['data-testid', 'data-test', 'aria-label']) {
    const v = e.getAttribute(attr);
    if (v && v.length < 80) {
      const s = `${e.localName}[${attr}="${CSS.escape(v)}"]`;
      if (document.querySelectorAll(s).length === 1) return s;
    }
  }
  const pieces: string[] = [];
  let node: Element | null = e;
  while (node && node !== document.body && pieces.length < 6) {
    const same = [...(node.parentElement?.children ?? [])].filter(
      (n) => n.localName === node!.localName,
    );
    pieces.unshift(
      node.localName + (same.length > 1 ? `:nth-of-type(${same.indexOf(node) + 1})` : ''),
    );
    node = node.parentElement;
  }
  return pieces.join(' > ');
}
export function inspect(engine: WebsiteEngine, root: ShadowRoot, focus = false) {
  root.querySelector('.nova-inspector')?.remove();
  const panel = el('section', 'nova-inspector'),
    highlight = el('div', 'nova-highlight'),
    heading = el('h2', '', focus ? 'Focus picker' : 'Theme Inspector'),
    info = el('pre', 'inspector-info', 'Click a page element to inspect it.'),
    controls = el('div'),
    status = el('p');
  panel.append(heading, info, controls, status);
  root.append(panel, highlight);
  let chosen: HTMLElement | undefined,
    selector = '',
    snapshot = '',
    undos: { css: string; colors: Record<string, string> }[] = [],
    redos: { css: string; colors: Record<string, string> }[] = [];
  const button = (label: string, fn: () => unknown) => {
    const b = el('button', '', label);
    b.addEventListener(
      'click',
      () =>
        void Promise.resolve()
          .then(fn)
          .catch((e) => {
            status.textContent = e instanceof Error ? e.message : String(e);
          }),
    );
    return b;
  };
  const cleanup = () => {
    if (chosen) {
      chosen.style.cssText = snapshot;
      engine.unfreeze(chosen);
    }
    document.removeEventListener('pointermove', move, true);
    document.removeEventListener('click', pick, true);
    document.removeEventListener('keydown', key, true);
    panel.remove();
    highlight.remove();
  };
  const key = (e: KeyboardEvent) => {
    if (e.key === 'Escape') {
      e.preventDefault();
      cleanup();
    }
  };
  const move = (e: PointerEvent) => {
    const target = e.composedPath()[0];
    if (!(target instanceof HTMLElement) || target.closest('[data-nova-ui]')) return;
    const r = target.getBoundingClientRect();
    Object.assign(highlight.style, {
      left: r.left + 'px',
      top: r.top + 'px',
      width: r.width + 'px',
      height: r.height + 'px',
    });
  };
  const pick = (event: MouseEvent) => {
    const target = event.composedPath()[0];
    if (!(target instanceof HTMLElement) || target.closest('[data-nova-ui]')) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (chosen) {
      chosen.style.cssText = snapshot;
      engine.unfreeze(chosen);
    }
    chosen = target;
    engine.freeze(target);
    snapshot = target.style.cssText;
    selector = stableSelector(target);
    undos = [];
    redos = [];
    const s = getComputedStyle(target),
      fg = color(s.color),
      bg = color(s.backgroundColor);
    info.textContent =
      selector +
      '\nOriginal background: ' +
      engine.original(target, 'background-color') +
      '\nCurrent: ' +
      s.backgroundColor +
      ' / ' +
      s.color +
      '\nContrast: ' +
      (fg && bg && bg[3] === 1
        ? contrast(fg, bg).toFixed(2) + ':1'
        : 'transparent; inherited surface') +
      '\nPalette: ' +
      (engine.config?.site?.palette ?? engine.config?.website.palette) +
      '\nRule: ' +
      (engine.config?.site?.domain ?? 'global') +
      '\nCSS variables: ' +
      [...s]
        .filter((k) => k.startsWith('--'))
        .slice(0, 12)
        .map((k) => k + ': ' + s.getPropertyValue(k))
        .join(', ') +
      '\nMatches: ' +
      document.querySelectorAll(selector).length;
    controls.replaceChildren();
    if (target.getRootNode() instanceof ShadowRoot) {
      status.textContent =
        'Shadow content is themed, but a persistent document selector cannot safely address this element.';
      return;
    }
    if (focus) {
      controls.append(
        button('Hide this distraction', async () => {
          if (!safeToHide(target))
            throw Error('Forms, main content and security dialogs are protected.');
          target.style.cssText = snapshot;
          engine.unfreeze(target);
          await send('suite-site-save', { focus: selector });
          engine.unfreeze(target);
          chosen = undefined;
          cleanup();
        }),
      );
      return;
    }
    const colors: Record<string, string> = {};
    for (const [token, property] of [
      ['base', 'background-color'],
      ['text', 'color'],
      ['border', 'border-color'],
    ] as const) {
      const row = el('label', '', token),
        input = el('input');
      input.type = 'color';
      input.value = engine.config?.tokens[token] ?? '#1e1e2e';
      input.setAttribute('aria-label', 'Inspector ' + token);
      row.append(input);
      controls.append(row);
      input.addEventListener('input', () => {
        undos.push({ css: target.style.cssText, colors: { ...colors } });
        redos = [];
        colors[token] = input.value;
        target.style.setProperty(property, input.value, 'important');
      });
    }
    controls.append(
      button('Undo', () => {
        const v = undos.pop();
        if (v !== undefined) {
          redos.push({ css: target.style.cssText, colors: { ...colors } });
          target.style.cssText = v.css;
          for (const k of Object.keys(colors)) delete colors[k];
          Object.assign(colors, v.colors);
        }
      }),
      button('Redo', () => {
        const v = redos.pop();
        if (v !== undefined) {
          undos.push({ css: target.style.cssText, colors: { ...colors } });
          target.style.cssText = v.css;
          for (const k of Object.keys(colors)) delete colors[k];
          Object.assign(colors, v.colors);
        }
      }),
      button('Save override', async () => {
        const count = document.querySelectorAll(selector).length;
        if (count !== 1) {
          status.textContent =
            'This selector matches ' + count + ' elements. Choose a unique element before saving.';
          return;
        }
        target.style.cssText = snapshot;
        engine.unfreeze(target);
        await send('suite-site-save', { element: { selector, preserve: false, colors } });
        engine.unfreeze(target);
        chosen = undefined;
        cleanup();
      }),
      button('Preserve original colors', async () => {
        target.style.cssText = snapshot;
        engine.unfreeze(target);
        await send('suite-site-save', { element: { selector, preserve: true, colors: {} } });
        engine.unfreeze(target);
        chosen = undefined;
        cleanup();
      }),
      button('Reset element override', async () => {
        target.style.cssText = snapshot;
        engine.unfreeze(target);
        await send('suite-site-save', { elementRemove: selector });
        engine.unfreeze(target);
        chosen = undefined;
        cleanup();
      }),
      button('Reset site overrides', async () => {
        target.style.cssText = snapshot;
        engine.unfreeze(target);
        await send('suite-site-save', { reset: true });
        engine.unfreeze(target);
        chosen = undefined;
        cleanup();
      }),
    );
  };
  panel.append(button('Close inspector', cleanup));
  document.addEventListener('pointermove', move, true);
  document.addEventListener('click', pick, true);
  document.addEventListener('keydown', key, true);
  return cleanup;
}
