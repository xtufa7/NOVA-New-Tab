import '../shared/platform';
import { loadSettings, getSettings } from '../storage/settings';
import { renderAppearance } from '../newtab/appearance';
import { el, button, report } from '../shared/dom';
import { send, openPalette } from '../commands/palette';
const root = document.querySelector<HTMLElement>('#tab-manager')!;
let filter = '',
  workspace = '',
  selected = new Set<number>(),
  snapshot: Record<string, { data: string; created: number }> = {},
  refreshTimer: ReturnType<typeof setTimeout>;
const act = (action: string, data: Record<string, unknown> = {}) =>
  send('suite-tab-action', { action, ...data }).then(refresh);
function request(permissions: chrome.runtime.ManifestPermission[]) {
  return chrome.permissions.request({ permissions }).then((ok) => {
    if (!ok) throw Error('Permission was declined.');
    return refresh();
  });
}
async function refresh() {
  const prior = document.activeElement?.getAttribute('aria-label'),
    position = root.scrollTop;
  root.replaceChildren();
  const s = getSettings(),
    c = s.suite.tabs;
  root.style.setProperty('--manager-width', c.width + 'px');
  root.classList.toggle('compact', c.compact);
  root.classList.toggle('collapsed', c.collapse);
  root.classList.toggle('minimal', c.minimal);
  const header = el('header', 'manager-header');
  header.append(
    el('span', 'wordmark', 'NØVA'),
    button('⌘', () => openPalette(), ''),
    button('Settings', () =>
      chrome.tabs.create({ url: chrome.runtime.getURL('settings.html') + '#Tab%20Manager' }),
    ),
  );
  root.append(header);
  if (!(await chrome.permissions.contains({ permissions: ['tabs'] }))) {
    root.append(
      el('h1', '', 'Your tabs, in one place.'),
      el(
        'p',
        'muted',
        'Allow tab access to show titles and organize open tabs. Data stays on your device.',
      ),
      button('Allow tab access', () => request(['tabs']), 'primary'),
    );
    return;
  }
  const data = await send('suite-tabs');
  const tabs = data.tabs as chrome.tabs.Tab[],
    groups = data.groups as chrome.tabGroups.TabGroup[];
  snapshot = data.snapshots;
  const tools = el('div', 'manager-tools'),
    search = el('input'),
    space = el('select');
  search.placeholder = 'Search open tabs…';
  search.value = filter;
  search.setAttribute('aria-label', 'Search tabs');
  search.addEventListener('input', () => {
    filter = search.value;
    paint();
  });
  space.setAttribute('aria-label', 'Workspace filter');
  for (const [id, name] of [
    ['', 'All workspaces'],
    ['unassigned', 'Unassigned'],
    ...s.profiles.map((p) => [p.id, p.name]),
  ]) {
    const o = el('option', '', name);
    o.value = id;
    space.append(o);
  }
  space.value = workspace;
  space.addEventListener('change', () => {
    workspace = space.value;
    paint();
  });
  tools.append(search, space);
  root.append(tools);
  const actions = el('details', 'manager-actions');
  actions.append(el('summary', '', 'Organize tabs'));
  actions.append(
    button('Sort by title', () => act('sort')),
    button('Remove duplicates', () => act('deduplicate')),
    button('Save window session', () => {
      const name = prompt('Session name', 'My session');
      if (name) return act('save', { value: name });
    }),
    button('Discard selected', () => act('discard', { ids: [...selected] })),
    button('Close selected', () => act('close', { ids: [...selected] })),
    button('Reopen last closed', () => request(['sessions']).then(() => act('reopen'))),
  );
  const assign = el('select');
  assign.setAttribute('aria-label', 'Assign selected workspace');
  assign.append(el('option', '', 'Move selected to workspace…'));
  for (const p of s.profiles) {
    const o = el('option', '', p.name);
    o.value = p.id;
    assign.append(o);
  }
  assign.addEventListener('change', () => {
    void act('workspace', { ids: [...selected], value: assign.value }).catch(report);
  });
  actions.append(assign);
  if (chrome.tabGroups)
    actions.append(
      button('Group selected', async () => {
        await request(['tabGroups']);
        const name = prompt('Group name', 'NØVA');
        if (name) await act('group', { ids: [...selected], value: name });
      }),
    );
  else actions.append(el('small', 'muted', 'Native groups unavailable; use workspaces.'));
  root.append(actions);
  const list = el('div', 'manager-list');
  root.append(list);
  function paint() {
    list.replaceChildren();
    const visible = tabs.filter((t) => {
      const assigned = c.assignments[String(t.id)] ?? '';
      return (
        (!workspace || (workspace === 'unassigned' ? !assigned : assigned === workspace)) &&
        ((t.title ?? '') + ' ' + (t.url ?? '')).toLowerCase().includes(filter.toLowerCase())
      );
    });
    const pinned = visible.filter((t) => t.pinned),
      ordinary = visible.filter((t) => !t.pinned);
    if (pinned.length) list.append(el('h3', '', 'Pinned'));
    for (const t of [...pinned, ...ordinary]) {
      const row = el('article', 'tab-row'),
        select = el('input'),
        title = el('button', 'tab-title'),
        icon = el('span', 'tab-icon', '◈'),
        controls = el('div', 'tab-actions');
      row.dataset.tabId = String(t.id);
      row.draggable = true;
      row.classList.toggle('active', !!t.active);
      row.classList.toggle('discarded', !!t.discarded);
      select.type = 'checkbox';
      select.checked = selected.has(t.id!);
      select.setAttribute('aria-label', 'Select ' + (t.title ?? 'tab'));
      select.addEventListener('change', () => {
        if (select.checked) selected.add(t.id!);
        else selected.delete(t.id!);
      });
      title.type = 'button';
      title.append(
        el('span', '', t.title || 'Untitled tab'),
        el('small', '', t.url?.replace(/^https?:\/\//, '').slice(0, 100) ?? ''),
      );
      title.addEventListener('click', () => void act('switch', { id: t.id }).catch(report));
      if (
        t.favIconUrl &&
        /^(https?:|data:image\/|chrome-extension:|moz-extension:)/.test(t.favIconUrl)
      ) {
        const image = el('img');
        image.alt = '';
        image.loading = 'lazy';
        image.src = t.favIconUrl;
        image.addEventListener('error', () => icon.replaceChildren(document.createTextNode('◈')));
        icon.replaceChildren(image);
      }
      const action = (label: string, name: string, value?: boolean) => {
        const b = button(label, () => act(name, { id: t.id, value }));
        b.setAttribute('aria-label', label + ' ' + (t.title ?? 'tab'));
        return b;
      };
      controls.append(
        action(t.pinned ? 'Unpin' : 'Pin', 'pin', !t.pinned),
        action(t.mutedInfo?.muted ? 'Unmute' : 'Mute', 'mute', !t.mutedInfo?.muted),
        action('Duplicate', 'duplicate'),
        action('Close', 'close'),
      );
      row.append(select, icon, title, controls);
      if (t.groupId !== undefined && t.groupId >= 0) {
        const group = groups.find((g) => g.id === t.groupId);
        if (group) row.append(el('small', 'tab-group', group.title ?? 'Group'));
      }
      row.addEventListener('dragstart', (e) =>
        e.dataTransfer?.setData('text/nova-tab', String(t.id)),
      );
      row.addEventListener('dragover', (e) => e.preventDefault());
      row.addEventListener('drop', (e) => {
        e.preventDefault();
        const id = Number(e.dataTransfer?.getData('text/nova-tab'));
        if (id && id !== t.id) void act('move', { id, index: t.index }).catch(report);
      });
      let preview: HTMLElement | undefined;
      row.addEventListener('mouseenter', () => {
        const cached = snapshot['nova.snapshot.' + t.id];
        if (!cached) return;
        preview = el('div', 'tab-preview');
        const img = el('img');
        img.src = cached.data;
        img.alt = 'User-captured snapshot';
        preview.append(
          img,
          el('small', '', 'Snapshot · ' + new Date(cached.created).toLocaleTimeString()),
        );
        row.append(preview);
      });
      row.addEventListener('mouseleave', () => preview?.remove());
      list.append(row);
    }
    if (!visible.length) list.append(el('p', 'muted', 'No matching tabs.'));
  }
  paint();
  if ((data.closed as { tab?: chrome.tabs.Tab }[]).length) {
    const closed = el('details', 'manager-actions');
    closed.append(el('summary', '', 'Recently closed'));
    for (const v of data.closed as { tab?: chrome.tabs.Tab; window?: chrome.windows.Window }[]) {
      const session =
        (v.tab as chrome.tabs.Tab & { sessionId?: string })?.sessionId ??
        (v.window as chrome.windows.Window & { sessionId?: string })?.sessionId;
      if (session)
        closed.append(
          button(v.tab?.title ?? 'Closed window', () => act('reopen', { value: session })),
        );
    }
    root.append(closed);
  }
  root.scrollTop = position;
  if (prior) root.querySelector<HTMLElement>(`[aria-label="${CSS.escape(prior)}"]`)?.focus();
}
function queue() {
  clearTimeout(refreshTimer);
  refreshTimer = setTimeout(() => void refresh().catch(report), 150);
}
for (const event of [
  chrome.tabs.onCreated,
  chrome.tabs.onRemoved,
  chrome.tabs.onMoved,
  chrome.tabs.onUpdated,
  chrome.tabs.onActivated,
])
  event.addListener(queue);
chrome.storage.onChanged.addListener((_, area) => {
  if (area === 'local') queue();
});
void loadSettings()
  .then(async () => {
    await renderAppearance();
    await refresh();
  })
  .catch(report);
window.addEventListener('pagehide', () => {
  clearTimeout(refreshTimer);
  for (const event of [
    chrome.tabs.onCreated,
    chrome.tabs.onRemoved,
    chrome.tabs.onMoved,
    chrome.tabs.onUpdated,
    chrome.tabs.onActivated,
  ])
    event.removeListener(queue);
});
