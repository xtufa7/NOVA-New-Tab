export const themes: Record<
  string,
  { color: string; accent: string; text: string; gradient: string }
> = {
  void: {
    color: '#0b0b10',
    accent: '#b2a1ef',
    text: '#eeedf5',
    gradient: 'radial-gradient(ellipse at 50% 20%, #20172c 0%, #0b0b10 65%)',
  },
  charcoal: {
    color: '#111314',
    accent: '#a7c6bd',
    text: '#e4ece8',
    gradient: 'radial-gradient(ellipse at 50% 15%, #20302a 0%, #111314 65%)',
  },
  dusk: {
    color: '#150e17',
    accent: '#e6a8b8',
    text: '#f7edf1',
    gradient: 'radial-gradient(ellipse at 50% 20%, #38212e 0%, #150e17 65%)',
  },
  aurora: {
    color: '#071918',
    accent: '#64fbd0',
    text: '#e4fff8',
    gradient:
      'radial-gradient(at 20% 15%, #18574b, transparent 65%), radial-gradient(at 85% 70%, #28225b, #071918 75%)',
  },
  electric: {
    color: '#101126',
    accent: '#7daaff',
    text: '#eef2ff',
    gradient:
      'radial-gradient(at 15% 20%, #243d72, transparent 65%), radial-gradient(at 90% 70%, #512969, #101126 75%)',
  },
  sunset: {
    color: '#271226',
    accent: '#ffbb83',
    text: '#fff1e7',
    gradient:
      'radial-gradient(at 20% 10%, #803c50, transparent 60%), radial-gradient(at 90% 80%, #442976, #271226 75%)',
  },
  candy: {
    color: '#1e1230',
    accent: '#f69be6',
    text: '#fbecff',
    gradient:
      'radial-gradient(at 10% 30%, #662753, transparent 65%), radial-gradient(at 90% 10%, #3c487a, #1e1230 75%)',
  },
  ocean: {
    color: '#071b29',
    accent: '#70d6f4',
    text: '#e5f7ff',
    gradient: 'radial-gradient(at 60% 10%, #174761, #071b29 70%)',
  },
  ember: {
    color: '#21110e',
    accent: '#ff906d',
    text: '#ffede6',
    gradient: 'radial-gradient(at 50% 10%, #603326, #21110e 70%)',
  },
  mocha: {
    color: '#1e1e2e',
    accent: '#cba6f7',
    text: '#cdd6f4',
    gradient: 'radial-gradient(ellipse at 50% 10%, #30263f, #1e1e2e 75%)',
  },
  frost: {
    color: '#e9edf2',
    accent: '#57539c',
    text: '#242534',
    gradient: 'radial-gradient(ellipse at 50% 20%, #f7f4ff 0%, #e9edf2 70%)',
  },
};
