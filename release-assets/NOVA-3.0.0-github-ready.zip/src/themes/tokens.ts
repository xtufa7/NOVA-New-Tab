import { themes } from './legacy';
export interface Tokens {
  base: string;
  mantle: string;
  crust: string;
  surface0: string;
  surface1: string;
  surface2: string;
  text: string;
  accent: string;
  border: string;
  link: string;
  highlight: string;
  selection: string;
  focus: string;
  shadow: string;
  gradient: string;
}
export interface Palette {
  id: string;
  name: string;
  category: string;
  tokens: Tokens;
}
const mocha: Tokens = {
  base: '#1e1e2e',
  mantle: '#181825',
  crust: '#11111b',
  surface0: '#313244',
  surface1: '#45475a',
  surface2: '#585b70',
  text: '#cdd6f4',
  accent: '#cba6f7',
  border: '#585b70',
  link: '#cba6f7',
  highlight: '#f5c2e7',
  selection: '#45475a',
  focus: '#cba6f7',
  shadow: '#11111b',
  gradient: 'linear-gradient(135deg,#1e1e2e,#313244)',
};
export const palettes: Palette[] = [
  { id: 'mocha', name: 'Catppuccin Mocha Purple', category: 'Dark', tokens: mocha },
  {
    id: 'latte',
    name: 'Catppuccin Latte',
    category: 'Light',
    tokens: {
      ...mocha,
      base: '#eff1f5',
      mantle: '#e6e9ef',
      crust: '#dce0e8',
      surface0: '#ccd0da',
      surface1: '#bcc0cc',
      surface2: '#acb0be',
      text: '#4c4f69',
      accent: '#8839ef',
      border: '#9ca0b0',
      link: '#1e66f5',
      highlight: '#ea76cb',
      selection: '#ccd0da',
      focus: '#8839ef',
      shadow: '#9ca0b0',
      gradient: 'linear-gradient(135deg,#eff1f5,#e6e9ef)',
    },
  },
  {
    id: 'deep-purple',
    name: 'Deep Purple',
    category: 'Dark',
    tokens: {
      ...mocha,
      base: '#171022',
      mantle: '#120c1c',
      crust: '#0b0712',
      surface0: '#2c1d3f',
      surface1: '#493160',
      accent: '#b987f5',
      gradient: 'linear-gradient(135deg,#171022,#2c1d3f)',
    },
  },
  {
    id: 'soft-dark',
    name: 'Soft Dark',
    category: 'Quiet',
    tokens: {
      ...mocha,
      base: '#24262e',
      mantle: '#1f2127',
      crust: '#191b20',
      surface0: '#353844',
      surface1: '#484c5a',
      accent: '#abb6e4',
      text: '#e0e2ed',
      gradient: 'linear-gradient(135deg,#24262e,#353844)',
    },
  },
];
for (const [id, t] of Object.entries(themes))
  if (!palettes.some((p) => p.id === id))
    palettes.push({
      id,
      name: id[0].toUpperCase() + id.slice(1),
      category: id === 'frost' ? 'Light' : 'Classic',
      tokens: {
        ...mocha,
        base: t.color,
        mantle: t.color,
        crust: t.color,
        surface0: t.color,
        surface1: t.color,
        text: t.text,
        accent: t.accent,
        link: t.accent,
        focus: t.accent,
        gradient: t.gradient,
      },
    });
export function tokenPalette(id: string, custom: Palette[] = []) {
  return [...custom, ...palettes].find((p) => p.id === id) ?? palettes[0];
}
export function validCSS(css: string) {
  if (
    css.length > 30000 ||
    /\\|image-set\s*\(|src\s*:/i.test(css) ||
    /@import|url\s*\(|expression\s*\(|-moz-binding|behavior\s*:|<\/style/i.test(css)
  )
    throw Error('CSS imports, network URLs and executable constructs are not supported.');
  return css;
}
export function validatePalette(raw: unknown): Palette {
  if (!raw || typeof raw !== 'object') throw Error('Invalid theme file.');
  const p = raw as Palette;
  if (
    !/^[a-z0-9_-]{1,80}$/i.test(p.id) ||
    typeof p.name !== 'string' ||
    !p.name.trim() ||
    p.name.length > 80 ||
    typeof p.category !== 'string' ||
    p.category.length > 40 ||
    !p.tokens
  )
    throw Error('Invalid theme identity.');
  for (const [key, value] of Object.entries(mocha)) {
    const input = p.tokens[key as keyof Tokens];
    if (typeof input !== 'string') throw Error('Theme token missing: ' + key);
    if (key === 'gradient') {
      validCSS(input);
      if (
        input.length > 500 ||
        (!/^#[a-f0-9]{6}$/i.test(input) &&
          (!/^(linear|radial)-gradient\(/i.test(input) ||
            !/^[a-z0-9#(),.%\s+-]+$/i.test(input) ||
            !input.endsWith(')') ||
            [...input].reduce((n, c) => n + (c === '(' ? 1 : c === ')' ? -1 : 0), 0) !== 0))
      )
        throw Error('Invalid gradient.');
    } else if (!/^#[a-f0-9]{6}$/i.test(input)) throw Error('Use six-digit hex theme colors.');
    void value;
  }
  return {
    id: p.id,
    name: p.name.trim(),
    category: p.category,
    tokens: Object.fromEntries(
      Object.keys(mocha).map((k) => [k, p.tokens[k as keyof Tokens]]),
    ) as unknown as Tokens,
  };
}

export function appearanceTokens(a: {
  color: string;
  accent: string;
  text: string;
  gradient: string;
}): Tokens {
  const base = mocha;
  const rgb = [1, 3, 5].map((i) => parseInt(a.color.slice(i, i + 2), 16));
  const light = rgb.reduce((n, v) => n + v, 0) > 450;
  const shade = (amount: number, target: number) =>
    '#' +
    rgb
      .map((v) =>
        Math.round(v + (target - v) * amount)
          .toString(16)
          .padStart(2, '0'),
      )
      .join('');
  const t = {
    ...base,
    base: a.color,
    mantle: shade(0.1, light ? 255 : 0),
    crust: shade(0.2, light ? 255 : 0),
    surface0: shade(0.08, light ? 0 : 255),
    surface1: shade(0.16, light ? 0 : 255),
    surface2: shade(0.24, light ? 0 : 255),
    text: a.text,
    accent: a.accent,
    link: a.accent,
    focus: a.accent,
    border: shade(0.3, light ? 0 : 255),
    shadow: shade(0.5, 0),
    gradient: a.gradient,
  };
  try {
    validatePalette({ id: 'derived', name: 'Derived', category: 'Custom', tokens: t });
  } catch {
    t.gradient = `linear-gradient(135deg,${a.color},${t.surface0})`;
  }
  return t;
}
