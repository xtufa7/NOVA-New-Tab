import { openPalette, paletteShortcut, send } from '../commands/palette';
import { loadSettings, subscribe, getSettings, storageWarning } from '../storage/settings';
import { renderAppearance } from './appearance';
import { report, shortcut } from '../shared/dom';
import { initTerminal } from '../terminal/index';
import { renderWidgets } from '../widgets/registry';
import { enterWorkspace } from './entrance';
let ready = false;
export async function openSettings(section?: string) {
  const module = await import('../settings/control');
  module.openControlCenter(section);
}
export async function toggleEdit() {
  const module = await import('./edit');
  module.toggleEdit();
}
async function render() {
  if (!ready) return;
  const wordmark = document.querySelector<HTMLElement>('.wordmark')!;
  wordmark.textContent = getSettings().branding.name;
  wordmark.hidden = getSettings().branding.hidden;
  const results = await Promise.allSettled([renderAppearance(), renderWidgets()]);
  for (const result of results) if (result.status === 'rejected') report(result.reason);
}
async function main() {
  await loadSettings();
  if (storageWarning) report(storageWarning);
  ready = true;
  initTerminal({ openSettings, toggleEdit });
  await render();
  if (globalThis.chrome?.runtime?.id) {
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('companion.js');
    document.body.append(script);
  }
  const { mountTerminalLyrics } = await import('../music/spotify');
  mountTerminalLyrics();
  const { mountMemory } = await import('./memory');
  mountMemory();
  const { mountTabIdentity } = await import('./tab-identity');
  mountTabIdentity();
  subscribe(() => void render().catch(report));
  const system = matchMedia('(prefers-color-scheme: dark)');
  const adapt = () => {
    void send('suite-system', { dark: system.matches }).catch(() => {});
    void renderAppearance().catch(report);
  };
  system.addEventListener('change', adapt);
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) adapt();
  });
  adapt();
  if (globalThis.chrome?.runtime?.id)
    chrome.runtime.onMessage.addListener((m) => {
      if (m.type === 'nova-adaptive-refresh') void renderAppearance().catch(report);
      if (m.type === 'nova-palette') openPalette();
    });
  document
    .querySelector('#settings-toggle')!
    .addEventListener('click', () => void openSettings().catch(report));
  document
    .querySelector('#edit-toggle')!
    .addEventListener('click', () => void toggleEdit().catch(report));
  document.addEventListener('nova-error', (e) => report((e as CustomEvent).detail));
  document.addEventListener('keydown', (e) => {
    const key = shortcut(e),
      s = getSettings();
    if (s.suite.commands.enabled && paletteShortcut(e, s.suite.commands.shortcut)) {
      e.preventDefault();
      openPalette();
    }
    if (s.suite.commands.enabled && paletteShortcut(e, s.suite.commands.focusShortcut)) {
      e.preventDefault();
      void send('suite-command', { id: 'focus-site' }).catch(report);
    }
    if (key === s.shortcuts.settings) {
      e.preventDefault();
      void openSettings().catch(report);
    }
    if (key === s.shortcuts.edit) {
      e.preventDefault();
      void toggleEdit().catch(report);
    }
  });
  performance.mark('nova-ready');
  void enterWorkspace(false);
  if (location.hash === '#palette') openPalette();
}
void main().catch((error) => {
  document.body.classList.remove('nova-loading');
  report(error);
});
