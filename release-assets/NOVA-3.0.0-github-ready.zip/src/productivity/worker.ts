import { KEY, validateSettings } from '../storage/settings';
import { defaults, applyTheme, type Settings } from '../settings/schema';
import { registry } from '../commands/registry';
import {
  newSite,
  siteConfig,
  domain,
  selector,
  resolvePalette,
  hostPattern,
} from '../website/model';
import { tokenPalette, appearanceTokens } from '../themes/tokens';
import { isGecko } from '../shared/platform';
import { safeURL } from '../shared/dom';

let mutations = Promise.resolve();
export async function settings() {
  return validateSettings((await chrome.storage.local.get(KEY))[KEY] ?? defaults());
}
export function mutate(fn: (s: Settings) => void) {
  const next = mutations.then(async () => {
    const s = await settings();
    fn(s);
    validateSettings(s);
    await chrome.storage.local.set({ [KEY]: s });
    return s;
  });
  mutations = next.then(
    () => {},
    () => {},
  );
  return next;
}
function extension(sender: chrome.runtime.MessageSender) {
  return !!sender.url?.startsWith(chrome.runtime.getURL(''));
}
async function current(sender: chrome.runtime.MessageSender, tabId?: number) {
  if (sender.tab && !extension(sender)) return sender.tab;
  if (tabId) return chrome.tabs.get(tabId);
  const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (active?.url?.startsWith(chrome.runtime.getURL(''))) {
    return (await chrome.tabs.query({ currentWindow: true }))
      .filter((t) => /^https?:\/\//.test(t.url ?? ''))
      .sort((a, b) => (b.lastAccessed ?? 0) - (a.lastAccessed ?? 0))[0];
  }
  return active;
}
async function pageConfig(url: string) {
  const s = await settings(),
    host = new URL(url).hostname,
    w = s.suite.website,
    candidate = siteConfig(w, host),
    granted = await chrome.permissions.contains({ origins: [hostPattern(url)] }),
    r =
      granted && candidate
        ? candidate.enabled
          ? candidate
          : { ...candidate, focusEnabled: false, reading: false, reduceMotion: false }
        : undefined;
  const blocked = w.blocklist.some((d) => host === d || host.endsWith('.' + d));
  const allowed =
    w.listMode !== 'allowlist' || w.allowlist.some((d) => host === d || host.endsWith('.' + d));
  let palette = resolvePalette(
    s.suite,
    s.activeProfile,
    new Date(),
    (await chrome.storage.session.get('nova.systemDark'))['nova.systemDark'] !== false,
  );
  if (w.sync && !s.suite.adaptive.enabled && s.suite.adaptive.manualUntil <= Date.now())
    palette = s.profiles.find((p) => p.id === s.activeProfile)?.appearance.theme ?? palette;
  if (r && !r.inheritPalette) palette = r.palette;
  return {
    website: { ...w, custom: [], sites: [], allowlist: [], blocklist: [] },
    site: r,
    tokens: {
      ...(w.sync &&
      !s.suite.adaptive.enabled &&
      s.suite.adaptive.manualUntil <= Date.now() &&
      (!r || r.inheritPalette)
        ? appearanceTokens(s.profiles.find((p) => p.id === s.activeProfile)!.appearance)
        : tokenPalette(palette, w.custom).tokens),
      ...r?.tokens,
    },
    theme: granted && w.enabled && r?.enabled !== false && !blocked && allowed,
    host,
    shortcuts: {
      enabled: s.suite.commands.enabled,
      websites: s.suite.commands.websites,
      shortcut: s.suite.commands.shortcut,
      focusShortcut: s.suite.commands.focusShortcut,
    },
  };
}
let syncQueue = Promise.resolve();
let lastSync = '';
export function syncWebsite() {
  syncQueue = syncQueue
    .catch(() => {})
    .then(async () => {
      const s = await settings();
      const grants = await chrome.permissions.getAll();
      const matches = (grants.origins ?? []).filter(
        (p) => /^https?:\/\//.test(p) || p === '<all_urls>',
      );
      const fingerprint = JSON.stringify([
        s.suite.website,
        s.suite.adaptive,
        s.suite.commands,
        s.activeProfile,
        s.suite.website.sync ? s.profiles.find((p) => p.id === s.activeProfile)?.appearance : null,
        matches,
        (await chrome.storage.session.get('nova.systemDark'))['nova.systemDark'],
      ]);
      if (fingerprint === lastSync) return;
      const id = 'nova-website';
      const registered = await chrome.scripting.getRegisteredContentScripts();
      const enabled =
        s.suite.website.enabled ||
        s.suite.website.sites.some((r) => r.focusEnabled || r.reduceMotion) ||
        (s.suite.commands.enabled && s.suite.commands.websites);
      const prior = registered.find((r) => r.id === id);
      if (prior && (!enabled || JSON.stringify(prior.matches) !== JSON.stringify(matches)))
        await chrome.scripting.unregisterContentScripts({ ids: [id] });
      if (
        enabled &&
        matches.length &&
        (!prior || JSON.stringify(prior.matches) !== JSON.stringify(matches))
      )
        await chrome.scripting.registerContentScripts([
          {
            id,
            matches,
            js: ['website.js'],
            runAt: 'document_idle',
            allFrames: true,
            persistAcrossSessions: true,
          },
        ]);
      const tabs = await chrome.tabs.query({});
      for (const tab of tabs) {
        if (!tab.id || !/^https?:\/\//.test(tab.url ?? '')) continue;
        try {
          await chrome.tabs.sendMessage(tab.id, { type: 'nova-suite-refresh' });
        } catch {
          if (
            enabled &&
            (await chrome.permissions.contains({ origins: [hostPattern(tab.url!)] }))
          ) {
            try {
              await chrome.scripting.executeScript({
                target: { tabId: tab.id, allFrames: true },
                files: ['website.js'],
              });
            } catch {
              /* Restricted/store pages and closing tabs are expected. */
            }
          }
        }
      }
      lastSync = fingerprint;
    });
  return syncQueue;
}
export async function openManager() {
  if (!isGecko && chrome.sidePanel?.open) {
    try {
      const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (t.windowId) await chrome.sidePanel.open({ windowId: t.windowId });
      return;
    } catch {
      /* Side panel needs a user gesture; full page is always available. */
    }
  }
  const browser = (
    globalThis as unknown as { browser?: { sidebarAction?: { open: () => Promise<void> } } }
  ).browser;
  if (isGecko && browser?.sidebarAction) {
    try {
      await browser.sidebarAction.open();
      return;
    } catch {}
  }
  await chrome.tabs.create({ url: chrome.runtime.getURL('manager.html') });
}
export async function suiteMessage(
  m: Record<string, unknown>,
  sender: chrome.runtime.MessageSender,
  legacy: (m: Record<string, unknown>) => Promise<any>,
) {
  const type = String(m.type);
  if (type === 'suite-config') {
    if (!sender.tab || !/^https?:\/\//.test(sender.url ?? ''))
      throw Error('Website context required.');
    return pageConfig(sender.url!);
  }
  if (type === 'suite-system') {
    if (!extension(sender) && !sender.tab) throw Error('Invalid context.');
    const prior = (await chrome.storage.session.get('nova.systemDark'))['nova.systemDark'];
    if (prior !== !!m.dark) {
      await chrome.storage.session.set({ 'nova.systemDark': !!m.dark });
      await syncWebsite();
    }
    return {};
  }
  if (type === 'suite-site-save') {
    const t = await current(sender, Number(m.tabId) || undefined);
    if (!t?.url || !/^https?:\/\//.test(t.url)) throw Error('This page cannot be customized.');
    const host = domain(t.url);
    return mutate((s) => {
      let r = s.suite.website.sites.find((r) => r.domain === host);
      if (!r) {
        r = newSite(host);
        s.suite.website.sites.push(r);
      }
      if (m.element) {
        const e = m.element as {
          selector: string;
          preserve: boolean;
          colors: Record<string, string>;
        };
        selector(e.selector);
        r.elements = r.elements.filter((v) => v.selector !== e.selector);
        r.elements.push(e);
      }
      if (typeof m.elementRemove === 'string') {
        const sel = selector(m.elementRemove);
        r.elements = r.elements.filter((e) => e.selector !== sel);
      }
      if (typeof m.focus === 'string') {
        const sel = selector(m.focus);
        r.focus = [...new Set([...r.focus, sel])];
        r.focusEnabled = true;
      }
      if (m.reset === true) {
        r.elements = [];
        r.focus = [];
        r.focusEnabled = false;
      }
      if (typeof m.enabled === 'boolean') r.enabled = m.enabled;
      if (typeof m.reading === 'boolean') r.reading = m.reading;
      if (typeof m.focusEnabled === 'boolean') r.focusEnabled = m.focusEnabled;
    }).then(() => ({}));
  }
  if (type === 'suite-registry') {
    const s = await settings();
    let tabs: chrome.tabs.Tab[] = [];
    if (await chrome.permissions.contains({ permissions: ['tabs'] }))
      tabs = await chrome.tabs.query({});
    return {
      enabled: s.suite.commands.enabled,
      items: registry(s, tabs),
      favorites: s.suite.commands.favorites,
      recent: s.suite.commands.recent,
    };
  }
  if (type === 'suite-command') {
    const s = await settings(),
      tabs = await chrome.tabs.query({}),
      cmd = registry(s, tabs).find((c) => c.id === m.id);
    if (!cmd) throw Error('Unknown command.');
    const tab = await current(sender, Number(m.tabId) || undefined);
    await mutate((s) => {
      s.suite.commands.recent = [
        cmd.id,
        ...s.suite.commands.recent.filter((id) => id !== cmd.id),
      ].slice(0, 30);
    });
    switch (cmd.action) {
      case 'manager':
        await openManager();
        break;
      case 'settings':
        await chrome.tabs.create({
          url: chrome.runtime.getURL('settings.html') + '#' + encodeURIComponent(cmd.value!),
        });
        break;
      case 'profile':
        await mutate((s) => {
          s.activeProfile = cmd.value!;
        });
        break;
      case 'theme':
        await mutate((s) => {
          applyTheme(
            s.profiles.find((p) => p.id === s.activeProfile)!,
            cmd.value!,
          );
        });
        break;
      case 'palette':
        await mutate((s) => {
          s.suite.website.palette = cmd.value!;
          s.suite.adaptive.manualPalette = cmd.value!;
          s.suite.adaptive.manualUntil = Date.now() + 3600000;
        });
        break;
      case 'web-toggle':
        await mutate((s) => {
          s.suite.website.enabled = !s.suite.website.enabled;
        });
        break;
      case 'web-mode':
        await mutate((s) => {
          s.suite.website.mode = cmd.value as 'smart' | 'original';
        });
        break;
      case 'tab': {
        const t = await chrome.tabs.get(Number(cmd.value));
        await chrome.tabs.update(t.id!, { active: true });
        await chrome.windows.update(t!.windowId, { focused: true });
        break;
      }
      case 'session': {
        const session = s.sessions.find((v) => v.id === cmd.value);
        for (const url of session?.urls ?? []) await chrome.tabs.create({ url: safeURL(url) });
        break;
      }
      case 'music': {
        const result = await legacy({ target: 'worker', type: 'music', action: cmd.value });
        if (result?.error) throw Error(result.error);
        break;
      }
      case 'float':
        if (!tab) throw Error('No tab selected.');
        {
          const result = await legacy({
            target: 'worker',
            type: 'float-open',
            tabId: tab.id,
            mode: s.floatingTabs.mode,
          });
          if (result?.error) throw Error(result.error);
        }
        break;
      case 'focus':
        if (!tab?.url || !/^https?:\/\//.test(tab.url)) throw Error('Open a website first.');
        await mutate((s) => {
          let r = s.suite.website.sites.find((r) => r.domain === new URL(tab.url!).hostname);
          if (!r) {
            r = newSite(new URL(tab.url!).hostname);
            s.suite.website.sites.push(r);
          }
          r.focusEnabled = !r.focusEnabled;
        });
        break;
      case 'inspect':
      case 'focus-pick':
        if (!tab?.id) throw Error('No tab selected.');
        try {
          await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ['website.js'],
          });
          await chrome.tabs.sendMessage(
            tab.id,
            { type: cmd.action === 'inspect' ? 'nova-inspect' : 'nova-focus-pick' },
            { frameId: 0 },
          );
        } catch {
          throw Error(
            'Allow this website in Website Appearance, then reload it. Browser and store pages are restricted.',
          );
        }
        break;
    }
    return {};
  }
  if (!extension(sender) && type !== 'suite-favorite') throw Error('Open this action from NØVA.');
  if (type === 'suite-refresh') {
    await syncWebsite();
    return {};
  }
  if (type === 'suite-favorite') {
    return mutate((s) => {
      const id = String(m.id);
      s.suite.commands.favorites = s.suite.commands.favorites.includes(id)
        ? s.suite.commands.favorites.filter((v) => v !== id)
        : [...s.suite.commands.favorites, id].slice(0, 100);
    }).then(() => ({}));
  }
  if (type === 'suite-capture') {
    const tab = await current(sender, Number(m.tabId) || undefined);
    if (!tab?.id || !tab.active || !/^https?:\/\//.test(tab.url ?? ''))
      throw Error('Select a website tab first.');
    const snapshots = await chrome.storage.session.get(null);
    const keys = Object.keys(snapshots)
      .filter((k) => k.startsWith('nova.snapshot.'))
      .sort(
        (a, b) =>
          ((snapshots[a] as { created: number }).created ?? 0) -
          ((snapshots[b] as { created: number }).created ?? 0),
      );
    if (keys.length >= 8) await chrome.storage.session.remove(keys.slice(0, keys.length - 7));
    const data = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 45 });
    await chrome.storage.session.set({
      ['nova.snapshot.' + tab.id]: { data, created: Date.now() },
    });
    return {};
  }
  if (type === 'suite-tabs') {
    if (!(await chrome.permissions.contains({ permissions: ['tabs'] })))
      throw Error('Allow tab access from Tab Manager.');
    const tabs = await chrome.tabs.query({});
    const snapshots = await chrome.storage.session.get(null);
    let closed: unknown[] = [];
    if (chrome.sessions && (await chrome.permissions.contains({ permissions: ['sessions'] })))
      closed = await chrome.sessions.getRecentlyClosed({ maxResults: 15 });
    let groups: chrome.tabGroups.TabGroup[] = [];
    if (chrome.tabGroups && (await chrome.permissions.contains({ permissions: ['tabGroups'] })))
      groups = await chrome.tabGroups.query({});
    return {
      tabs,
      closed,
      groups,
      snapshots: Object.fromEntries(
        Object.entries(snapshots).filter(([k]) => k.startsWith('nova.snapshot.')),
      ),
      settings: (await settings()).suite.tabs,
    };
  }
  if (type === 'suite-tab-action') {
    if (!(await chrome.permissions.contains({ permissions: ['tabs'] })))
      throw Error('Tab permission required.');
    const ids = Array.isArray(m.ids)
      ? m.ids.map(Number).filter(Number.isSafeInteger).slice(0, 200)
      : [];
    const id = Number(m.id);
    switch (m.action) {
      case 'switch': {
        const t = await chrome.tabs.update(id, { active: true });
        await chrome.windows.update(t!.windowId, { focused: true });
        break;
      }
      case 'close':
        await chrome.tabs.remove(ids.length ? ids : [id]);
        break;
      case 'pin':
        await chrome.tabs.update(id, { pinned: !!m.value });
        break;
      case 'mute':
        await chrome.tabs.update(id, { muted: !!m.value });
        break;
      case 'discard':
        for (const v of ids.length ? ids : [id]) {
          try {
            await chrome.tabs.discard(v);
          } catch {}
        }
        break;
      case 'duplicate':
        await chrome.tabs.duplicate(id);
        break;
      case 'move':
        await chrome.tabs.move(id, { index: Number(m.index) });
        break;
      case 'sort': {
        const list = (await chrome.tabs.query({ currentWindow: true }))
          .filter((t) => !t.pinned)
          .sort((a, b) => (a.title ?? '').localeCompare(b.title ?? ''));
        for (const t of list) await chrome.tabs.move(t.id!, { index: -1 });
        break;
      }
      case 'deduplicate': {
        const seen = new Set<string>();
        for (const t of (await chrome.tabs.query({ currentWindow: true })).sort(
          (a, b) =>
            Number(b.pinned || b.audible || b.active) - Number(a.pinned || a.audible || a.active),
        )) {
          if (!t.url) continue;
          if (t.pinned || t.audible || t.active) {
            seen.add(t.url);
            continue;
          }
          if (seen.has(t.url)) await chrome.tabs.remove(t.id!);
          else seen.add(t.url);
        }
        break;
      }
      case 'reopen':
        if (!(await chrome.permissions.contains({ permissions: ['sessions'] })))
          throw Error('Allow session access first.');
        await chrome.sessions.restore(typeof m.value === 'string' ? m.value : undefined);
        break;
      case 'group':
        if (
          !chrome.tabs.group ||
          !(await chrome.permissions.contains({ permissions: ['tabGroups'] }))
        )
          throw Error('Native groups are unavailable. Use workspaces instead.');
        {
          const g = await chrome.tabs.group({ tabIds: ids as [number, ...number[]] });
          await chrome.tabGroups.update(g, { title: String(m.value ?? 'NØVA').slice(0, 80) });
          break;
        }
      case 'workspace':
        await mutate((s) => {
          for (const v of ids) s.suite.tabs.assignments[String(v)] = String(m.value ?? '');
        });
        break;
      case 'save': {
        const list = await chrome.tabs.query({ currentWindow: true }),
          urls = list.map((t) => t.url ?? '').filter((u) => /^https?:\/\//.test(u));
        await mutate((s) => {
          s.sessions.push({
            id: crypto.randomUUID(),
            name: String(m.value || 'Session').slice(0, 80),
            created: Date.now(),
            urls,
          });
        });
        break;
      }
      default:
        throw Error('Unknown tab action.');
    }
    return {};
  }
  throw Error('Unknown suite request.');
}
export function scheduleAdaptive() {
  void settings()
    .then(async (s) => {
      await chrome.alarms.clear('nova-adaptive');
      if (!s.suite.adaptive.enabled) return;
      const now = new Date();
      const times = s.suite.adaptive.rules
        .filter((r) => r.enabled && r.kind === 'time')
        .flatMap((r) => [r.start, r.end])
        .map((v) => {
          const d = new Date(now);
          d.setHours(Number(v.slice(0, 2)), Number(v.slice(3)), 0, 0);
          if (d <= now) d.setDate(d.getDate() + 1);
          return d.getTime();
        });
      if (s.suite.adaptive.manualUntil > Date.now()) times.push(s.suite.adaptive.manualUntil);
      if (times.length) await chrome.alarms.create('nova-adaptive', { when: Math.min(...times) });
    })
    .catch(() => {});
}
chrome.alarms?.onAlarm.addListener((alarm) => {
  if (alarm.name === 'nova-adaptive') {
    lastSync = '';
    void syncWebsite();
    scheduleAdaptive();
    void chrome.runtime.sendMessage({ type: 'nova-adaptive-refresh' }).catch(() => {});
  }
});
