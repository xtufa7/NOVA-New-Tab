import { themes } from '../themes/legacy';
export { themes } from '../themes/legacy';
import { suiteDefaults, type Suite } from '../website/model';
export const SCHEMA_VERSION = 7;
export const widgetIds = [
  'clock',
  'lyrics',
  'date',
  'greeting',
  'terminal',
  'links',
  'notes',
  'music',
  'status',
  'tabs',
  'recent',
  'sessions',
  'credits',
  'shelf',
] as const;
export type WidgetId = (typeof widgetIds)[number];
export interface Appearance {
  theme: string;
  background: 'solid' | 'gradient' | 'image' | 'video';
  color: string;
  gradient: string;
  mediaId: string;
  accent: string;
  text: string;
  opacity: number;
  blur: number;
  brightness: number;
  contrast: number;
  saturation: number;
  panelOpacity: number;
  radius: number;
  shadow: number;
  glow: number;
  font: string;
  fontSize: number;
  clockStyle: '24h' | '12h' | 'seconds';
  clockFace: 'classic' | 'neon' | 'outline' | 'gradient' | 'retro' | 'bold';
  clockFont: string;
  clockCaption: string;
  clockSpacing: number;
  meridiemSize: number;
  meridiemPosition: 'inline' | 'below' | 'hidden';
  customFontId: string;
  clockCustomFontId: string;
  cursor: 'default' | 'crosshair' | 'dot';
  videoLoop: boolean;
  videoSpeed: number;
  customCSS: string;
  cssEnabled: boolean;
  showHeader: boolean;
  showClockCaption: boolean;
  showTerminalHints: boolean;
}
export interface LayoutItem {
  x: number;
  y: number;
  w: number;
  h: number;
  z: number;
  locked: boolean;
  custom: boolean;
}
export interface QuickLink {
  id: string;
  title: string;
  url: string;
  icon: string;
  favicon: boolean;
  shortcut: string;
  newTab: boolean;
  alias: string;
  group: string;
}
export interface Track {
  id: string;
  title: string;
  artist: string;
  coverId: string;
  playlist: string;
  lyrics?: string;
}
export interface Profile {
  id: string;
  name: string;
  appearance: Appearance;
  layout: Partial<Record<WidgetId, LayoutItem>>;
  widgets: Record<WidgetId, boolean>;
  terminal: {
    username: string;
    hostname: string;
    engine: string;
    engines: Record<string, string>;
    aliases: Record<string, string>;
    history: string[];
  };
  links: QuickLink[];
  linksOptions: { labels: boolean; compact: boolean; iconsOnly: boolean };
  notes: string;
  music: {
    tracks: Track[];
    volume: number;
    shuffle: boolean;
    repeat: 'off' | 'all' | 'one';
    playlist: string;
    muted: boolean;
    autoDuck: boolean;
  };
}
export interface Settings {
  suite: Suite;
  schemaVersion: 7;
  branding: { name: string; hidden: boolean };
  accountAvatars: { github: string; instagram: string; x: string; discord: string };
  memory: { enabled: boolean; browser: 'helium' | 'chrome' | 'msedge' | 'brave' | 'chromium' };
  activeProfile: string;
  profiles: Profile[];
  lyrics: {
    enabled: boolean;
    respectSystem: boolean;
    unit: 'word' | 'letter';
    duration: number;
    stagger: number;
    rise: number;
    blur: number;
    color: string;
    arabicFont: string;
    englishFont: string;
    size: number;
    weight: number;
    spacing: number;
    lineHeight: number;
  };
  entrance: {
    enabled: boolean;
    respectSystem: boolean;
    style: 'rise+blur' | 'rise' | 'fade' | 'zoom' | 'slide';
    duration: number;
    stagger: number;
    delay: number;
    distance: number;
    blur: number;
    easing: 'smooth' | 'ease-out' | 'linear';
    clock: boolean;
    terminal: boolean;
    header: boolean;
    widgets: boolean;
    background: boolean;
  };
  performance: {
    lowPower: boolean;
    animations: 'full' | 'reduced' | 'off';
    blur: 'high' | 'medium' | 'low' | 'off';
    video: 'full' | 'reduced' | 'off';
    particles: boolean;
    visualizer: boolean;
  };
  floatingTabs: {
    width: number;
    height: number;
    left: number;
    top: number;
    audio: boolean;
    mode: 'live' | 'interactive';
  };
  credits: { discordURL: string; gunsAvatarId: string; syncGunsAvatar: boolean; lastSync: number };
  tab: {
    title: string;
    animation: 'off' | 'typewriter' | 'scroll';
    speed: number;
    iconId: string;
    animateIcon: boolean;
  };

  shortcuts: { settings: string; edit: string };
  privacy: { rememberHistory: boolean; blockTrackers: boolean; exceptions: string[] };
  fonts: { id: string; name: string; faces: { mediaId: string; unicodeRange: string }[] }[];
  companion: { enabled: boolean; edge: 'left' | 'right'; y: number; exceptions: string[] };
  integrations: {
    spotify: boolean;
    spotifySource: 'web' | 'desktop';
    onlineLyrics: boolean;
    terminalLyrics: boolean;
    lyricsOffset: number;
    lyricsAnimation: 'rise' | 'rise+blur' | 'fade' | 'blur' | 'typewriter' | 'none';
    desktopBridge: boolean;
    spectrum: 'off' | 'bars' | 'cava' | 'native-cava';
  };
  customThemes: { id: string; name: string; appearance: Appearance }[];
  sessions: { id: string; name: string; urls: string[]; created: number }[];
}
export const engines: Record<string, string> = {
  google: 'https://www.google.com/search?q={query}',
  duckduckgo: 'https://duckduckgo.com/?q={query}',
  bing: 'https://www.bing.com/search?q={query}',
  youtube: 'https://www.youtube.com/results?search_query={query}',
  github: 'https://github.com/search?q={query}',
  reddit: 'https://www.reddit.com/search/?q={query}',
  x: 'https://x.com/search?q={query}',
  stackoverflow: 'https://stackoverflow.com/search?q={query}',
};
export function makeProfile(name = 'Minimal', id: string = crypto.randomUUID()): Profile {
  return {
    id,
    name,
    appearance: {
      theme: 'void',
      background: 'gradient',
      ...themes.void,
      mediaId: '',
      opacity: 100,
      blur: 0,
      brightness: 100,
      contrast: 100,
      saturation: 100,
      panelOpacity: 35,
      radius: 16,
      shadow: 8,
      glow: 0,
      font: 'system',
      fontSize: 14,
      clockStyle: '24h',
      clockFace: 'classic',
      clockFont: 'system',
      clockCaption: 'YOUR TIME. YOUR SPACE.',
      clockSpacing: -0.06,
      meridiemSize: 20,
      meridiemPosition: 'inline',
      customFontId: '',
      clockCustomFontId: '',
      cursor: 'default',
      videoLoop: true,
      videoSpeed: 1,
      customCSS: '',
      cssEnabled: false,
      showHeader: true,
      showClockCaption: true,
      showTerminalHints: true,
    },
    layout: {},
    widgets: Object.fromEntries(
      widgetIds.map((w) => [
        w,
        ['clock', 'lyrics', 'greeting', 'terminal', 'links', 'credits'].includes(w),
      ]),
    ) as Record<WidgetId, boolean>,
    terminal: {
      username: 'KiT',
      hostname: 'Helium',
      engine: 'google',
      engines: { ...engines },
      aliases: {
        g: 'google',
        ddg: 'duckduckgo',
        yt: 'youtube',
        gh: 'github',
        so: 'stackoverflow',
      },
      history: [],
    },
    links: [
      ['GitHub', 'https://github.com', '⌘'],
      ['YouTube', 'https://youtube.com', '▷'],
      ['Discord', 'https://discord.com/app', '◈'],
      ['ChatGPT', 'https://chatgpt.com', '✳'],
    ].map(([title, url, icon]) => ({
      id: title.toLowerCase(),
      title,
      url,
      icon,
      favicon: false,
      shortcut: '',
      newTab: false,
      alias: title.toLowerCase(),
      group: '',
    })),
    linksOptions: { labels: true, compact: false, iconsOnly: false },
    notes: '',
    music: {
      tracks: [],
      volume: 40,
      shuffle: false,
      repeat: 'all',
      playlist: 'All tracks',
      muted: false,
      autoDuck: true,
    },
  };
}
export function defaults(): Settings {
  const profiles = ['Minimal', 'Coding', 'Gaming', 'Work'].map((name) =>
    makeProfile(name, name.toLowerCase()),
  );
  profiles[1].widgets.notes = true;
  profiles[3].widgets.sessions = true;
  return {
    schemaVersion: 7,
    suite: suiteDefaults(),
    branding: { name: 'NØVA', hidden: false },
    accountAvatars: { github: '', instagram: '', x: '', discord: '' },
    memory: { enabled: true, browser: 'helium' },
    activeProfile: 'minimal',
    profiles,
    lyrics: {
      enabled: true,
      respectSystem: true,
      unit: 'letter',
      duration: 650,
      stagger: 35,
      rise: 16,
      blur: 8,
      color: '#e0e0e0',
      arabicFont: 'system',
      englishFont: 'mono',
      size: 15,
      weight: 400,
      spacing: 0,
      lineHeight: 1.6,
    },
    entrance: {
      enabled: true,
      respectSystem: true,
      style: 'rise+blur',
      duration: 800,
      stagger: 90,
      delay: 100,
      distance: 24,
      blur: 8,
      easing: 'smooth',
      clock: true,
      terminal: true,
      header: true,
      widgets: true,
      background: true,
    },
    performance: {
      lowPower: false,
      animations: 'reduced',
      blur: 'low',
      video: 'reduced',
      particles: false,
      visualizer: false,
    },
    floatingTabs: {
      width: 480,
      height: 300,
      left: 80,
      top: 80,
      audio: false,
      mode: 'live',
    },
    credits: {
      discordURL: 'https://discord.com/app',
      gunsAvatarId: '',
      syncGunsAvatar: false,
      lastSync: 0,
    },
    tab: { title: 'NØVA', animation: 'off', speed: 350, iconId: '', animateIcon: true },
    shortcuts: { settings: 'Ctrl+,', edit: 'Ctrl+Shift+E' },
    privacy: { rememberHistory: true, blockTrackers: false, exceptions: [] },
    fonts: [],
    companion: { enabled: false, edge: 'right', y: 0.5, exceptions: [] },
    integrations: {
      spotify: true,
      spotifySource: 'web',
      onlineLyrics: true,
      terminalLyrics: true,
      lyricsOffset: 0,
      lyricsAnimation: 'rise+blur',
      desktopBridge: false,
      spectrum: 'off',
    },
    customThemes: [],
    sessions: [],
  };
}
export function applyTheme(profile: Profile, name: string) {
  if (!themes[name]) throw new Error(`Unknown theme: ${name}`);
  Object.assign(profile.appearance, themes[name], {
    theme: name,
    background: 'gradient',
  });
}
