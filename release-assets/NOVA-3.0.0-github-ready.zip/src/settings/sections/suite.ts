import { getSettings, getProfile } from '../../storage/settings';
import {
  palettes,
  tokenPalette,
  validatePalette,
  validCSS,
  type Tokens,
  type Palette,
} from '../../themes/tokens';
import {
  domain,
  newSite,
  selector,
  suiteDefaults,
  type SiteRule,
  type ThemeMode,
} from '../../website/model';
import { el, button, download, toast } from '../../shared/dom';
import { send } from '../../commands/palette';
import { registry } from '../../commands/registry';
import type { SettingsUI } from '../ui';
const modes = ['smart', 'force', 'dark-only', 'original', 'custom'];
function grant(ui: SettingsUI) {
  ui.group('Website access', () => {
    ui.note(
      'NØVA reads computed colors only on sites you allow. No page content is sent to a server. Browser settings, extension stores and protected pages cannot be modified.',
    );
    if (!globalThis.chrome?.runtime?.id) {
      ui.note('Install the extension to grant browser access. This is a local UI preview.');
      return;
    }
    const input = ui.field('Website domain', 'text', '', () => {}) as HTMLInputElement;
    ui.content.append(
      button('Allow this domain', async () => {
        const host = domain(input.value);
        const ok = await chrome.permissions.request({
          origins: ['https://' + host + '/*', 'http://' + host + '/*'],
        });
        if (ok) {
          await send('suite-refresh');
          toast('Website allowed. Reload open pages if needed.');
        }
      }),
      button('Allow all websites', async () => {
        const ok = await chrome.permissions.request({ origins: ['https://*/*', 'http://*/*'] });
        if (ok) toast('All website access granted.');
      }),
      button('Revoke optional website access', async () => {
        await chrome.permissions.remove({ origins: ['https://*/*', 'http://*/*'] });
        toast('Optional website access revoked.');
      }),
    );
    const status = el('p', 'muted');
    ui.content.append(status);
    void chrome.permissions.getAll().then((p) => {
      status.textContent = 'Granted: ' + (p.origins ?? []).join(', ');
    });
  });
}
export function websites(ui: SettingsUI) {
  const w = getSettings().suite.website;
  ui.field('Enable website appearance', 'checkbox', w.enabled, (v) =>
    ui.change((s) => {
      s.suite.website.enabled = !!v;
    }),
  );
  ui.field(
    'Default mode',
    'text',
    w.mode,
    (v) =>
      ui.change((s) => {
        s.suite.website.mode = v as ThemeMode;
      }),
    modes,
  );
  ui.field(
    'Website palette',
    'text',
    w.palette,
    (v) =>
      ui.change((s) => {
        s.suite.website.palette = String(v);
      }),
    [...palettes, ...w.custom].map((p) => p.id),
  );
  ui.field('Sync with New Tab theme', 'checkbox', w.sync, (v) =>
    ui.change((s) => {
      s.suite.website.sync = !!v;
    }),
  );
  ui.field('Follow system dark / light', 'checkbox', w.followSystem, (v) =>
    ui.change((s) => {
      s.suite.website.followSystem = !!v;
    }),
  );
  ui.range('Transformation intensity', w.intensity, 0, 100, (v) =>
    ui.change((s) => {
      s.suite.website.intensity = v;
    }),
  );
  ui.range(
    'Minimum text contrast',
    w.contrast,
    3,
    7,
    (v) =>
      ui.change((s) => {
        s.suite.website.contrast = v;
      }),
    0.1,
  );
  ui.range('Accent saturation', w.saturation, 0, 150, (v) =>
    ui.change((s) => {
      s.suite.website.saturation = v;
    }),
  );
  ui.field(
    'Processing budget',
    'text',
    w.performance,
    (v) =>
      ui.change((s) => {
        s.suite.website.performance = v as 'balanced' | 'economical';
      }),
    ['balanced', 'economical'],
  );
  grant(ui);
  ui.group('Rules and exceptions', () => {
    ui.field(
      'Apply to',
      'text',
      w.listMode,
      (v) =>
        ui.change((s) => {
          s.suite.website.listMode = v as 'all' | 'allowlist';
        }),
      ['all', 'allowlist'],
    );
    for (const [key, label] of [
      ['allowlist', 'Allowed domains'],
      ['blocklist', 'Blocked domains'],
    ] as const)
      ui.textArea(label, w[key].join('\n'), (v) => {
        const list = v
          .split('\n')
          .map((x) => x.trim())
          .filter(Boolean)
          .map(domain);
        ui.change((s) => {
          s.suite.website[key] = list;
        });
      });
    ui.textArea('Preserve selectors', w.preserve.join('\n'), (v) => {
      const list = v.split('\n').filter(Boolean).map(selector);
      for (const x of list) document.querySelector(x);
      ui.change((s) => {
        s.suite.website.preserve = list;
      });
    });
    const add = ui.field('New site rule', 'text', '', () => {}) as HTMLInputElement;
    ui.content.append(
      button('Add site rule', () => {
        const r = newSite(add.value);
        ui.change((s) => {
          if (s.suite.website.sites.some((v) => v.domain === r.domain))
            throw Error('A rule for this domain already exists.');
          s.suite.website.sites.push(r);
        });
        ui.redraw();
      }),
    );
    for (const r of w.sites) siteEditor(ui, r);
    ui.content.append(
      button('Export website rules', () =>
        download('nova-website-rules.json', JSON.stringify(w.sites, null, 2)),
      ),
      button('Reset all site rules', () => {
        ui.change((s) => {
          s.suite.website.sites = [];
        });
        ui.redraw();
      }),
    );
    ui.files('Import website rules', '.json', false, async (files) => {
      const raw = JSON.parse(await files[0].text());
      if (!Array.isArray(raw) || raw.length > 300) throw Error('Expected a site-rule array.');
      ui.change((s) => {
        s.suite.website.sites = raw;
      });
      ui.redraw();
    });
  });
  ui.group('Advanced website CSS', () => {
    ui.note(
      'Website CSS is separate from New Tab CSS. Imports, remote assets and executable CSS are rejected. Prefer the inspector for reversible element overrides.',
    );
    ui.textArea(
      'Website CSS',
      w.css,
      (v) => {
        validCSS(v);
        ui.change((s) => {
          s.suite.website.css = v;
        });
      },
      true,
    );
    ui.content.append(
      button('Reset website appearance', () => {
        ui.change((s) => {
          s.suite.website = suiteDefaults().website;
        });
        ui.redraw();
      }),
    );
  });
}
function siteEditor(ui: SettingsUI, r: SiteRule) {
  ui.group(r.domain, () => {
    const edit = (fn: (r: SiteRule) => void) =>
      ui.change((s) => {
        fn(s.suite.website.sites.find((v) => v.id === r.id)!);
      });
    ui.field('Rule enabled', 'checkbox', r.enabled, (v) =>
      edit((r) => {
        r.enabled = !!v;
      }),
    );
    ui.field('Include subdomains', 'checkbox', r.subdomains, (v) =>
      edit((r) => {
        r.subdomains = !!v;
      }),
    );
    ui.range('Rule priority', r.priority, 0, 100, (v) =>
      edit((r) => {
        r.priority = v;
      }),
    );
    ui.field(
      'Site mode',
      'text',
      r.mode,
      (v) =>
        edit((r) => {
          r.mode = v as ThemeMode;
        }),
      modes,
    );
    ui.field('Use global palette', 'checkbox', r.inheritPalette, (v) =>
      edit((r) => {
        r.inheritPalette = !!v;
      }),
    );
    ui.field(
      'Site palette',
      'text',
      r.palette,
      (v) =>
        edit((r) => {
          r.palette = String(v);
        }),
      [...palettes, ...getSettings().suite.website.custom].map((p) => p.id),
    );
    for (const key of ['base', 'surface0', 'text', 'accent', 'border'] as const)
      ui.field(
        'Override ' + key,
        'color',
        r.tokens[key] ?? tokenPalette(r.palette).tokens[key],
        (v) =>
          edit((r) => {
            r.tokens[key] = String(v);
          }),
      );
    ui.textArea(
      'Site CSS',
      r.css,
      (v) => {
        validCSS(v);
        edit((r) => {
          r.css = v;
        });
      },
      true,
    );
    ui.field('Focus enabled', 'checkbox', r.focusEnabled, (v) =>
      edit((r) => {
        r.focusEnabled = !!v;
      }),
    );
    ui.field('Reading layout', 'checkbox', r.reading, (v) =>
      edit((r) => {
        r.reading = !!v;
      }),
    );
    ui.field('Reduce site motion', 'checkbox', r.reduceMotion, (v) =>
      edit((r) => {
        r.reduceMotion = !!v;
      }),
    );
    ui.textArea('Hidden distractions', r.focus.join('\n'), (v) => {
      const selectors = v.split('\n').filter(Boolean).map(selector);
      selectors.forEach((x) => document.querySelector(x));
      edit((r) => {
        r.focus = selectors;
      });
    });
    for (const element of r.elements) {
      const line = el('div', 'site-element-rule');
      line.append(
        el('code', '', element.selector + (element.preserve ? ' · preserve' : '')),
        button('Remove override', () => {
          edit((r) => {
            r.elements = r.elements.filter((v) => v.selector !== element.selector);
          });
          ui.redraw();
        }),
      );
      ui.content.append(line);
    }
    ui.note(
      r.elements.length +
        ' saved inspector overrides. Higher priority wins; equally ranked rules prefer the more specific domain.',
    );
    ui.content.append(
      button('Reset this rule', () => {
        ui.change((s) => {
          s.suite.website.sites = s.suite.website.sites.map((v) =>
            v.id === r.id ? { ...newSite(r.domain), id: r.id } : v,
          );
        });
        ui.redraw();
      }),
      button('Delete rule', () => {
        ui.change((s) => {
          s.suite.website.sites = s.suite.website.sites.filter((v) => v.id !== r.id);
        });
        ui.redraw();
      }),
    );
  });
}
export function marketplace(ui: SettingsUI) {
  const all = [...palettes, ...getSettings().suite.website.custom];
  const search = ui.field('Search themes', 'text', '', () => {}) as HTMLInputElement;
  const category = ui.field('Category', 'text', 'All', () => {}, [
    'All',
    ...new Set(all.map((p) => p.category)),
  ]) as HTMLSelectElement;
  const grid = el('div', 'marketplace-grid');
  ui.content.append(grid);
  const paint = () => {
    grid.replaceChildren();
    for (const p of all.filter(
      (p) =>
        (category.value === 'All' || p.category === category.value) &&
        p.name.toLowerCase().includes(search.value.toLowerCase()),
    )) {
      const card = el('article', 'marketplace-card'),
        preview = el('div', 'marketplace-preview');
      preview.style.background = p.tokens.gradient;
      preview.style.color = p.tokens.text;
      preview.append(el('span', '', '12:48'), el('small', '', p.category));
      const swatches = el('div', 'theme-swatches');
      for (const c of [p.tokens.base, p.tokens.surface0, p.tokens.accent, p.tokens.text]) {
        const sw = el('i');
        sw.style.background = c;
        swatches.append(sw);
      }
      card.append(preview, el('h3', '', p.name), swatches);
      card.append(
        button('Apply to websites', () =>
          ui.change((s) => {
            s.suite.website.palette = p.id;
            s.suite.adaptive.manualPalette = p.id;
            s.suite.adaptive.manualUntil = Date.now() + 3600000;
          }),
        ),
        button('Apply to New Tab', () =>
          ui.change((_s, profile) => {
            Object.assign(profile.appearance, {
              theme: p.id,
              color: p.tokens.base,
              accent: p.tokens.accent,
              text: p.tokens.text,
              gradient: p.tokens.gradient,
            });
          }),
        ),
        button('Duplicate / save', () => {
          const copy = structuredClone(p);
          copy.id = 'custom-' + crypto.randomUUID();
          copy.name = p.name + ' copy';
          ui.change((s) => {
            s.suite.website.custom.push(copy);
          });
          ui.redraw();
        }),
        button('Export', () =>
          download('nova-theme-' + p.id + '.json', JSON.stringify(p, null, 2)),
        ),
      );
      const details = el('details');
      details.append(el('summary', '', 'Token details'));
      for (const [k, v] of Object.entries(p.tokens))
        details.append(el('p', 'code-editor', k + ' · ' + v));
      card.append(details);
      if (getSettings().suite.website.custom.some((v) => v.id === p.id))
        card.append(
          button('Edit tokens', () => {
            editor(ui, p);
          }),
          button('Delete saved theme', () => {
            ui.change((s) => {
              s.suite.website.custom = s.suite.website.custom.filter((v) => v.id !== p.id);
              if (s.suite.website.palette === p.id) s.suite.website.palette = 'mocha';
              for (const rule of s.suite.website.sites)
                if (rule.palette === p.id) rule.palette = 'mocha';
              for (const rule of s.suite.adaptive.rules)
                if (rule.palette === p.id) rule.palette = 'mocha';
              if (s.suite.adaptive.manualPalette === p.id) s.suite.adaptive.manualPalette = 'mocha';
            });
            ui.redraw();
          }),
        );
      grid.append(card);
    }
  };
  search.addEventListener('input', paint);
  category.addEventListener('change', paint);
  paint();
  ui.files('Import theme JSON', '.json', false, async (files) => {
    const p = validatePalette(JSON.parse(await files[0].text()));
    if (palettes.some((v) => v.id === p.id)) p.id = 'import-' + p.id + '-' + crypto.randomUUID();
    ui.change((s) => {
      s.suite.website.custom = s.suite.website.custom.filter((v) => v.id !== p.id);
      s.suite.website.custom.push(p);
    });
    ui.redraw();
  });
  ui.content.append(
    button('Create a theme', () => {
      const p = structuredClone(palettes[0]);
      p.id = 'custom-' + crypto.randomUUID();
      p.name = 'My theme';
      editor(ui, p);
    }),
  );
  ui.note(
    'Curated themes work offline. Theme files contain validated color tokens only, with no scripts or remote code.',
  );
}
function editor(ui: SettingsUI, p: Palette) {
  const draft = structuredClone(p);
  const box = el('div', 'token-editor');
  ui.content.append(box);
  const parent = ui.content;
  ui.content = box;
  ui.heading('Edit ' + p.name);
  const preview = el('div', 'marketplace-preview');
  preview.append(el('span', '', '12:48'), el('small', '', 'Live token preview'));
  const paint = () => {
    preview.style.background = draft.tokens.gradient;
    preview.style.color = draft.tokens.text;
    preview.style.border = '1px solid ' + draft.tokens.border;
  };
  paint();
  ui.content.append(preview);
  ui.field('Theme name', 'text', draft.name, (v) => {
    draft.name = String(v);
  });
  for (const key of Object.keys(draft.tokens) as (keyof Tokens)[])
    ui.field(key, key === 'gradient' ? 'text' : 'color', draft.tokens[key], (v) => {
      draft.tokens[key] = String(v);
      paint();
    });
  ui.content.append(
    button('Save theme', () => {
      const valid = validatePalette(draft);
      ui.change((s) => {
        s.suite.website.custom = s.suite.website.custom.filter((v) => v.id !== valid.id);
        s.suite.website.custom.push(valid);
      });
      ui.redraw();
    }),
    button('Reset draft', () => {
      Object.assign(draft.tokens, palettes[0].tokens);
      box.remove();
      editor(ui, draft);
    }),
    button('Cancel', () => box.remove()),
  );
  ui.content = parent;
  box.scrollIntoView({ block: 'start', behavior: 'smooth' });
}
export function inspectorSettings(ui: SettingsUI) {
  ui.note(
    'Open a website, grant its domain, then choose Inspect from the toolbar or command palette. Select an element to compare original and transformed colors, inspect CSS variables and save a reversible override. Escape closes the overlay.',
  );
  ui.content.append(
    button('Inspect current website', () => send('suite-command', { id: 'inspector' })),
    button('Open Website Appearance', () =>
      chrome.tabs.create({ url: chrome.runtime.getURL('settings.html') + '#Website%20Appearance' }),
    ),
  );
  ui.note(
    'A selector must match one element to save safely. Shadow content is themed when accessible; inspector persistence avoids unstable cross-shadow selectors.',
  );
}
export function tabsSettings(ui: SettingsUI) {
  const c = getSettings().suite.tabs;
  ui.range('Sidebar width', c.width, 240, 600, (v) =>
    ui.change((s) => {
      s.suite.tabs.width = v;
    }),
  );
  for (const [key, label] of [
    ['compact', 'Compact rows'],
    ['collapse', 'Auto collapse / expand on hover'],
    ['minimal', 'Minimal controls'],
  ] as const)
    ui.field(label, 'checkbox', c[key], (v) =>
      ui.change((s) => {
        s.suite.tabs[key] = !!v;
      }),
    );
  ui.content.append(
    button('Open Tab Manager', () => send('suite-command', { id: 'manager' })),
    button('Allow tabs and recently closed sessions', () =>
      chrome.permissions.request({ permissions: ['tabs', 'sessions'] }),
    ),
  );
  ui.note(
    'Use the browser side panel, Firefox / Zen sidebar, or the full manager page. Pinned tabs, mute, reorder, workspaces, sessions, duplicates and discarding are available. Native grouping appears only in browsers that provide it. Hover previews are snapshots captured explicitly from the toolbar; NØVA never captures tabs silently.',
  );
}
export function commandsSettings(ui: SettingsUI) {
  const c = getSettings().suite.commands;
  ui.field('Enable command palette', 'checkbox', c.enabled, (v) =>
    ui.change((s) => {
      s.suite.commands.enabled = !!v;
    }),
  );
  ui.field('Enable shortcuts on allowed websites', 'checkbox', c.websites, (v) =>
    ui.change((s) => {
      s.suite.commands.websites = !!v;
    }),
  );
  ui.field('Command palette shortcut', 'text', c.shortcut, (v) =>
    ui.change((s) => {
      s.suite.commands.shortcut = String(v);
    }),
  );
  ui.field('Focus shortcut', 'text', c.focusShortcut, (v) =>
    ui.change((s) => {
      s.suite.commands.focusShortcut = String(v);
    }),
  );
  ui.note(
    'Shortcuts work on New Tab and allowed websites. Browser-wide commands can also be assigned in the browser extension shortcut settings. Arrow keys navigate, Enter executes, Escape closes.',
  );
  ui.content.append(
    button('Clear recent commands', () =>
      ui.change((s) => {
        s.suite.commands.recent = [];
      }),
    ),
  );
  ui.group('Command catalog', () => {
    for (const cmd of registry(getSettings()))
      ui.content.append(el('p', 'command-catalog', cmd.category + ' · ' + cmd.label));
  });
}
export function adaptive(ui: SettingsUI) {
  const a = getSettings().suite.adaptive;
  ui.field('Enable adaptive themes', 'checkbox', a.enabled, (v) =>
    ui.change((s) => {
      s.suite.adaptive.enabled = !!v;
    }),
  );
  ui.note(
    'Local-time schedules, system appearance and workspace rules use priority ordering. Manual palette choices pause automatic switching for one hour. Resume returns to your automatic rules.',
  );
  ui.content.append(
    button('Resume automatic theme', () =>
      ui.change((s) => {
        s.suite.adaptive.manualUntil = 0;
      }),
    ),
    button('Add adaptive rule', () => {
      ui.change((s) => {
        s.suite.adaptive.rules.push({
          id: crypto.randomUUID(),
          name: 'Evening',
          kind: 'time',
          start: '18:00',
          end: '07:00',
          system: 'dark',
          profile: getProfile().id,
          palette: 'mocha',
          priority: 10,
          enabled: true,
        });
      });
      ui.redraw();
    }),
  );
  for (const r of a.rules)
    ui.group(r.name, () => {
      const edit = (key: string, value: unknown) =>
        ui.change((s) => {
          Object.assign(
            s.suite.adaptive.rules.find((v) => v.id === r.id)!,
            { [key]: value },
          );
        });
      ui.field('Rule name', 'text', r.name, (v) => edit('name', v));
      ui.field('Rule enabled', 'checkbox', r.enabled, (v) => edit('enabled', v));
      ui.field('Trigger', 'text', r.kind, (v) => edit('kind', v), ['time', 'system', 'profile']);
      ui.field('Start local time', 'time', r.start, (v) => edit('start', v));
      ui.field('End local time', 'time', r.end, (v) => edit('end', v));
      ui.field('System appearance', 'text', r.system, (v) => edit('system', v), ['dark', 'light']);
      ui.field(
        'Workspace',
        'text',
        r.profile,
        (v) => edit('profile', v),
        getSettings().profiles.map((p) => p.id),
      );
      ui.field(
        'Palette',
        'text',
        r.palette,
        (v) => edit('palette', v),
        [...palettes, ...getSettings().suite.website.custom].map((p) => p.id),
      );
      ui.range('Priority', r.priority, 0, 100, (v) => edit('priority', v));
      ui.content.append(
        button('Remove schedule', () => {
          ui.change((s) => {
            s.suite.adaptive.rules = s.suite.adaptive.rules.filter((v) => v.id !== r.id);
          });
          ui.redraw();
        }),
      );
    });
}
export function focus(ui: SettingsUI) {
  ui.note(
    'Focus hides selected distractions on one site. Choose elements with the picker or edit selectors under Website Appearance. Forms, authentication, payment inputs and dialogs are protected. Disable the site rule to restore the page.',
  );
  grant(ui);
  ui.content.append(
    button('Pick a distraction on this site', () => send('suite-command', { id: 'focus-pick' })),
    button('Toggle current site Focus', () => send('suite-command', { id: 'focus-site' })),
  );
  ui.group('Conservative presets', () => {
    const domainInput = ui.field('Preset domain', 'text', '', () => {}) as HTMLInputElement;
    const preset = ui.field('Preset', 'text', 'quiet sidebars', () => {}, [
      'quiet sidebars',
      'reading',
      'reduced motion',
    ]) as HTMLSelectElement;
    ui.content.append(
      button('Apply preset', () => {
        const host = domain(domainInput.value);
        ui.change((s) => {
          let r = s.suite.website.sites.find((v) => v.domain === host);
          if (!r) {
            r = newSite(host);
            s.suite.website.sites.push(r);
          }
          if (preset.value === 'quiet sidebars') {
            r.focus = ['aside[aria-label="Recommendations"]', '[data-testid="recommendations"]'];
            r.focusEnabled = true;
          }
          if (preset.value === 'reading') {
            r.reading = true;
            r.focusEnabled = true;
          }
          if (preset.value === 'reduced motion') r.reduceMotion = true;
        });
        toast('Preset saved for ' + host);
      }),
    );
  });
}
